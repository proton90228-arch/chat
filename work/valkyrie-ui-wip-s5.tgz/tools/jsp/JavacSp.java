import javax.tools.*;
import java.util.*;
import java.nio.file.*;
/** java JavacSp.java <outDir> <sourcepath> <listFile> : компилирует файлы из списка с -sourcepath */
public class JavacSp {
    public static void main(String[] a) throws Exception {
        JavaCompiler c = ToolProvider.getSystemJavaCompiler();
        List<String> args = new ArrayList<>(List.of("-d", a[0], "-sourcepath", a[1], "-proc:none", "-encoding", "UTF-8", "-Xmaxerrs", "400", "-implicit:class", "-nowarn"));
        for (String line : Files.readAllLines(Path.of(a[2]))) if (!line.isBlank()) args.add(line.trim());
        int r = c.run(null, null, null, args.toArray(new String[0]));
        System.out.println("exit=" + r + " files=" + (args.size() - 11));
        System.exit(r);
    }
}
