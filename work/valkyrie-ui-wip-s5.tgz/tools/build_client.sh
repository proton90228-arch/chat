#!/bin/bash
# Проверочная сборка изменённых/новых файлов клиента против заглушек MC.
cd /tmp/w/out/src/main/java
: > /tmp/w/tools/jsp/list.txt
for f in $(find . -name "*.java"); do
  if [ ! -f /tmp/w/client/src/main/java/$f ] || ! cmp -s $f /tmp/w/client/src/main/java/$f; then echo "/tmp/w/out/src/main/java/${f#./}" >> /tmp/w/tools/jsp/list.txt; fi
done
rm -rf /tmp/w/tools/jsp/cls && mkdir -p /tmp/w/tools/jsp/cls
java /tmp/w/tools/jsp/JavacSp.java /tmp/w/tools/jsp/cls /tmp/w/stubs/src:/tmp/w/out/src/main/java /tmp/w/tools/jsp/list.txt 2>&1
