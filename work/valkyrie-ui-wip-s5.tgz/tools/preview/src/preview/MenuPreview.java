package preview;

import com.valkyrie.client.ui.color.Scheme;
import com.valkyrie.client.ui.menu.MenuView;
import com.valkyrie.client.ui.motion.Motion;
import com.valkyrie.client.ui.render.Ui;
import com.valkyrie.client.ui.theme.UiTheme;

/** Превью главного меню: java -cp cls:res preview.MenuPreview <outDir> */
public final class MenuPreview {
    static ImageCanvas render(int W, int H, float sc, boolean dark, int seed, float seconds, float mx, float my, String sub) {
        UiTheme.set(seed, dark);
        ImageCanvas cv = new ImageCanvas(W, H, sc);
        boolean[] theme = {dark};
        MenuView view = new MenuView(new MenuView.Host() {
            public void singleplayer() { }
            public void multiplayer() { }
            public void options() { }
            public void telegram() { }
            public void quit() { }
            public void toggleTheme() { theme[0] = !theme[0]; }
            public boolean dark() { return theme[0]; }
            public String subtitle() { return sub; }
            public String username() { return "SakuraBlade"; }
        });
        Ui ui = Ui.get();
        // Промежуточные кадры — на маленьком холсте того же GUI-размера (быстро), последний — в полном.
        ImageCanvas small = new ImageCanvas(Math.round(W / sc), Math.round(H / sc), 1f);
        float t = 0;
        while (t < seconds) {
            Motion.advanceManual(1 / 60f);
            t += 1 / 60f;
            boolean last = t >= seconds;
            ImageCanvas target = last ? cv : small;
            target.clear(0xFF000000);
            ui.begin(target);
            view.render(ui, mx, my);
        }
        return cv;
    }

    public static void main(String[] args) throws Exception {
        String dir = args[0];
        String sub = "Лепестки падают, а ты всё ещё в топе.";
        render(1920, 1080, 3f, false, Scheme.Preset.SAKURA.seed, 2.5f, 320, 182, sub).save(dir + "/menu_light_x3.png");
        render(1920, 1080, 3f, true, Scheme.Preset.SAKURA.seed, 2.5f, -1, -1, sub).save(dir + "/menu_dark_x3.png");
        render(1280, 720, 2f, false, Scheme.Preset.MATCHA.seed, 2.5f, -1, -1, sub).save(dir + "/menu_matcha_720p_x2.png");
        render(1920, 1080, 2f, true, Scheme.Preset.FUJI.seed, 2.5f, -1, -1, sub).save(dir + "/menu_fuji_dark_x2.png");
        System.out.println("menu ok");
    }
}
