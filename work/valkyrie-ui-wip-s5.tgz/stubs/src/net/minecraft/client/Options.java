package net.minecraft.client;
public class Options { public KeyMapping keyInventory, keyUp, keyLeft, keyDown, keyRight; }
