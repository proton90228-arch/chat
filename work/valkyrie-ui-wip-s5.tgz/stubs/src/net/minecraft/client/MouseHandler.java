package net.minecraft.client;
public class MouseHandler { public boolean isLeftPressed() { return false; } public boolean isRightPressed() { return false; } }
