package net.minecraft.client.gui.screens.options;
public class OptionsScreen extends net.minecraft.client.gui.screens.Screen { public OptionsScreen(net.minecraft.client.gui.screens.Screen parent, net.minecraft.client.Options options) { super(null); } }
