package net.minecraft.client.gui.screens.multiplayer;
public class JoinMultiplayerScreen extends net.minecraft.client.gui.screens.Screen { public JoinMultiplayerScreen(net.minecraft.client.gui.screens.Screen parent) { super(null); } }
