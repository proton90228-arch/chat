package net.minecraft.client.gui.screens.worldselection;
public class SelectWorldScreen extends net.minecraft.client.gui.screens.Screen { public SelectWorldScreen(net.minecraft.client.gui.screens.Screen parent) { super(null); } }
