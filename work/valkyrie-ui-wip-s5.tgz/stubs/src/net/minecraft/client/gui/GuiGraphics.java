package net.minecraft.client.gui;
import com.mojang.blaze3d.pipeline.RenderPipeline; import net.minecraft.resources.ResourceLocation; import org.joml.Matrix3x2fStack; import net.minecraft.network.chat.Component;
public class GuiGraphics { public Matrix3x2fStack pose() { return null; } public void fill(int a, int b, int c, int d, int col) {} public void fillGradient(int a, int b, int c, int d, int c1, int c2) {}
  public void blit(RenderPipeline p, ResourceLocation id, int x, int y, float u, float v, int w, int h, int uw, int vh, int tw, int th, int color) {}
  public void blit(RenderPipeline p, ResourceLocation id, int x, int y, float u, float v, int w, int h, int tw, int th, int color) {}
  public void blit(RenderPipeline p, ResourceLocation id, int x, int y, float u, float v, int w, int h, int tw, int th) {}
  public void enableScissor(int a, int b, int c, int d) {} public void disableScissor() {} public void blurBeforeThisStratum() {} public void nextStratum() {}
  public void renderItem(net.minecraft.world.item.ItemStack s, int x, int y) {} public int guiWidth() { return 0; } public int guiHeight() { return 0; }
  public void drawString(Font f, String s, int x, int y, int c, boolean sh) {} public void drawString(Font f, Component s, int x, int y, int c, boolean sh) {} }
