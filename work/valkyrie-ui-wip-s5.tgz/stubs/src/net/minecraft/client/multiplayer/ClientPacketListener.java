package net.minecraft.client.multiplayer;
public class ClientPacketListener { public PlayerInfo getPlayerInfo(java.util.UUID id) { return null; } }
