package net.minecraft.client.multiplayer;
public class PlayerInfo { public int getLatency() { return 0; } }
