package net.minecraft.client;
public class Minecraft { public net.minecraft.client.player.LocalPlayer player; public Options options; public MouseHandler mouseHandler; public net.minecraft.client.gui.screens.Screen screen;
  public static Minecraft getInstance() { return null; }
  public com.mojang.blaze3d.platform.Window getWindow() { return null; } public net.minecraft.client.renderer.texture.TextureManager getTextureManager() { return null; } public void setScreen(net.minecraft.client.gui.screens.Screen s) {}
  public int getFps() { return 0; } public net.minecraft.client.multiplayer.ClientPacketListener getConnection() { return null; } public boolean hasSingleplayerServer() { return false; } public User getUser() { return null; } public void stop() {} }
