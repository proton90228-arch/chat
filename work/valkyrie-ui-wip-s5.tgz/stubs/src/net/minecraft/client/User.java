package net.minecraft.client;
public class User { public String getName() { return ""; } }
