package net.minecraft.world.effect;
public class MobEffect { public net.minecraft.network.chat.Component getDisplayName() { return null; } public int getColor() { return 0; } public MobEffectCategory getCategory() { return null; } }
