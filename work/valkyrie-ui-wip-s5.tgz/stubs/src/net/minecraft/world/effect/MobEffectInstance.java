package net.minecraft.world.effect;
public class MobEffectInstance { public net.minecraft.core.Holder<MobEffect> getEffect() { return null; } public int getAmplifier() { return 0; } public int getDuration() { return 0; } public boolean isInfiniteDuration() { return false; } }
