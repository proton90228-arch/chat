package net.minecraft.world.item;
public class ItemStack { public boolean isEmpty() { return true; } public boolean isDamageableItem() { return false; } public int getMaxDamage() { return 0; } public int getDamageValue() { return 0; } }
