package net.minecraft.world.phys;
public class Vec3 { public double distanceTo(Vec3 o) { return 0; } }
