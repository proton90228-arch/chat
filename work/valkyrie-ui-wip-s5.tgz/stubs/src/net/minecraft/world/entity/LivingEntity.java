package net.minecraft.world.entity;
public class LivingEntity extends Entity { public int hurtTime; public float getHealth() { return 0; } public float getMaxHealth() { return 0; } public float getAbsorptionAmount() { return 0; }
  public net.minecraft.world.item.ItemStack getItemBySlot(EquipmentSlot s) { return null; } public java.util.Collection<net.minecraft.world.effect.MobEffectInstance> getActiveEffects() { return null; } }
