package net.minecraft.world.entity;
public class Entity { public int getId() { return 0; } public net.minecraft.network.chat.Component getDisplayName() { return null; } public net.minecraft.network.chat.Component getName() { return null; }
  public net.minecraft.world.phys.Vec3 position() { return null; } public int getBlockX() { return 0; } public int getBlockY() { return 0; } public int getBlockZ() { return 0; } public java.util.UUID getUUID() { return null; } }
