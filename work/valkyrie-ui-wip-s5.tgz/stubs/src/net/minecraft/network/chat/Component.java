package net.minecraft.network.chat;
public interface Component { static MutableComponent literal(String s) { return new MutableComponent(); } static MutableComponent translatable(String key) { return new MutableComponent(); } default String getString() { return ""; } }
