package net.minecraft;
public class Util { public static OS getPlatform() { return null; } public enum OS { WINDOWS; public void openUri(String uri) {} } }
