package net.minecraftforge.client.gui.overlay;
public interface ForgeLayer { void render(net.minecraft.client.gui.GuiGraphics g, net.minecraft.client.DeltaTracker d); }
