package com.valkyrie.client.render;
public final class CombatVisuals { public static float hitFade() { return 0; } }
