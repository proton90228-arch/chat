package com.valkyrie.client.render;
public final class ValkyrieLines { public static void drawLine(net.minecraft.client.gui.GuiGraphics g, float x0, float y0, float x1, float y1, int color) {} }
