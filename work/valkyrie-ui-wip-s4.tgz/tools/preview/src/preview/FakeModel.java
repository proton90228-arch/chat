package preview;
import com.valkyrie.client.ui.clickgui.*;
import com.valkyrie.client.ui.icon.Icon;
import java.util.*;
/** Сгенерировано из исходников клиента: реальные модули, описания и настройки. */
public final class FakeModel implements GuiModel {
  boolean dark; final List<Category> cats = new ArrayList<>();
  public boolean dark() { return dark; }
  public void setDark(boolean d) { dark = d; }
  public List<Category> categories() { return cats; }
  record Cat(String title, Icon icon, List<Module> modules) implements Category {}
  static final class Mod implements Module {
    final String name, desc; boolean on; final boolean toggle; final String action; final List<Option> opts = new ArrayList<>(); boolean expanded;
    Mod(String n, String d, boolean on, boolean toggle, String action) { name = n; desc = d; this.on = on; this.toggle = toggle; this.action = action; }
    public String name() { return name; } public String description() { return desc; } public Icon icon() { return ModuleIcons.forModule(name); }
    public boolean toggleable() { return toggle; } public boolean enabled() { return on; } public void toggle() { on = !on; }
    public String actionLabel() { return action; } public List<Option> options() { return opts; }
    public boolean expanded() { return expanded; } public void setExpanded(boolean e) { expanded = e; }
  }
  static final class B implements BoolOption { final String n, d; boolean v; B(String n, String d, boolean v) { this.n = n; this.d = d; this.v = v; }
    public String name() { return n; } public String description() { return d; } public boolean value() { return v; } public void set(boolean x) { v = x; } }
  static final class S implements SliderOption { final String n; float v; final float lo, hi; final java.util.function.Function<Float,String> f;
    S(String n, float v, float lo, float hi, java.util.function.Function<Float,String> f) { this.n = n; this.v = v; this.lo = lo; this.hi = hi; this.f = f; }
    public String name() { return n; } public float min() { return lo; } public float max() { return hi; } public float value() { return v; } public void set(float x) { v = x; } public String label() { return f.apply(v); } }
  static final class M implements ModeOption { final String n; final List<String> ms; String v; M(String n, List<String> ms, String v) { this.n = n; this.ms = ms; this.v = v; }
    public String name() { return n; } public List<String> modes() { return ms; } public String value() { return v; } public void set(String x) { v = x; } }
  static final class C implements ColorOption { final String n; int v; final boolean accent; C(String n, int v, boolean accent) { this.n = n; this.v = v; this.accent = accent; }
    public String name() { return n; } public int value() { return v; } public void set(int x) { v = x; }
    public int[] swatches() { return accent ? new int[] {0xFFDF91AA, 0xFFB3A0D2, 0xFFE39A6E, 0xFF93B47E, 0xFF8FB4DE} : new int[] {0xFFDF91AA, 0xFFB3A0D2, 0xFF8FB4DE, 0xFF93B47E, 0xFFE39A6E, 0xFFF2D28C, 0xFFFFFFFF}; } }
  public FakeModel() {
    { List<Module> l = new ArrayList<>(); cats.add(new Cat("HUD", ModuleIcons.forCategory("HUD"), l));
      { Mod m = new Mod("Watermark", "name + fps", true, true, null); l.add(m);
        m.opts.add(new B("FPS", "frame counter", true));
        m.opts.add(new B("Graph", "fps sparkline", true));
      }
      { Mod m = new Mod("Keystrokes", "WASD + mouse", true, true, null); l.add(m);
      }
      { Mod m = new Mod("Info", "coords, ping", true, true, null); l.add(m);
        m.opts.add(new B("Coords", "position + ping", true));
        m.opts.add(new B("Session", "play time", true));
      }
      { Mod m = new Mod("Armor", "durability", true, true, null); l.add(m);
      }
      { Mod m = new Mod("Effects", "potions", true, true, null); l.add(m);
      }
      { Mod m = new Mod("Edit layout", "drag blocks", false, false, "Open"); l.add(m);
      }
      { Mod m = new Mod("Target HUD", "current aura target", true, true, null); l.add(m);
        m.opts.add(new B("Model", "entity preview", true));
        m.opts.add(new B("Distance", "target range", true));
      }
    }
    { List<Module> l = new ArrayList<>(); cats.add(new Cat("Visuals", ModuleIcons.forCategory("Visuals"), l));
      { Mod m = new Mod("ESP", "entity boxes", false, true, null); l.add(m);
        m.opts.add(new B("Boxes", "hitbox corners", true));
        m.opts.add(new B("Nametags", "name + range", true));
        m.opts.add(new B("Health", "side bar", true));
        m.opts.add(new B("Off-screen", "edge markers", false));
        m.opts.add(new C("Color", 0xFFE8B4C8, false));
        m.opts.add(new S("Opacity", 0.85f, 0.05f, 1.0f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new S("Range", 64.0f, 8.0f, 128.0f, v -> Math.round(v) + " m"));
      }
      { Mod m = new Mod("Tracers", "from crosshair", false, true, null); l.add(m);
        m.opts.add(new B("Distance", "range pills", true));
        m.opts.add(new C("Color", 0xFFE8B4C8, false));
        m.opts.add(new S("Opacity", 0.72f, 0.05f, 1.0f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new S("Range", 96.0f, 16.0f, 160.0f, v -> Math.round(v) + " m"));
      }
      { Mod m = new Mod("Hit marker", "attack feedback", true, true, null); l.add(m);
        m.opts.add(new S("Size", 6.0f, 3.0f, 12.0f, v -> String.valueOf(Math.round(v))));
      }
      { Mod m = new Mod("Damage tint", "soft damage frame", true, true, null); l.add(m);
        m.opts.add(new S("Opacity", 0.28f, 0.05f, 0.65f, v -> Math.round(v * 100) + "%"));
      }
      { Mod m = new Mod("Crosshair", "adaptive aim point", true, true, null); l.add(m);
        m.opts.add(new S("Size", 4.0f, 2.0f, 9.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Gap", 3.0f, 1.0f, 7.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new B("Dynamic", "target + cooldown response", true));
      }
      { Mod m = new Mod("World time", "visual sky preset", false, true, null); l.add(m);
        m.opts.add(new M("Time", List.of("Day", "Sunset", "Night", "Midnight"), "Sunset"));
      }
      { Mod m = new Mod("Target glow", "aura target halo", true, true, null); l.add(m);
        m.opts.add(new S("Opacity", 0.42f, 0.1f, 0.8f, v -> Math.round(v * 100) + "%"));
      }
      { Mod m = new Mod("Sakura bloom", "petals on combat", true, true, null); l.add(m);
        m.opts.add(new M("Amount", List.of("Low", "Normal", "Rich"), "Normal"));
        m.opts.add(new B("Hit bloom", "petals on attack", true));
        m.opts.add(new B("Kill bloom", "large finishing bloom", true));
        m.opts.add(new B("Wind", "inherit sakura drift", true));
      }
      { Mod m = new Mod("Threat constellation", "radial threat map", false, true, null); l.add(m);
        m.opts.add(new S("Radius", 54.0f, 32.0f, 96.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Range", 48.0f, 12.0f, 128.0f, v -> Math.round(v) + " m"));
        m.opts.add(new S("Markers", 14.0f, 4.0f, 30.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new B("Threat pulse", "nearby enemies breathe", true));
        m.opts.add(new B("Constellations", "connect nearby markers", true));
        m.opts.add(new B("Target connection", "line to aura target", true));
      }
      { Mod m = new Mod("Intent lens", "target movement intent", false, true, null); l.add(m);
        m.opts.add(new S("Prediction", 4.0f, 1.0f, 8.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new B("Attack window", "ready + in range", true));
        m.opts.add(new S("Opacity", 0.58f, 0.15f, 0.9f, v -> Math.round(v * 100) + "%"));
      }
      { Mod m = new Mod("Memory echo", "recent movement trail", false, true, null); l.add(m);
        m.opts.add(new M("Entities", List.of("Target", "Self", "Both"), "Target"));
        m.opts.add(new M("Style", List.of("Ribbon", "Petals"), "Ribbon"));
        m.opts.add(new S("Echoes", 6.0f, 3.0f, 10.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Lifetime", 1.1f, 0.4f, 2.2f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
        m.opts.add(new B("Moving only", "hide stationary echoes", true));
      }
      { Mod m = new Mod("Block highlight", "sakura block selection", true, true, null); l.add(m);
        m.opts.add(new M("Style", List.of("Outline", "Fill", "Both"), "Both"));
        m.opts.add(new S("Opacity", 0.42f, 0.08f, 0.8f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new B("Pulse", "calm opacity breath", true));
      }
      { Mod m = new Mod("Pearl prediction", "ender pearl trajectory", false, true, null); l.add(m);
        m.opts.add(new S("Flight ticks", 90.0f, 30.0f, 160.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new B("Only holding", "show with pearl in hand", true));
        m.opts.add(new B("Distance", "landing range label", true));
        m.opts.add(new S("Opacity", 0.62f, 0.15f, 0.9f, v -> Math.round(v * 100) + "%"));
      }
      { Mod m = new Mod("Projectile trails", "projectile movement trails", false, true, null); l.add(m);
        m.opts.add(new M("Style", List.of("Ribbon", "Echo", "Petals"), "Ribbon"));
        m.opts.add(new S("Lifetime", 1.4f, 0.4f, 3.0f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
        m.opts.add(new S("Range", 96.0f, 24.0f, 192.0f, v -> Math.round(v) + " m"));
        m.opts.add(new B("Pearls", "ender pearls", true));
        m.opts.add(new B("Arrows", "arrows and spectral arrows", true));
        m.opts.add(new B("Throwables", "snowballs and potions", true));
        m.opts.add(new B("Tridents", "thrown tridents", true));
      }
      { Mod m = new Mod("Item animations", "first-person hand scene", false, true, null); l.add(m);
        m.opts.add(new M("Style", List.of("Vanilla", "Compact", "Sakura"), "Sakura"));
        m.opts.add(new S("Scale", 0.92f, 0.65f, 1.25f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new S("X offset", 0.0f, -0.6f, 0.6f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
        m.opts.add(new S("Y offset", -0.04f, -0.6f, 0.6f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
        m.opts.add(new S("Z offset", 0.0f, -0.6f, 0.6f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
        m.opts.add(new S("Swing accent", 0.28f, 0.0f, 1.0f, v -> Math.round(v * 100) + "%"));
      }
      { Mod m = new Mod("Camera effects", "motion accessibility", false, true, null); l.add(m);
        m.opts.add(new M("Hurt cam", List.of("Vanilla", "Soft", "Off"), "Soft"));
        m.opts.add(new M("View bob", List.of("Vanilla", "Off"), "Vanilla"));
        m.opts.add(new S("Portal effect", 0.35f, 0.0f, 1.0f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new B("Static sprint FOV", "remove sprint zoom", false));
        m.opts.add(new B("Water overlay", "vanilla underwater texture", true));
      }
      { Mod m = new Mod("Storage ESP", "nearby containers", false, true, null); l.add(m);
        m.opts.add(new M("Style", List.of("Corners", "Markers"), "Corners"));
        m.opts.add(new S("Range", 72.0f, 16.0f, 128.0f, v -> Math.round(v) + " m"));
        m.opts.add(new S("Markers", 48.0f, 8.0f, 96.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Opacity", 0.56f, 0.1f, 0.9f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new B("Labels", "name + distance", true));
        m.opts.add(new B("Chests", "normal + trapped", true));
        m.opts.add(new B("Ender chests", "ender storage", true));
        m.opts.add(new B("Barrels", "barrels", true));
        m.opts.add(new B("Shulkers", "all colors", true));
        m.opts.add(new B("Furnaces", "furnace + smoker + blast", false));
        m.opts.add(new B("Hoppers", "hoppers", false));
      }
      { Mod m = new Mod("World color", "weather ambience", false, true, null); l.add(m);
        m.opts.add(new M("Mood", List.of("Natural", "Sakura", "Moonlit", "Ashen", "Custom"), "Sakura"));
        m.opts.add(new C("Custom color", 0xFFE8A0B4, false));
        m.opts.add(new S("Color strength", 0.42f, 0.0f, 1.0f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new S("Atmospheric fog", 0.18f, 0.0f, 0.65f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new B("Weather ambience", "rain deepens tint + fog", true));
      }
    }
    { List<Module> l = new ArrayList<>(); cats.add(new Cat("Combat", ModuleIcons.forCategory("Combat"), l));
      { Mod m = new Mod("KillAura", "auto attack", false, true, null); l.add(m);
        m.opts.add(new S("Range", 3.0f, 2.0f, 4.5f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
        m.opts.add(new M("Rotation", List.of("Silent", "Smooth", "Snap"), "Silent"));
        m.opts.add(new S("Rot speed", 55.0f, 10.0f, 180.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new B("Random center", "vary aim point", true));
        m.opts.add(new S("FOV", 120.0f, 30.0f, 360.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Min CPS", 8.0f, 1.0f, 20.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Max CPS", 12.0f, 1.0f, 20.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new M("Combat timing", List.of("Legacy", "Modern", "Hybrid"), "Modern"));
        m.opts.add(new S("Cooldown ready", 0.92f, 0.8f, 1.0f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new B("Wall check", "need line of sight", true));
        m.opts.add(new M("Priority", List.of("Distance", "Health", "Angle"), "Distance"));
        m.opts.add(new S("Switch delay", 4.0f, 0.0f, 20.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Predict", 1.0f, 0.0f, 4.0f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
      }
      { Mod m = new Mod("Aim Assist", "gentle manual aim", false, true, null); l.add(m);
        m.opts.add(new S("Range", 4.0f, 2.0f, 6.0f, v -> String.format(java.util.Locale.ROOT, "%.1f", v)));
        m.opts.add(new S("FOV", 70.0f, 20.0f, 140.0f, v -> String.valueOf(Math.round(v))));
        m.opts.add(new S("Assist speed", 18.0f, 4.0f, 45.0f, v -> String.valueOf(Math.round(v))));
      }
      { Mod m = new Mod("TriggerBot", "attack under crosshair", false, true, null); l.add(m);
        m.opts.add(new S("Cooldown ready", 0.92f, 0.8f, 1.0f, v -> Math.round(v * 100) + "%"));
      }
      { Mod m = new Mod("AutoWeapon", "best hotbar weapon", false, true, null); l.add(m);
      }
      { Mod m = new Mod("AutoTotem", "emergency offhand", false, true, null); l.add(m);
        m.opts.add(new S("Health", 8.0f, 2.0f, 20.0f, v -> String.valueOf(Math.round(v))));
      }
      { Mod m = new Mod("Criticals", "natural jump criticals", false, true, null); l.add(m);
      }
    }
    { List<Module> l = new ArrayList<>(); cats.add(new Cat("Client", ModuleIcons.forCategory("Client"), l));
      { Mod m = new Mod("Dark mode", "night palette", false, true, null); l.add(m);
      }
      { Mod m = new Mod("Appearance", "accent + opacity", false, false, null); l.add(m);
        m.opts.add(new C("Accent", 0xFFE8A0B4, true));
        m.opts.add(new S("HUD opacity", 0.85f, 0.0f, 1.0f, v -> Math.round(v * 100) + "%"));
        m.opts.add(new M("Particles", List.of("Off", "Low", "Normal"), "Normal"));
        m.opts.add(new M("Sakura wind", List.of("Calm", "Windy"), "Calm"));
        m.opts.add(new M("Quotes", List.of("Off", "Menu", "All"), "All"));
        m.opts.add(new B("Reduced motion", "calmer UI animation", false));
        m.opts.add(new B("Player preview", "cursor-following model", true));
        m.opts.add(new M("Companion", List.of("Cursor", "Context"), "Context"));
        m.opts.add(new B("Idle reactions", "looks around when idle", true));
      }
      { Mod m = new Mod("Main menu", "custom screen", true, true, null); l.add(m);
      }
      { Mod m = new Mod("Focus mode", "combat-only HUD", false, true, null); l.add(m);
      }
      { Mod m = new Mod("Visual profiles", "apply a visual preset", false, false, "Open"); l.add(m);
        m.opts.add(new M("Profile", List.of("Normal", "Performance", "Calm", "Combat", "Cinematic"), "Normal"));
      }
    }
  }
  Module find(String name) { for (Category c : cats) for (Module m : c.modules()) if (m.name().equals(name)) return m; return null; }
}
