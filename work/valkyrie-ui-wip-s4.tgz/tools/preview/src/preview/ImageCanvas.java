package preview;

import com.valkyrie.client.ui.render.Canvas;
import com.valkyrie.client.ui.render.Mask;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayDeque;
import java.util.Deque;
import javax.imageio.ImageIO;

/** Программный холст: то же «source over» смешивание в sRGB, что у GUI Minecraft. */
public final class ImageCanvas implements Canvas {
    final int w, h; final float scale; final int[] px;
    private int cx0, cy0, cx1, cy1;
    private final Deque<int[]> clips = new ArrayDeque<>();
    public long ops;

    public ImageCanvas(int w, int h, float scale) {
        this.w = w; this.h = h; this.scale = scale; this.px = new int[w * h];
        cx0 = 0; cy0 = 0; cx1 = w; cy1 = h;
    }
    @Override public float scale() { return scale; }
    @Override public int width() { return w; }
    @Override public int height() { return h; }

    private void blend(int i, int argb, int a) {
        if (a <= 0) return;
        int d = px[i];
        if (a >= 255) { px[i] = 0xFF000000 | (argb & 0xFFFFFF); return; }
        int ia = 255 - a;
        int r = (((argb >> 16) & 0xFF) * a + ((d >> 16) & 0xFF) * ia + 127) / 255;
        int g = (((argb >> 8) & 0xFF) * a + ((d >> 8) & 0xFF) * ia + 127) / 255;
        int b = ((argb & 0xFF) * a + (d & 0xFF) * ia + 127) / 255;
        px[i] = 0xFF000000 | (r << 16) | (g << 8) | b;
    }
    @Override public void fill(int x0, int y0, int x1, int y1, int argb) {
        ops++;
        int a = argb >>> 24; if (a == 0) return;
        int ax = Math.max(x0, cx0), ay = Math.max(y0, cy0), bx = Math.min(x1, cx1), by = Math.min(y1, cy1);
        for (int y = ay; y < by; y++) for (int x = ax; x < bx; x++) blend(y * w + x, argb, a);
    }
    @Override public void gradient(int x0, int y0, int x1, int y1, int top, int bottom) {
        ops++;
        int ay = Math.max(y0, cy0), by = Math.min(y1, cy1), ax = Math.max(x0, cx0), bx = Math.min(x1, cx1);
        for (int y = ay; y < by; y++) {
            float t = (y - y0 + 0.5f) / Math.max(1, y1 - y0);
            int c = mix(top, bottom, t);
            for (int x = ax; x < bx; x++) blend(y * w + x, c, c >>> 24);
        }
    }
    static int mix(int a, int b, float t) {
        int aa = Math.round((a >>> 24) + ((b >>> 24) - (a >>> 24)) * t);
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bb = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (r << 16) | (g << 8) | bb;
    }
    @Override public void mask(Mask m, int dx, int dy, int dw, int dh, int sx, int sy, int sw, int sh, int argb) {
        ops++;
        int ca = argb >>> 24; if (ca == 0 || dw <= 0 || dh <= 0) return;
        int ax = Math.max(dx, cx0), ay = Math.max(dy, cy0), bx = Math.min(dx + dw, cx1), by = Math.min(dy + dh, cy1);
        for (int y = ay; y < by; y++) {
            int my = sy + (int) Math.floor((y - dy + 0.5) * sh / dh);
            if (my < 0 || my >= m.height) continue;
            for (int x = ax; x < bx; x++) {
                int mx = sx + (int) Math.floor((x - dx + 0.5) * sw / dw);
                if (mx < 0 || mx >= m.width) continue;
                int cov = m.alpha[my * m.width + mx] & 0xFF;
                if (cov == 0) continue;
                blend(y * w + x, argb, (ca * cov + 127) / 255);
            }
        }
    }
    @Override public void pushClip(int x0, int y0, int x1, int y1) {
        clips.push(new int[] {cx0, cy0, cx1, cy1});
        cx0 = Math.max(cx0, x0); cy0 = Math.max(cy0, y0); cx1 = Math.min(cx1, x1); cy1 = Math.min(cy1, y1);
    }
    @Override public void popClip() {
        int[] c = clips.pop(); cx0 = c[0]; cy0 = c[1]; cx1 = c[2]; cy1 = c[3];
    }
    public void clear(int argb) { java.util.Arrays.fill(px, argb | 0xFF000000); }
    public void backdrop(int[] src) { System.arraycopy(src, 0, px, 0, px.length); }
    public void save(String path) throws Exception {
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        img.setRGB(0, 0, w, h, px, 0, w);
        ImageIO.write(img, "png", new File(path));
    }
}
