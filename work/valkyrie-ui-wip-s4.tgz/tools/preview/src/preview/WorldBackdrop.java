package preview;

import java.util.Random;

/**
 * Псевдо-Minecraft от первого лица для превью HUD: пиксельное небо с облаками,
 * поле травы в перспективе (текстура 16×16 по блокам), холмы и деревья у
 * горизонта, туман. Плюс ванильный HUD (хотбар, сердца, голод, опыт, прицел).
 */
final class WorldBackdrop {
    private WorldBackdrop() {
    }

    static int[] make(int W, int H, float sc, boolean night) {
        int[] px = new int[W * H];
        Random rnd = new Random(7);
        int horizon = (int) (H * 0.50f);
        int skyTop = night ? 0x0A0F24 : 0x6E9EFF;
        int skyLow = night ? 0x1B2547 : 0xBCD3FF;
        float light = night ? 0.32f : 1.0f;
        // Небо.
        for (int y = 0; y < horizon; y++) {
            float t = (float) y / horizon;
            int c = mix(skyTop, skyLow, (float) Math.pow(t, 1.6));
            for (int x = 0; x < W; x++) {
                px[y * W + x] = c;
            }
        }
        if (night) {
            for (int i = 0; i < W * H / 4000; i++) {
                int x = rnd.nextInt(W);
                int y = rnd.nextInt(horizon - 20);
                int s = Math.max(1, Math.round(sc * 0.5f));
                rect(px, W, H, x, y, s, s, mix(0xFFFFFF, skyTop, rnd.nextFloat() * 0.5f));
            }
            int m = Math.round(16 * sc);
            rect(px, W, H, (int) (W * 0.22f), (int) (H * 0.12f), m, m, 0xE8ECF5);
            rect(px, W, H, (int) (W * 0.22f) + m / 4, (int) (H * 0.12f) + m / 3, m / 4, m / 4, 0xC9CFDD);
        } else {
            int s = Math.round(24 * sc);
            rect(px, W, H, (int) (W * 0.76f), (int) (H * 0.10f), s, s, 0xFFF8D6);
            rect(px, W, H, (int) (W * 0.76f) + s / 6, (int) (H * 0.10f) + s / 6, s * 2 / 3, s * 2 / 3, 0xFFFFF2);
            // Плоские облака Minecraft: прямоугольные массивы.
            int cell = Math.round(10 * sc);
            for (int i = 0; i < 9; i++) {
                int cx = rnd.nextInt(W);
                int cy = (int) (H * (0.04f + rnd.nextFloat() * 0.22f));
                int cw = 3 + rnd.nextInt(6);
                int ch = 1 + rnd.nextInt(2);
                for (int a = 0; a < cw; a++) {
                    for (int b = 0; b < ch; b++) {
                        if (rnd.nextFloat() < 0.85f) {
                            rectBlend(px, W, H, cx + a * cell, cy + b * cell / 2, cell, cell / 2, 0xFFFFFF, 0.82f);
                        }
                    }
                }
            }
        }
        // Земля в перспективе.
        int[] grass = texture(rnd, 0x5E9E3A, 0x4A8530, 0x76B54A);
        int fog = skyLow;
        float camH = 1.62f;
        float focal = H * 0.9f;
        for (int y = horizon; y < H; y++) {
            float dy = (y - horizon + 0.5f);
            float z = camH * focal / dy;
            float f = Math.min(1.0f, z / 60.0f);
            for (int x = 0; x < W; x++) {
                float wx = (x - W / 2.0f) * z / focal + 0.37f;
                float wz = z + 3.7f;
                int tx = Math.floorMod((int) Math.floor(wx * 16), 16);
                int tz = Math.floorMod((int) Math.floor(wz * 16), 16);
                int c = shade(grass[tz * 16 + tx], light * (0.86f + 0.14f * (Math.floorMod((int) Math.floor(wx) * 31 + (int) Math.floor(wz) * 17, 7) / 6.0f)));
                px[y * W + x] = mix(c, fog, (float) Math.pow(f, 1.3) * 0.92f);
            }
        }
        // Холмы у горизонта (блочные ступени).
        int block = Math.max(2, Math.round(4 * sc));
        int hill = mix(night ? 0x22351F : 0x5C8C47, fog, 0.55f);
        int hill2 = mix(night ? 0x1A2A18 : 0x4F7D3C, fog, 0.35f);
        int hgt = 0;
        for (int x = 0; x < W; x += block) {
            hgt = Math.max(0, Math.min(12, hgt + rnd.nextInt(3) - 1));
            rect(px, W, H, x, horizon - hgt * block, block, hgt * block, hill);
        }
        hgt = 3;
        for (int x = W / 3; x < W; x += block * 2) {
            hgt = Math.max(0, Math.min(7, hgt + rnd.nextInt(3) - 1));
            rect(px, W, H, x, horizon - hgt * block * 2 + block, block * 2, hgt * block * 2, hill2);
        }
        // Деревья на разной дистанции.
        int[] leaves = texture(rnd, 0x3F7F2A, 0x2F6A20, 0x55973A);
        int[] bark = texture(rnd, 0x6B5131, 0x5A4228, 0x7D6340);
        float[][] trees = {{-9.5f, 14f}, {6.0f, 22f}, {-3.0f, 34f}, {13f, 30f}, {-20f, 26f}, {2.5f, 48f}, {22f, 18f}};
        java.util.Arrays.sort(trees, (p, q) -> Float.compare(q[1], p[1]));
        for (float[] t : trees) {
            float z = t[1];
            float s = focal / z;
            int baseY = (int) (horizon + camH * focal / z);
            int cx = (int) (W / 2.0f + t[0] * s);
            float f = Math.min(1.0f, z / 60.0f) * 0.9f;
            drawCube(px, W, H, cx - (int) (0.5f * s), baseY - (int) (4 * s), (int) s, (int) (4 * s), bark, light, fog, f);
            drawCube(px, W, H, cx - (int) (2.5f * s), baseY - (int) (6.5f * s), (int) (5 * s), (int) (3 * s), leaves, light, fog, f);
            drawCube(px, W, H, cx - (int) (1.5f * s), baseY - (int) (7.5f * s), (int) (3 * s), (int) (1.2f * s), leaves, light, fog, f);
        }
        if (night) {
            // Факел: тёплое пятно света справа внизу.
            int tx = (int) (W * 0.70f);
            int ty = (int) (H * 0.80f);
            for (int y = 0; y < H; y++) {
                for (int x = 0; x < W; x++) {
                    double d = Math.hypot(x - tx, (y - ty) * 1.4) / (H * 0.35);
                    if (d < 1) {
                        px[y * W + x] = mix(px[y * W + x], 0xFFB45A, (float) (0.22 * (1 - d) * (1 - d)));
                    }
                }
            }
        }
        vanillaHud(px, W, H, sc);
        return px;
    }

    private static void drawCube(int[] px, int W, int H, int x, int y, int w, int h, int[] tex, float light, int fog, float f) {
        for (int yy = 0; yy < h; yy++) {
            for (int xx = 0; xx < w; xx++) {
                int tx = (int) ((float) xx / Math.max(1, w) * 16 * Math.max(1, w / Math.max(1f, h / 4f) / 4f)) & 15;
                int tz = (int) ((float) yy / Math.max(1, h) * 16 * Math.max(1, h / (float) Math.max(1, w))) & 15;
                int c = shade(tex[tz * 16 + tx], light * (xx < w / 6 ? 0.8f : 1.0f));
                int X = x + xx;
                int Y = y + yy;
                if (X >= 0 && X < W && Y >= 0 && Y < H) {
                    px[Y * W + X] = mix(c, fog, f);
                }
            }
        }
    }

    /** Ванильные элементы в GUI-координатах × масштаб. */
    private static void vanillaHud(int[] px, int W, int H, float sc) {
        float gw = W / sc;
        float gh = H / sc;
        // Прицел.
        int cx = (int) (W / 2f);
        int cy = (int) (H / 2f);
        int len = Math.round(4.5f * sc);
        int th = Math.max(1, Math.round(sc * 0.5f));
        rectBlend(px, W, H, cx - len, cy - th / 2, len * 2, th, 0xF0F0F0, 0.85f);
        rectBlend(px, W, H, cx - th / 2, cy - len, th, len * 2, 0xF0F0F0, 0.85f);
        // Хотбар 182×22.
        float hx = gw / 2 - 91;
        float hy = gh - 22;
        g(px, W, H, sc, hx, hy, 182, 22, 0x000000, 0.45f);
        for (int i = 0; i < 9; i++) {
            float sx = hx + 1 + i * 20;
            g(px, W, H, sc, sx, hy + 1, 20, 20, 0x8B8B8B, 0.35f);
            g(px, W, H, sc, sx + 2, hy + 3, 16, 16, 0x373737, 0.30f);
        }
        g(px, W, H, sc, hx - 1 + 2 * 20, hy - 1, 24, 2, 0xFFFFFF, 0.9f);
        g(px, W, H, sc, hx - 1 + 2 * 20, hy + 21, 24, 2, 0xFFFFFF, 0.9f);
        g(px, W, H, sc, hx - 1 + 2 * 20, hy - 1, 2, 24, 0xFFFFFF, 0.9f);
        g(px, W, H, sc, hx + 21 + 2 * 20, hy - 1, 2, 24, 0xFFFFFF, 0.9f);
        // Опыт.
        g(px, W, H, sc, hx, gh - 29, 182, 5, 0x000000, 0.7f);
        g(px, W, H, sc, hx + 1, gh - 28, 74, 3, 0x80FF20, 1f);
        // Сердца и голод.
        String[] heart = {".##.##.", "#######", "#######", ".#####.", "..###..", "...#..."};
        for (int i = 0; i < 10; i++) {
            sprite(px, W, H, sc, hx + i * 8 + 1, gh - 38, heart, i < 7 ? 0xE0202C : 0x4A1A1A);
        }
        String[] food = {"..##...", ".####..", "######.", "######.", ".####..", "...##.."};
        for (int i = 0; i < 10; i++) {
            sprite(px, W, H, sc, hx + 182 - 9 - i * 8 + 1, gh - 38, food, 0xB06A2C);
        }
        String[] armor = {"##.##..", "#####..", "#####..", ".###...", ".###...", "......."};
        for (int i = 0; i < 10; i++) {
            sprite(px, W, H, sc, hx + i * 8 + 1, gh - 48, armor, i < 8 ? 0xC8D0D8 : 0x555555);
        }
    }

    private static void sprite(int[] px, int W, int H, float sc, float x, float y, String[] rows, int color) {
        for (int r = 0; r < rows.length; r++) {
            for (int c = 0; c < rows[r].length(); c++) {
                if (rows[r].charAt(c) == '#') {
                    g(px, W, H, sc, x + c, y + r, 1, 1, color, 1f);
                }
            }
        }
        // Чёрная обводка как у ванильных спрайтов (упрощённо — тень снизу).
    }

    private static void g(int[] px, int W, int H, float sc, float x, float y, float w, float h, int rgb, float a) {
        rectBlend(px, W, H, Math.round(x * sc), Math.round(y * sc), Math.round(w * sc), Math.round(h * sc), rgb, a);
    }

    static int[] texture(Random rnd, int base, int dark, int lightC) {
        int[] t = new int[256];
        for (int i = 0; i < 256; i++) {
            float r = rnd.nextFloat();
            t[i] = r < 0.25f ? dark : r > 0.8f ? lightC : mix(base, r < 0.5f ? dark : lightC, rnd.nextFloat() * 0.3f);
        }
        return t;
    }

    static void rect(int[] px, int W, int H, int x, int y, int w, int h, int rgb) {
        for (int yy = Math.max(0, y); yy < Math.min(H, y + h); yy++) {
            for (int xx = Math.max(0, x); xx < Math.min(W, x + w); xx++) {
                px[yy * W + xx] = rgb;
            }
        }
    }

    static void rectBlend(int[] px, int W, int H, int x, int y, int w, int h, int rgb, float a) {
        for (int yy = Math.max(0, y); yy < Math.min(H, y + h); yy++) {
            for (int xx = Math.max(0, x); xx < Math.min(W, x + w); xx++) {
                px[yy * W + xx] = mix(px[yy * W + xx], rgb, a);
            }
        }
    }

    static int shade(int c, float k) {
        int r = Math.min(255, (int) (((c >> 16) & 255) * k));
        int g = Math.min(255, (int) (((c >> 8) & 255) * k));
        int b = Math.min(255, (int) ((c & 255) * k));
        return (r << 16) | (g << 8) | b;
    }

    static int mix(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
