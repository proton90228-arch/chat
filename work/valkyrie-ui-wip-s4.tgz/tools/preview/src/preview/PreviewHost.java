package preview;

import com.valkyrie.client.ui.hud.HudState;
import com.valkyrie.client.ui.hud.HudView;
import com.valkyrie.client.ui.render.Ui;

/** Пиксель-арт вместо предметов и модели — только для превью. */
final class PreviewHost implements HudView.Host {
    private static final String[][] ARMOR = {
        {"................", "................", "....########....", "...#cccccccc#...", "..#ccwwwwwwcc#..", "..#cw######wc#..",
         "..#cw#....#wc#..", "..#cc#....#cc#..", "..###......###..", "................", "................", "................",
         "................", "................", "................", "................"},
        {"................", "..###......###..", ".#cc#......#cc#.", ".#cwc######cwc#.", ".#cwwcccccccwc#.", "..##cwwwwwwc##..",
         "...#cccccccc#...", "...#cwwwwwwc#...", "...#cccccccc#...", "...#cwwwwwwc#...", "...#cccccccc#...", "...##########...",
         "................", "................", "................", "................"},
        {"................", "...##########...", "...#cccccccc#...", "...#cwwwwwwc#...", "...#ccc##ccc#...", "...#cwc##cwc#...",
         "...#ccc##ccc#...", "...#cwc##cwc#...", "...#ccc##ccc#...", "...#cwc##cwc#...", "...####..####...", "................",
         "................", "................", "................", "................"},
        {"................", "................", "................", "................", "................", "...###....###...",
         "...#c#....#c#...", "...#w#....#w#...", "...#c#....#c#...", "..#cc#....#cc#..", ".#cwc#....#cwc#.", ".######..######.",
         "................", "................", "................", "................"}
    };

    @Override
    public boolean item(Ui ui, HudState.Armor armor, float x, float y) {
        String[] rows = ARMOR[Math.max(0, Math.min(3, armor.slot()))];
        for (int r = 0; r < 16; r++) {
            for (int c = 0; c < 16; c++) {
                char ch = rows[r].charAt(c);
                int color = switch (ch) {
                    case '#' -> 0xFF0E3B3A;
                    case 'c' -> 0xFF2BC7AD;
                    case 'w' -> 0xFFA6F5E6;
                    default -> 0;
                };
                if (color != 0) {
                    ui.rect(x + c, y + r + 2, 1, 1, color);
                }
            }
        }
        return true;
    }

    @Override
    public void entity(Ui ui, HudState.Target target, float x, float y, float w, float h) {
        // Голова и плечи зомби 8×8 «пикселей».
        String[] face = {"gggggggg", "gGggggGg", "gggggggg", "gKKggKKg", "gggggggg", "ggGddGgg", "gggddggg", "gGggggGg"};
        float px = 3.0f;
        float fx = x + (w - 8 * px) / 2.0f;
        float fy = y + 4.0f;
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                int color = switch (face[r].charAt(c)) {
                    case 'G' -> 0xFF4F7A3A;
                    case 'K' -> 0xFF1E2B19;
                    case 'd' -> 0xFF3B5A2B;
                    default -> 0xFF6A9E4F;
                };
                ui.rect(fx + c * px, fy + r * px, px, px, color);
            }
        }
        ui.rect(x + 6.0f, fy + 8 * px + 1.0f, w - 12.0f, y + h - (fy + 8 * px + 1.0f), 0xFF2E7F8C);
    }
}
