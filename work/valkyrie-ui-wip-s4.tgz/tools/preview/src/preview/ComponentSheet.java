package preview;

import com.valkyrie.client.ui.color.*;
import com.valkyrie.client.ui.icon.Icon;
import com.valkyrie.client.ui.motion.Motion;
import com.valkyrie.client.ui.render.Ui;
import com.valkyrie.client.ui.text.TypeStyle;
import com.valkyrie.client.ui.theme.*;

public final class ComponentSheet {
    public static void main(String[] a) throws Exception {
        for (boolean dark : new boolean[] {false, true}) for (float sc : new float[] {2f, 3f}) render(dark, sc, a[0]);
    }
    static void render(boolean dark, float sc, String dir) throws Exception {
        int W = (int) (520 * sc), H = (int) (330 * sc);
        ImageCanvas cv = new ImageCanvas(W, H, sc);
        UiTheme.set(Scheme.Preset.SAKURA.seed, dark);
        Motion.beginFrame();
        Ui ui = Ui.get().begin(cv);
        cv.clear(UiTheme.c(Role.SURFACE_CONTAINER));
        // Роли.
        Role[] show = {Role.PRIMARY, Role.PRIMARY_CONTAINER, Role.SECONDARY_CONTAINER, Role.TERTIARY_CONTAINER, Role.SURFACE_CONTAINER_LOWEST, Role.SURFACE_CONTAINER_HIGH, Role.SURFACE_CONTAINER_HIGHEST, Role.OUTLINE_VARIANT, Role.ERROR, Role.SUCCESS};
        for (int i = 0; i < show.length; i++) { ui.round(10 + i * 30, 10, 26, 18, 6, UiTheme.c(show[i])); }
        // Карточки с тенями всех уровней.
        Elevation[] lv = Elevation.values();
        for (int i = 1; i < lv.length; i++) {
            float x = 10 + (i - 1) * 62, y = 40;
            ui.elevation(x, y, 52, 40, 12, lv[i]);
            ui.round(x, y, 52, 40, 12, UiTheme.c(Role.SURFACE_CONTAINER_LOWEST));
            ui.text(TypeStyle.LABEL_MEDIUM, "Level " + i, x + 8, y + 6, UiTheme.c(Role.ON_SURFACE_VARIANT));
        }
        // Пилюли, кольца, обводки.
        ui.pill(330, 40, 60, 16, UiTheme.c(Role.PRIMARY));
        ui.text(TypeStyle.LABEL_LARGE, "Готово", 343, 43, UiTheme.c(Role.ON_PRIMARY));
        ui.pill(330, 62, 60, 16, UiTheme.c(Role.SECONDARY_CONTAINER));
        ui.text(TypeStyle.LABEL_LARGE, "Tonal", 346, 65, UiTheme.c(Role.ON_SECONDARY_CONTAINER));
        ui.outline(396, 40, 60, 16, 8, 0.5f, UiTheme.c(Role.OUTLINE));
        ui.text(TypeStyle.LABEL_LARGE, "Outline", 409, 43, UiTheme.c(Role.PRIMARY));
        ui.circle(410, 70, 7, UiTheme.c(Role.PRIMARY));
        ui.ring(430, 70, 7, 1, UiTheme.c(Role.PRIMARY));
        ui.circle(450, 70, 3, UiTheme.c(Role.TERTIARY));
        // Переключатели (M3): выкл/вкл.
        float sx = 470;
        ui.pill(sx, 40, 26, 15, UiTheme.c(Role.SURFACE_CONTAINER_HIGHEST)); ui.outline(sx, 40, 26, 15, 7.5f, 1f, UiTheme.c(Role.OUTLINE)); ui.circle(sx + 7.5f, 47.5f, 4, UiTheme.c(Role.OUTLINE));
        ui.pill(sx, 60, 26, 15, UiTheme.c(Role.PRIMARY)); ui.circle(sx + 18.5f, 67.5f, 6, UiTheme.c(Role.ON_PRIMARY)); ui.icon(Icon.CHECK, sx + 14.5f, 63.5f, 8, UiTheme.c(Role.ON_PRIMARY_CONTAINER));
        // Типографика.
        float ty = 92;
        TypeStyle[] st = {TypeStyle.DISPLAY_SMALL, TypeStyle.HEADLINE_MEDIUM, TypeStyle.HEADLINE_SMALL, TypeStyle.TITLE_LARGE, TypeStyle.TITLE_MEDIUM, TypeStyle.TITLE_SMALL, TypeStyle.BODY_LARGE, TypeStyle.BODY_MEDIUM, TypeStyle.BODY_SMALL, TypeStyle.LABEL_LARGE, TypeStyle.LABEL_MEDIUM, TypeStyle.LABEL_SMALL};
        for (TypeStyle s : st) {
            ui.rect(10, ty, 2, s.lineHeight, UiTheme.c(Role.PRIMARY, 0.35f));
            ui.text(s, s.name().toLowerCase() + " · Valkyrie Сакура AVATAR 0123", 16, ty, UiTheme.c(Role.ON_SURFACE));
            ty += s.lineHeight + 2;
        }
        // Иконки.
        Icon[] icons = Icon.values();
        for (int i = 0; i < icons.length; i++) {
            float x = 300 + (i % 11) * 19, y = 96 + (i / 11) * 19;
            ui.round(x, y, 16, 16, 5, UiTheme.c(Role.SURFACE_CONTAINER_HIGH));
            ui.icon(icons[i], x + 2, y + 2, 12, UiTheme.c(Role.ON_SURFACE_VARIANT));
        }
        // Слайдер M3 Expressive.
        float slx = 300, sly = 210, slw = 200, val = 0.62f;
        float hx = slx + slw * val;
        ui.round(slx, sly, hx - slx - 3, 8, 4, 2, 2, 4, UiTheme.c(Role.PRIMARY));
        ui.round(hx + 3, sly, slx + slw - hx - 3, 8, 2, 4, 4, 2, UiTheme.c(Role.SECONDARY_CONTAINER));
        ui.circle(slx + slw - 4, sly + 4, 1, UiTheme.c(Role.ON_SECONDARY_CONTAINER));
        ui.pill(hx - 1, sly - 5, 2, 18, UiTheme.c(Role.PRIMARY));
        ui.pill(hx - 12, sly - 22, 24, 13, UiTheme.c(Role.INVERSE_SURFACE));
        ui.textCentered(TypeStyle.LABEL_MEDIUM, "62%", hx, sly - 19.5f, UiTheme.c(Role.INVERSE_ON_SURFACE));
        // Сакура-логотип.
        ui.icon(Icon.SAKURA, 300, 240, 40, UiTheme.c(Role.BRAND));
        ui.icon(Icon.SAKURA, 345, 250, 20, UiTheme.c(Role.PETAL));
        ui.text(TypeStyle.HEADLINE_MEDIUM, "Valkyrie", 372, 250, UiTheme.c(Role.ON_SURFACE));
        String name = dir + "/sheet_" + (dark ? "dark" : "light") + "_x" + (int) sc + ".png";
        cv.save(name);
        System.out.println(name + " ops=" + cv.ops);
    }
}
