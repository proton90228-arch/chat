package preview;

import com.valkyrie.client.ui.clickgui.*;
import com.valkyrie.client.ui.color.*;
import com.valkyrie.client.ui.motion.Motion;
import com.valkyrie.client.ui.render.Ui;
import com.valkyrie.client.ui.text.TypeStyle;
import com.valkyrie.client.ui.theme.UiTheme;
import java.util.*;

public final class ClickGuiPreview {
    static String dir;
    public static void main(String[] a) throws Exception {
        dir = a[0];
        String only = a.length > 1 ? a[1] : "";
        if (only.isEmpty() || only.equals("1")) scene("clickgui_visuals_light_x2", false, 2f, 1920, 1080, 1, v -> v.debugExpand("ESP"), 0.62f, 0.33f);
        if (only.isEmpty() || only.equals("2")) scene("clickgui_combat_dark_x2", true, 2f, 1920, 1080, 2, v -> v.debugExpand("KillAura"), 0.45f, 0.52f);
        if (only.isEmpty() || only.equals("3")) scene("clickgui_client_light_x3", false, 3f, 1920, 1080, 3, v -> v.debugExpand("Appearance"), 0.7f, 0.4f);
        if (only.isEmpty() || only.equals("4")) scene("clickgui_search_dark_x2", true, 2f, 1920, 1080, 1, v -> v.debugQuery("tr"), 0.5f, 0.5f);
        if (only.isEmpty() || only.equals("5")) scene("clickgui_folded_light_x2", false, 2f, 1920, 1080, 0, v -> v.debugFold(), 0.1f, 0.4f);
        if (only.isEmpty() || only.equals("7")) filmstrip();
        if (only.isEmpty() || only.equals("6")) scene("clickgui_hud_light_x2_720p", false, 2f, 1280, 720, 0, v -> v.debugExpand("Watermark"), 0.5f, 0.3f);
    }
    interface Act { void run(ClickGuiView v); }

    /** Кадры анимации открытия и раскрытия карточки: 0, 50, 100, 160, 300 мс. */
    static void filmstrip() throws Exception {
        float sc = 1f; int W = 960, H = 540;
        float[] times = {0.016f, 0.05f, 0.10f, 0.16f, 0.30f};
        int[] strip = new int[W * times.length / 2 * H / 2];
        int SW = W / 2 * times.length, SH = H / 2;
        ImageCanvas out = new ImageCanvas(SW, SH * 2, 1f);
        out.clear(0xFF101014);
        for (int row = 0; row < 2; row++) for (int k = 0; k < times.length; k++) {
            FakeModel model = new FakeModel();
            UiTheme.set(Scheme.Preset.SAKURA.seed, row == 1);
            int[] bg = Backdrop.make(W, H, row == 1);
            ImageCanvas cv = new ImageCanvas(W, H, sc);
            ClickGuiView view = new ClickGuiView(model, new ClickGuiView.Host() { public void sound(ClickGuiView.Sound s) {} public void close() {} }, 1, false);
            Ui ui = Ui.get();
            float t = 0; boolean expanded = row == 1;
            if (expanded) { for (int f = 0; f < 40; f++) { Motion.advanceManual(1 / 60f); ui.begin(cv); view.render(ui, 0, 0); } view.debugExpand("Tracers"); }
            while (t < times[k]) { Motion.advanceManual(1 / 120f); t += 1 / 120f; cv.backdrop(bg); ui.begin(cv); view.render(ui, 0, 0); }
            for (int y = 0; y < SH; y++) for (int x = 0; x < W / 2; x++) {
                int c = cv.px[(y * 2) * W + x * 2];
                out.px[(row * SH + y) * SW + k * (W / 2) + x] = c;
            }
        }
        out.save(dir + "/clickgui_motion_filmstrip.png");
        System.out.println("filmstrip ok");
    }

    static void scene(String name, boolean dark, float sc, int W, int H, int cat, Act act, float mxr, float myr) throws Exception {
        FakeModel model = new FakeModel();
        model.dark = dark;
        UiTheme.set(Scheme.Preset.SAKURA.seed, dark);
        int[] bg = Backdrop.make(W, H, dark);
        ImageCanvas cv = new ImageCanvas(W, H, sc);
        Ui ui = Ui.get();
        List<String> sounds = new ArrayList<>();
        ClickGuiView.Host host = new ClickGuiView.Host() {
            public void sound(ClickGuiView.Sound s) { sounds.add(s.name()); }
            public void close() { }
            public String playerName() { return "Sakura_Valk"; }
            public void companion(Ui u, float x, float y, float w, float h, float alpha) {
                float cx = x + w / 2, top = y + 10;
                int skin = 0xFFE8B89A, shirt = UiTheme.c(Role.PRIMARY), pants = 0xFF3B3F5C;
                u.round(cx - 9, top, 18, 18, 3, skin);
                u.round(cx - 9, top, 18, 6, 3, 3, 0, 0, 0xFF5A3A2E);
                u.rect(cx - 9, top + 20, 18, 26, shirt);
                u.rect(cx - 16, top + 20, 6, 24, shirt); u.rect(cx + 10, top + 20, 6, 24, shirt);
                u.rect(cx - 9, top + 46, 8.5f, 26, pants); u.rect(cx + 0.5f, top + 46, 8.5f, 26, pants);
            }
        };
        ClickGuiView view = new ClickGuiView(model, host, cat, false);
        float mx = W / sc * mxr, my = H / sc * myr;
        int frames = 110;
        for (int f = 0; f < frames; f++) {
            Motion.advanceManual(1 / 60f);
            if (f == 20) act.run(view);
            boolean last = f == frames - 1;
            if (last || f % 10 == 0) cv.backdrop(bg);
            ui.begin(cv);
            view.render(ui, mx, my);
        }
        cv.save(dir + "/" + name + ".png");
        System.out.println(name + " sounds=" + sounds + " ops=" + cv.ops);
    }
}
