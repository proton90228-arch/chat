package preview;

import com.valkyrie.client.ui.color.Scheme;
import com.valkyrie.client.ui.hud.HudElement;
import com.valkyrie.client.ui.hud.HudLayout;
import com.valkyrie.client.ui.hud.HudState;
import com.valkyrie.client.ui.hud.HudView;
import com.valkyrie.client.ui.hud.HudEditorView;
import com.valkyrie.client.ui.hud.QuoteView;
import com.valkyrie.client.ui.hud.ToastStack;
import com.valkyrie.client.ui.motion.Motion;
import com.valkyrie.client.ui.render.Ui;
import com.valkyrie.client.ui.theme.UiTheme;

/** Превью HUD поверх псевдо-Minecraft: java -cp cls:res preview.HudPreview <outDir> [scene] */
public final class HudPreview {
    interface Extra {
        void draw(Ui ui, float t);
    }

    static HudView CURRENT;

    static HudState state(float t) {
        HudState s = new HudState();
        for (HudElement e : HudElement.values()) {
            s.visible(e, true);
        }
        s.fps = (int) (138 + 18 * Math.sin(t * 1.7) + 9 * Math.sin(t * 5.3) - (t > 2.4 && t < 3.1 ? 55 : 0));
        s.keyW = true;
        s.keyD = t % 1.2f < 0.5f;
        s.mouseLeft = t % 0.14f < 0.06f;
        s.cpsLeft = 7;
        s.blockX = -284;
        s.blockY = 71;
        s.blockZ = 1532;
        s.ping = 42;
        s.sessionSeconds = 754;
        s.armor.add(new HudState.Armor(0, 0.94f));
        s.armor.add(new HudState.Armor(1, 0.71f));
        s.armor.add(new HudState.Armor(2, 0.88f));
        s.armor.add(new HudState.Armor(3, 0.31f));
        s.effects.add(new HudState.Effect("Speed", 1, 20 * 154, 0x33EBFF, false));
        s.effects.add(new HudState.Effect("Strength", 0, 20 * 62, 0xFFC700, false));
        s.effects.add(new HudState.Effect("Night Vision", 0, -1, 0xC2FF66, false));
        s.effects.add(new HudState.Effect("Poison", 0, 20 * 6, 0x87A363, true));
        float hp = t < 4.55f ? 18.0f : 13.5f;
        int hurt = t < 4.55f ? 0 : Math.max(0, 10 - (int) ((t - 4.55f) * 20));
        s.target = new HudState.Target(7, "Zombie", hp, 20.0f, t < 4.55f ? 0 : 2.0f, hurt, 3.2f, "zombie");
        return s;
    }

    static ImageCanvas render(int W, int H, float sc, boolean dark, int seed, float seconds, Extra extra) {
        UiTheme.set(seed, dark);
        int[] bg = WorldBackdrop.make(W, H, sc, dark);
        ImageCanvas cv = new ImageCanvas(W, H, sc);
        HudView view = new HudView(new PreviewHost());
        CURRENT = view;
        HudLayout layout = new HudLayout();
        Ui ui = Ui.get();
        float t = 0;
        float dt = 1 / 60f;
        while (t < seconds) {
            Motion.advanceManual(dt);
            t += dt;
            cv.backdrop(bg);
            ui.begin(cv);
            HudState s = state(t);
            view.render(ui, s, layout);
            if (extra != null) {
                extra.draw(ui, t);
            }
        }
        return cv;
    }

    static void crop(ImageCanvas src, int x, int y, int w, int h, int zoom, String path) throws Exception {
        ImageCanvas out = new ImageCanvas(w * zoom, h * zoom, 1f);
        for (int yy = 0; yy < h * zoom; yy++) {
            for (int xx = 0; xx < w * zoom; xx++) {
                int sx = Math.min(src.w - 1, x + xx / zoom);
                int sy = Math.min(src.h - 1, y + yy / zoom);
                out.px[yy * out.w + xx] = src.px[sy * src.w + sx];
            }
        }
        out.save(path);
    }


    static void editor(String path, boolean dark, int seed) throws Exception {
        int W = 1920, H = 1080;
        float sc = 2f;
        UiTheme.set(seed, dark);
        int[] bg = WorldBackdrop.make(W, H, sc, dark);
        ImageCanvas cv = new ImageCanvas(W, H, sc);
        HudView view = new HudView(new PreviewHost());
        HudLayout layout = new HudLayout();
        HudEditorView ed = new HudEditorView(view, new HudEditorView.Host() {
            public HudLayout layout() { return layout; }
            public boolean enabled(HudElement e) { return e != HudElement.EFFECTS; }
            public void moved(HudElement e, int x, int y) { layout.set(e, x, y); }
            public void reset(HudElement e) { layout.reset(e); }
            public void resetAll() { for (HudElement e : HudElement.values()) layout.reset(e); }
            public void close() { }
        });
        Ui ui = Ui.get();
        float t = 0;
        float mx = 0, my = 0;
        while (t < 1.6f) {
            Motion.advanceManual(1 / 60f);
            t += 1 / 60f;
            cv.backdrop(bg);
            ui.begin(cv);
            HudState s = state(2f);
            HudView.fillSamples(s);
            if (t > 0.5f && t < 0.52f) {
                mx = 40; my = 60;
                ed.mousePressed(mx, my, 0);
            }
            if (t > 0.52f) {
                float k = Math.min(1f, (t - 0.52f) / 0.6f);
                mx = 40 + (412 - 40) * k;
                my = 60 + (139 - 60) * k;
                ed.mouseDragged(mx, my);
            }
            ed.render(ui, s, mx, my);
        }
        cv.save(path);
    }

    public static void main(String[] args) throws Exception {
        String dir = args.length > 0 ? args[0] : ".";
        String only = args.length > 1 ? args[1] : "all";
        if (only.equals("all") || only.equals("day")) {
            ImageCanvas a = render(1920, 1080, 3f, false, Scheme.Preset.SAKURA.seed, 4.75f, null);
            a.save(dir + "/hud_day_light_x3.png");
            crop(a, 0, 0, 760, 420, 1, dir + "/hud_day_light_topleft.png");
            crop(a, 1920 - 520, 0, 520, 260, 1, dir + "/hud_day_light_topright.png");
            crop(a, 960 - 420, 1080 - 520, 840, 520, 1, dir + "/hud_day_light_bottom.png");
            System.out.println("day ok");
        }
        if (only.equals("all") || only.equals("night")) {
            ImageCanvas b = render(1920, 1080, 2f, true, Scheme.Preset.SAKURA.seed, 4.75f, null);
            b.save(dir + "/hud_night_dark_x2.png");
            System.out.println("night ok");
        }

        if (only.equals("all") || only.equals("toasts")) {
            java.util.function.Supplier<Extra> make = () -> {
                ToastStack toasts = new ToastStack();
                QuoteView quote = new QuoteView();
                boolean[] fired = new boolean[4];
                return (ui, t) -> {
                    if (t > 0.5f && !fired[0]) { fired[0] = true; toasts.toggle("KillAura", true); }
                    if (t > 1.2f && !fired[1]) { fired[1] = true; toasts.push(ToastStack.Kind.INFO, "Config saved", "profile \"default\" · 36 modules"); }
                    if (t > 1.9f && !fired[2]) { fired[2] = true; toasts.toggle("Sprint", false); }
                    if (t > 2.6f && !fired[3]) { fired[3] = true; toasts.push(ToastStack.Kind.WARNING, "Server lag", "TPS dropped to 12.4"); }
                    float right = ui.width() - 10;
                    toasts.render(ui, right, CURRENT.avoidTop(right - ToastStack.maxWidth(), right, 10));
                    quote.render(ui, t > 0.3f ? "Цветёт сакура — и в бою, и в тишине." : null, ui.width() / 2f, 12, 1f);
                };
            };
            ImageCanvas c = render(1920, 1080, 3f, false, Scheme.Preset.SAKURA.seed, 3.0f, make.get());
            crop(c, 1920 - 760, 0, 760, 560, 1, dir + "/toasts_light_x3.png");
            crop(c, 960 - 480, 0, 960, 140, 1, dir + "/quote_light_x3.png");
            ImageCanvas d = render(1920, 1080, 3f, true, Scheme.Preset.FUJI.seed, 3.0f, make.get());
            crop(d, 1920 - 760, 0, 760, 560, 1, dir + "/toasts_dark_x3.png");
            System.out.println("toasts ok");
        }
        if (only.equals("all") || only.equals("editor")) {
            editor(dir + "/editor_light_x2.png", false, Scheme.Preset.SAKURA.seed);
            editor(dir + "/editor_dark_x2.png", true, Scheme.Preset.MATCHA.seed);
            System.out.println("editor ok");
        }
    }
}
