package preview;

/** Размытый «игровой мир» за интерфейсом: небо, горы, деревья, солнце. */
public final class Backdrop {
    public static int[] make(int w, int h, boolean night) {
        int[] p = new int[w * h];
        java.util.Random rnd = new java.util.Random(7);
        for (int y = 0; y < h; y++) {
            float t = y / (float) h;
            int top = night ? 0x1B2140 : 0x8EC5F0, mid = night ? 0x3A3260 : 0xCFE6F7;
            int c = ImageCanvas.mix(0xFF000000 | top, 0xFF000000 | mid, Math.min(1, t * 1.6f));
            for (int x = 0; x < w; x++) p[y * w + x] = c;
        }
        // Горы и лес.
        for (int layer = 0; layer < 3; layer++) {
            int col = night ? new int[] {0x2C3355, 0x232845, 0x1A1E33}[layer] : new int[] {0x8FB0C8, 0x6E9A6A, 0x4E7A47}[layer];
            double base = h * (0.52 + layer * 0.12), amp = h * (0.10 - layer * 0.02), f = 2.0 + layer * 1.7, ph = layer * 1.3;
            for (int x = 0; x < w; x++) {
                double yy = base - amp * (0.6 * Math.sin(x / (double) w * Math.PI * f + ph) + 0.4 * Math.sin(x / (double) w * Math.PI * f * 2.3 + ph * 2));
                for (int y = (int) Math.max(0, yy); y < h; y++) p[y * w + x] = 0xFF000000 | col;
            }
        }
        // Пятна света (солнце/луна, цветущие деревья).
        blob(p, w, h, (int) (w * 0.78), (int) (h * 0.2), h * 0.09, night ? 0xFFE9E4F5 : 0xFFFFF4D6, 0.9f);
        for (int i = 0; i < 14; i++) blob(p, w, h, rnd.nextInt(w), (int) (h * (0.62 + rnd.nextFloat() * 0.25)), h * (0.03 + rnd.nextFloat() * 0.04), night ? 0xFF8F6BA8 : 0xFFF2B8C9, 0.8f);
        return boxBlur(boxBlur(boxBlur(p, w, h, 18), w, h, 18), w, h, 18);
    }
    static void blob(int[] p, int w, int h, int cx, int cy, double r, int col, float a) {
        for (int y = Math.max(0, (int) (cy - r)); y < Math.min(h, cy + r); y++)
            for (int x = Math.max(0, (int) (cx - r)); x < Math.min(w, cx + r); x++) {
                double d = Math.hypot(x - cx, y - cy) / r; if (d > 1) continue;
                p[y * w + x] = ImageCanvas.mix(p[y * w + x], col, (float) (a * (1 - d * d)));
            }
    }
    static int[] boxBlur(int[] src, int w, int h, int r) {
        int[] tmp = new int[src.length], out = new int[src.length];
        for (int pass = 0; pass < 2; pass++) {
            int[] in = pass == 0 ? src : tmp, o = pass == 0 ? tmp : out;
            int len = pass == 0 ? w : h, lines = pass == 0 ? h : w;
            for (int l = 0; l < lines; l++) {
                long sr = 0, sg = 0, sb = 0; int n = 0;
                int[] buf = new int[len];
                for (int i = 0; i < len; i++) buf[i] = in[pass == 0 ? l * w + i : i * w + l];
                for (int i = -r; i <= r; i++) { int c = buf[Math.max(0, Math.min(len - 1, i))]; sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255; n++; }
                for (int i = 0; i < len; i++) {
                    int idx = pass == 0 ? l * w + i : i * w + l;
                    o[idx] = 0xFF000000 | ((int) (sr / n) << 16) | ((int) (sg / n) << 8) | (int) (sb / n);
                    int add = buf[Math.min(len - 1, i + r + 1)], rem = buf[Math.max(0, i - r)];
                    sr += ((add >> 16) & 255) - ((rem >> 16) & 255); sg += ((add >> 8) & 255) - ((rem >> 8) & 255); sb += (add & 255) - (rem & 255);
                }
            }
        }
        return out;
    }
}
