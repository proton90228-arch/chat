import javax.tools.*; import java.util.*; import java.nio.file.*; import java.util.stream.*;
public class Javac { public static void main(String[] a) throws Exception {
  // usage: Javac <outDir> <classpath> <srcRoot...>
  String out=a[0], cp=a[1]; List<String> files=new ArrayList<>();
  for (int i=2;i<a.length;i++) try (Stream<Path> s=Files.walk(Paths.get(a[i]))) { s.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toString())); }
  List<String> args=new ArrayList<>(List.of("-d",out,"-encoding","UTF-8","-Xlint:-options","-nowarn","-Xmaxerrs","60","--release","21")); if(!cp.isEmpty()){args.add("-cp");args.add(cp);} args.addAll(files);
  int r=ToolProvider.getSystemJavaCompiler().run(null,null,null,args.toArray(new String[0])); System.out.println("javac exit="+r+" files="+files.size()); System.exit(r);
}}
