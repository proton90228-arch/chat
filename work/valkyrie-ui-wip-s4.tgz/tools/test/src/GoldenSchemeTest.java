import com.valkyrie.client.ui.color.*;
import java.nio.file.*; import java.util.*;
public class GoldenSchemeTest { public static void main(String[] a) throws Exception {
  int ok=0, bad=0, missing=0; Map<String,Role> byToken=new HashMap<>(); for (Role r: Role.all()) byToken.put(r.token,r);
  for (String line: Files.readAllLines(Paths.get(a[0]))) { if(line.isBlank()) continue; String[] p=line.split(" ");
    int seed=0xFF000000|Integer.parseInt(p[0].substring(1),16); boolean dark=p[1].equals("dark"); Role role=byToken.get(p[2]);
    if(role==null){missing++; System.out.println("no role "+p[2]); continue;}
    int got=Scheme.of(seed,dark).get(role); String gs=String.format("#%06X",got&0xFFFFFF);
    if(gs.equalsIgnoreCase(p[3])) ok++; else {bad++; if(bad<15) System.out.println("MISMATCH "+line+" got "+gs);} }
  System.out.println("golden ok="+ok+" bad="+bad+" missingRoles="+missing+" totalRoles="+Role.all().length);
}}
