#!/bin/bash
# Собирает MC-независимую часть ui + превью в tools/preview/cls
set -e
rm -rf /tmp/w/pv_src /tmp/w/tools/preview/cls && mkdir -p /tmp/w/pv_src/com/valkyrie/client /tmp/w/tools/preview/cls
cp -r /tmp/w/out/src/main/java/com/valkyrie/client/ui /tmp/w/pv_src/com/valkyrie/client/
rm -rf /tmp/w/pv_src/com/valkyrie/client/ui/mc
java /tmp/w/tools/Javac.java /tmp/w/tools/preview/cls "" /tmp/w/pv_src /tmp/w/tools/preview/src 2>&1 | grep -v "^Note:" | head -80
