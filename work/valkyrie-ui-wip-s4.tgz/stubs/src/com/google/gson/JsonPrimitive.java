package com.google.gson;
public class JsonPrimitive extends JsonElement { public JsonPrimitive(Boolean b) {} public JsonPrimitive(Number n) {} public JsonPrimitive(String s) {} public boolean isNumber() { return false; } public boolean isBoolean() { return false; } public boolean isString() { return false; } }
