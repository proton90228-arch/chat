package com.google.gson;
public class JsonObject extends JsonElement { public void addProperty(String k, Boolean v) {} public void addProperty(String k, Number v) {} public void addProperty(String k, String v) {} public void add(String k, JsonElement v) {} public JsonElement get(String k) { return null; } public boolean has(String k) { return false; } }
