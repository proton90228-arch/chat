package com.valkyrie.client.module;
import java.util.List;
public final class ModuleRegistry { public static <T extends Module> T get(Class<T> c) { return null; } public static List<Module> byCategory(Category c) { return List.of(); } public static List<Module> all() { return List.of(); } public static boolean isEnabled(Class<? extends Module> c) { return false; } }
