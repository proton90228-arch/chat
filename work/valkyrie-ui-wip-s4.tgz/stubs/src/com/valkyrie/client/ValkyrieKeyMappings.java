package com.valkyrie.client;
public final class ValkyrieKeyMappings { public static final net.minecraft.client.KeyMapping OPEN_GUI = new net.minecraft.client.KeyMapping(); }
