package com.valkyrie.client.gui;
public final class CompanionReactions { public static void moduleToggled(boolean e) {} public static void settingChanged() {} public static void greeting() {} public static void warning() {} public static float lookX() { return 0; } public static float lookY() { return 0; } public static float bob() { return 0; } public static void reset() {} }
