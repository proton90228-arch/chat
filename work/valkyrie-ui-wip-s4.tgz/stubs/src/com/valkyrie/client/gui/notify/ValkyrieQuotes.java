package com.valkyrie.client.gui.notify;
public final class ValkyrieQuotes { public static void onOpenGui() {} public static void render(net.minecraft.client.gui.GuiGraphics g, net.minecraft.client.gui.Font f, float s) {} }
