package com.valkyrie.client.gui.particle;
public final class SakuraParticles { public static void render(net.minecraft.client.gui.GuiGraphics g, float pt, float a) {} }
