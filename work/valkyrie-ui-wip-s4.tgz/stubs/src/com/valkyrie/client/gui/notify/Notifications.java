package com.valkyrie.client.gui.notify;
public final class Notifications { public static void toggle(String n, boolean e) {} public static void render(net.minecraft.client.gui.GuiGraphics g, net.minecraft.client.gui.Font f) {} public static void info(String a, String b) {} }
