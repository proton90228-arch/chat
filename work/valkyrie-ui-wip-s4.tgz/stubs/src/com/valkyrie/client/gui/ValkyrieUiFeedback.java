package com.valkyrie.client.gui;
public final class ValkyrieUiFeedback { public static void click() {} public static void hover() {} public static void toggleOn() {} public static void toggleOff() {} public static void open() {} public static void close() {} public static void tick() {} }
