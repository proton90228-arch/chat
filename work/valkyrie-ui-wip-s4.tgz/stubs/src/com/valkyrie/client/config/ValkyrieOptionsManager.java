package com.valkyrie.client.config;
public final class ValkyrieOptionsManager { public static final ValkyrieOptions OPTIONS = new ValkyrieOptions(); public static void save() {} }
