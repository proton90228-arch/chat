package com.valkyrie;
public class ValkyrieClient { public static final String MODID = "valkyrieclient"; }
