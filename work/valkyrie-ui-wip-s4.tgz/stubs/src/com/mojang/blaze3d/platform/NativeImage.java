package com.mojang.blaze3d.platform;
public class NativeImage implements AutoCloseable { public enum Format { RGBA }
  public NativeImage(Format f, int w, int h, boolean c) {} public void setPixelABGR(int x, int y, int abgr) {} public void setPixel(int x, int y, int argb) {} public int getWidth() { return 0; } public int getHeight() { return 0; } public void close() {} }
