package com.mojang.blaze3d.platform;
public class Window { public int getGuiScaledWidth() { return 0; } public int getGuiScaledHeight() { return 0; } public int getWidth() { return 0; } public int getHeight() { return 0; } }
