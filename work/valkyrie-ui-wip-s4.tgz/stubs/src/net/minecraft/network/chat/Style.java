package net.minecraft.network.chat;
public class Style { public static final Style EMPTY = new Style(); public Style withBold(Boolean b) { return this; } }
