package net.minecraft.network.chat;
public class MutableComponent implements Component { public MutableComponent withStyle(Style s) { return this; } }
