package net.minecraft.world.entity;
public class LivingEntity { public net.minecraft.network.chat.Component getName() { return null; } }
