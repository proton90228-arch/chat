package net.minecraft.client.input;
public record KeyEvent(int key, int scancode, int modifiers) { public boolean isEscape() { return key == 256; } }
