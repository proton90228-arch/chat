package net.minecraft.client;
public class KeyMapping { public boolean matches(net.minecraft.client.input.KeyEvent e) { return false; } }
