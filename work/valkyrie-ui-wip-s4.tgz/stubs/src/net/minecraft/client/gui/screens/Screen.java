package net.minecraft.client.gui.screens;
import net.minecraft.client.gui.*; import net.minecraft.client.input.*; import net.minecraft.network.chat.Component;
public abstract class Screen { protected net.minecraft.client.Minecraft minecraft; protected Font font; public int width, height;
  protected Screen(Component title) {} protected void init() {} public void render(GuiGraphics g, int x, int y, float pt) {} public void renderBackground(GuiGraphics g, int x, int y, float pt) {}
  public boolean mouseClicked(MouseButtonEvent e, boolean d) { return false; } public boolean mouseReleased(MouseButtonEvent e) { return false; }
  public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) { return false; } public boolean mouseScrolled(double x, double y, double sx, double sy) { return false; }
  public boolean keyPressed(KeyEvent e) { return false; } public boolean charTyped(CharacterEvent e) { return false; } public void onClose() {} public boolean isPauseScreen() { return true; } }
