package net.minecraft.client.gui.screens.inventory;
public class InventoryScreen { public static void renderEntityInInventoryFollowsMouse(net.minecraft.client.gui.GuiGraphics g, int x1, int y1, int x2, int y2, int scale, float yOff, float mx, float my, net.minecraft.world.entity.LivingEntity e) {} }
