package net.minecraft.client;
public class Minecraft { public net.minecraft.client.player.LocalPlayer player; public Options options; public static Minecraft getInstance() { return null; }
  public com.mojang.blaze3d.platform.Window getWindow() { return null; } public net.minecraft.client.renderer.texture.TextureManager getTextureManager() { return null; } public void setScreen(net.minecraft.client.gui.screens.Screen s) {} }
