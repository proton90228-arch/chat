package net.minecraft.client.renderer.texture;
import com.mojang.blaze3d.platform.NativeImage; import java.util.function.Supplier;
public class DynamicTexture extends AbstractTexture { public DynamicTexture(Supplier<String> label, NativeImage image) {} public void upload() {} public NativeImage getPixels() { return null; } }
