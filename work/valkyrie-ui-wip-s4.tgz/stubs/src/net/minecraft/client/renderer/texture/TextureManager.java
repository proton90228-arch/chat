package net.minecraft.client.renderer.texture;
import net.minecraft.resources.ResourceLocation;
public class TextureManager { public void register(ResourceLocation id, AbstractTexture t) {} public void release(ResourceLocation id) {} }
