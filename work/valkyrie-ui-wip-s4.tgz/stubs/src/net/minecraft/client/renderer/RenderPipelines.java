package net.minecraft.client.renderer;
import com.mojang.blaze3d.pipeline.RenderPipeline;
public class RenderPipelines { public static final RenderPipeline GUI_TEXTURED = new RenderPipeline(); }
