package org.joml;
public class Matrix3x2fStack { public Matrix3x2fStack pushMatrix() { return this; } public Matrix3x2fStack popMatrix() { return this; } public Matrix3x2fStack scale(float x, float y) { return this; } public Matrix3x2fStack translate(float x, float y) { return this; } }
