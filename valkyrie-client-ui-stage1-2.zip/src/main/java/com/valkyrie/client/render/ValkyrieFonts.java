package com.valkyrie.client.render;

import com.valkyrie.client.ui.mc.McUi;
import com.valkyrie.client.ui.render.Ui;
import com.valkyrie.client.ui.text.TypeStyle;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

/** Текст UI: TTF-рендерер Gfx, если он готов, иначе ванильный {@link Font}. */
public final class ValkyrieFonts {
    private ValkyrieFonts() {
    }

    public static Component titleText(String value) {
        return Component.literal(value).withStyle(Style.EMPTY.withBold(true));
    }

    public static void draw(GuiGraphics guiGraphics, Font font, String value, int x, int y, int color) {
        text(guiGraphics, TypeStyle.UI_TEXT, value, x, y, color, false);
    }

    public static void drawTitle(GuiGraphics guiGraphics, Font font, String value, int x, int y, int color) {
        text(guiGraphics, TypeStyle.UI_TITLE, value, x, y, color, false);
    }

    public static void drawCentered(GuiGraphics guiGraphics, Font font, String value, int centerX, int y, int color) {
        text(guiGraphics, TypeStyle.UI_TEXT, value, centerX, y, color, true);
    }

    public static void drawCenteredTitle(GuiGraphics guiGraphics, Font font, String value, int centerX, int y, int color) {
        text(guiGraphics, TypeStyle.UI_TITLE, value, centerX, y, color, true);
    }

    public static int width(Font font, String value) {
        return (int) Math.ceil(McUi.textWidth(TypeStyle.UI_TEXT, value));
    }

    public static int titleWidth(Font font, String value) {
        return (int) Math.ceil(McUi.textWidth(TypeStyle.UI_TITLE, value));
    }

    public static int lineHeight(Font font) {
        return Math.round(TypeStyle.UI_TEXT.lineHeight);
    }

    /** Вывод через новый текстовый рендер; альфа 0 трактуется как непрозрачный (как у ванильного drawString). */
    private static void text(GuiGraphics guiGraphics, TypeStyle style, String value, int x, int y, int color, boolean centered) {
        if (value == null || value.isEmpty()) {
            return;
        }
        int argb = (color & 0xFC000000) == 0 ? color | 0xFF000000 : color;
        Ui ui = McUi.begin(guiGraphics);
        try {
            if (centered) {
                ui.textCentered(style, value, x, y, argb);
            } else {
                ui.text(style, value, x, y, argb);
            }
        } finally {
            McUi.end();
        }
    }
}
