package com.valkyrie.client.gui;

import com.valkyrie.client.ValkyrieKeyMappings;
import com.valkyrie.client.config.ValkyrieOptionsManager;
import com.valkyrie.client.gui.notify.Notifications;
import com.valkyrie.client.gui.notify.ValkyrieQuotes;
import com.valkyrie.client.gui.thunder.ThunderRender;
import com.valkyrie.client.module.ModuleRegistry;
import com.valkyrie.client.module.impl.AppearanceModule;
import com.valkyrie.client.ui.clickgui.ClickGuiView;
import com.valkyrie.client.ui.mc.McUi;
import com.valkyrie.client.ui.mc.ModuleGuiModel;
import com.valkyrie.client.ui.render.Ui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/**
 * ClickGUI Valkyrie: тонкая оболочка над {@link ClickGuiView} — размытие мира,
 * ввод, модель игрока, звуки и сохранение состояния. Весь дизайн — в {@code ui.clickgui}.
 */
public final class ValkyrieGuiScreen extends Screen implements ClickGuiView.Host {
    private ClickGuiView view;
    private GuiGraphics graphics;
    private int mouseX;
    private int mouseY;
    private boolean finished;

    public ValkyrieGuiScreen() {
        super(Component.literal("Valkyrie"));
    }

    @Override
    protected void init() {
        if (view == null) {
            var options = ValkyrieOptionsManager.OPTIONS;
            view = new ClickGuiView(new ModuleGuiModel(), this, options.clickGuiCategory, options.clickGuiCollapsed);
            ValkyrieUiFeedback.open();
            CompanionReactions.greeting();
        }
    }

    @Override
    public void renderBackground(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        // Размытие всего, что нарисовано раньше, — «стекло» под окном; лепестки — за окном.
        guiGraphics.blurBeforeThisStratum();
        float alpha = view == null ? 0.0f : view.appearAlpha();
        com.valkyrie.client.gui.particle.SakuraParticles.render(guiGraphics, partialTick, 0.85f * alpha);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        ThunderRender.beginFrame();
        this.graphics = guiGraphics;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        Ui ui = McUi.begin(guiGraphics);
        try {
            view.render(ui, mouseX, mouseY);
        } finally {
            McUi.end();
        }
        this.graphics = null;
        if (!finished) {
            ValkyrieQuotes.render(guiGraphics, this.font, ThunderRender.frameSeconds());
            Notifications.render(guiGraphics, this.font);
        }
    }

    // ─── ClickGuiView.Host ──────────────────────────────────────────────────

    @Override
    public void sound(ClickGuiView.Sound sound) {
        switch (sound) {
            case TOGGLE_ON -> ValkyrieUiFeedback.toggleOn();
            case TOGGLE_OFF -> ValkyrieUiFeedback.toggleOff();
            case SLIDER -> ValkyrieUiFeedback.tick();
            case CLOSE -> ValkyrieUiFeedback.close();
            case OPEN -> ValkyrieUiFeedback.open();
            default -> ValkyrieUiFeedback.click();
        }
    }

    @Override
    public void close() {
        if (finished) {
            return;
        }
        finished = true;
        ValkyrieOptionsManager.save();
        super.onClose();
    }

    @Override
    public String playerName() {
        return this.minecraft != null && this.minecraft.player != null ? this.minecraft.player.getName().getString() : "Player";
    }

    @Override
    public void companion(Ui ui, float x, float y, float w, float h, float alpha) {
        if (graphics == null || this.minecraft == null || this.minecraft.player == null || alpha < 0.55f) {
            return;
        }
        AppearanceModule appearance = ModuleRegistry.get(AppearanceModule.class);
        float motion = appearance.reducedMotion.value() ? 0.30f : 1.0f;
        float lookX = mouseX + CompanionReactions.lookX() * motion;
        float lookY = mouseY + CompanionReactions.lookY() * motion;
        float scale = ui.scale();
        // Модель игрока рисуется в единицах GUI: временно возвращаем исходную позу.
        graphics.pose().pushMatrix();
        graphics.pose().scale(scale, scale);
        graphics.pose().translate(ui.offsetX(), ui.offsetY() + CompanionReactions.bob() * motion);
        InventoryScreen.renderEntityInInventoryFollowsMouse(
            graphics,
            Math.round(x + 2),
            Math.round(y + 6),
            Math.round(x + w - 2),
            Math.round(y + h - 2),
            38,
            0.0625f,
            lookX,
            lookY,
            this.minecraft.player
        );
        graphics.pose().popMatrix();
    }

    @Override
    public void stateChanged(int category, boolean folded) {
        ValkyrieOptionsManager.OPTIONS.clickGuiCategory = category;
        ValkyrieOptionsManager.OPTIONS.clickGuiCollapsed = folded;
        CompanionReactions.settingChanged();
    }

    // ─── Ввод ───────────────────────────────────────────────────────────────

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        view.mouseClicked(event.x(), event.y(), event.button());
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        if (view.mouseReleased(event.x(), event.y(), event.button())) {
            CompanionReactions.settingChanged();
        }
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        view.mouseDragged(event.x(), event.y(), event.button());
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        return view.mouseScrolled(mouseX, mouseY, scrollY);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        boolean ctrl = (event.modifiers() & 0x0002) != 0;
        if (view.keyPressed(event.key(), ctrl)) {
            return true;
        }
        // Клавиша открытия закрывает окно, если не идёт ввод в поиск.
        if (!view.searchFocused() && ValkyrieKeyMappings.OPEN_GUI.matches(event)) {
            view.requestClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        int codepoint = event.codepoint();
        if (Character.isBmpCodePoint(codepoint) && view.charTyped((char) codepoint)) {
            return true;
        }
        return super.charTyped(event);
    }

    /** Закрытие с анимацией (вызывается и из {@code ClientHandler} по клавише меню). */
    public void requestClose() {
        if (view != null) {
            view.requestClose();
        } else {
            close();
        }
    }

    @Override
    public void onClose() {
        requestClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
