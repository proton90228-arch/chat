package com.valkyrie.client.ui.render;

import com.valkyrie.client.ui.color.Argb;
import com.valkyrie.client.ui.color.Role;
import com.valkyrie.client.ui.icon.Icon;
import com.valkyrie.client.ui.icon.IconRaster;
import com.valkyrie.client.ui.text.Fonts;
import com.valkyrie.client.ui.text.SizedFont;
import com.valkyrie.client.ui.text.TypeStyle;
import com.valkyrie.client.ui.theme.Elevation;
import com.valkyrie.client.ui.theme.UiTheme;
import java.util.HashMap;
import java.util.Map;

/**
 * Рисование интерфейса в единицах GUI поверх {@link Canvas} в физических пикселях.
 * <p>
 * Все координаты переводятся в пиксели экрана и округляются там, а не в GUI:
 * края, тени, иконки и текст получаются чёткими при любом масштабе интерфейса.
 * Формы собираются по схеме 9-slice из закэшированных аналитических масок.
 */
public final class Ui {
    private static final Ui INSTANCE = new Ui();

    private Canvas canvas;
    private float s = 1.0f;
    private float tx;
    private float ty;
    private float alpha = 1.0f;
    private final float[] stack = new float[96];
    private int depth;
    private final float[] alphaStack = new float[32];
    private int alphaDepth;
    private final Map<Long, Mask> masks = new HashMap<>();
    private final Map<String, Mask> bigMasks = new HashMap<>();

    private Ui() {
    }

    /** Общий экземпляр (интерфейс рисуется только из потока отрисовки). */
    public static Ui get() {
        return INSTANCE;
    }

    public Ui begin(Canvas canvas) {
        this.canvas = canvas;
        float scale = canvas.scale();
        if (scale != s) {
            masks.clear();
            bigMasks.clear();
        }
        this.s = scale;
        tx = 0.0f;
        ty = 0.0f;
        depth = 0;
        alpha = 1.0f;
        alphaDepth = 0;
        if (masks.size() > 1500) {
            masks.clear();
        }
        if (bigMasks.size() > 300) {
            bigMasks.clear();
        }
        return this;
    }

    public Canvas canvas() {
        return canvas;
    }

    public float scale() {
        return s;
    }

    /** Ширина экрана в единицах GUI. */
    public float width() {
        return canvas.width() / s;
    }

    public float height() {
        return canvas.height() / s;
    }

    /** Округление до физического пикселя (для выравнивания линий). */
    public float snap(float v) {
        return Math.round(v * s) / s;
    }

    // ─── Состояние ──────────────────────────────────────────────────────────

    public void push(float dx, float dy) {
        stack[depth++] = tx;
        stack[depth++] = ty;
        tx += dx;
        ty += dy;
    }

    public void pop() {
        ty = stack[--depth];
        tx = stack[--depth];
    }

    public void pushAlpha(float factor) {
        alphaStack[alphaDepth++] = alpha;
        alpha *= Math.max(0.0f, Math.min(1.0f, factor));
    }

    public void popAlpha() {
        alpha = alphaStack[--alphaDepth];
    }

    public float alpha() {
        return alpha;
    }

    /** Текущее смещение (GUI) — нужно, чтобы вставить в кадр чужую отрисовку (модель игрока). */
    public float offsetX() {
        return tx;
    }

    public float offsetY() {
        return ty;
    }

    private int px(float gx) {
        return Math.round((gx + tx) * s);
    }

    private int py(float gy) {
        return Math.round((gy + ty) * s);
    }

    private int color(int argb) {
        return alpha >= 1.0f ? argb : Argb.fade(argb, alpha);
    }

    // ─── Обрезка ────────────────────────────────────────────────────────────

    /** Прямоугольная обрезка; границы выравниваются по сетке GUI (так её понимает ножницы Minecraft). */
    public void clip(float x, float y, float w, float h) {
        int x0 = (int) Math.floor(x + tx);
        int y0 = (int) Math.floor(y + ty);
        int x1 = (int) Math.ceil(x + tx + w);
        int y1 = (int) Math.ceil(y + ty + h);
        canvas.pushClip(Math.round(x0 * s), Math.round(y0 * s), Math.round(x1 * s), Math.round(y1 * s));
    }

    public void unclip() {
        canvas.popClip();
    }

    // ─── Прямоугольники ─────────────────────────────────────────────────────

    public void rect(float x, float y, float w, float h, int argb) {
        int c = color(argb);
        if ((c >>> 24) == 0) {
            return;
        }
        canvas.fill(px(x), py(y), px(x + w), py(y + h), c);
    }

    public void gradient(float x, float y, float w, float h, int top, int bottom) {
        canvas.gradient(px(x), py(y), px(x + w), py(y + h), color(top), color(bottom));
    }

    /** Скруглённый прямоугольник с одинаковыми радиусами. */
    public void round(float x, float y, float w, float h, float r, int argb) {
        int c = color(argb);
        if ((c >>> 24) == 0 || w <= 0 || h <= 0) {
            return;
        }
        int x0 = px(x);
        int y0 = py(y);
        int x1 = px(x + w);
        int y1 = py(y + h);
        int rp = Math.round(r * s);
        roundPx(x0, y0, x1, y1, rp, rp, rp, rp, c);
    }

    /** Полностью скруглённая «пилюля». */
    public void pill(float x, float y, float w, float h, int argb) {
        round(x, y, w, h, Math.min(w, h) / 2.0f, argb);
    }

    /** Скругление с разными радиусами углов (по часовой от левого верхнего). */
    public void round(float x, float y, float w, float h, float tl, float tr, float br, float bl, int argb) {
        int c = color(argb);
        if ((c >>> 24) == 0 || w <= 0 || h <= 0) {
            return;
        }
        roundPx(px(x), py(y), px(x + w), py(y + h), Math.round(tl * s), Math.round(tr * s), Math.round(br * s), Math.round(bl * s), c);
    }

    private void roundPx(int x0, int y0, int x1, int y1, int tl, int tr, int br, int bl, int c) {
        int w = x1 - x0;
        int h = y1 - y0;
        if (w <= 0 || h <= 0) {
            return;
        }
        int limit = Math.min(w, h) / 2;
        tl = Math.max(0, Math.min(tl, limit));
        tr = Math.max(0, Math.min(tr, limit));
        br = Math.max(0, Math.min(br, limit));
        bl = Math.max(0, Math.min(bl, limit));
        if (tl > 0) {
            Mask m = disc(tl * 2);
            canvas.mask(m, x0, y0, tl, tl, 0, 0, tl, tl, c);
        }
        if (tr > 0) {
            Mask m = disc(tr * 2);
            canvas.mask(m, x1 - tr, y0, tr, tr, tr, 0, tr, tr, c);
        }
        if (br > 0) {
            Mask m = disc(br * 2);
            canvas.mask(m, x1 - br, y1 - br, br, br, br, br, br, br, c);
        }
        if (bl > 0) {
            Mask m = disc(bl * 2);
            canvas.mask(m, x0, y1 - bl, bl, bl, 0, bl, bl, bl, c);
        }
        // Остальное — горизонтальные полосы между угловыми зонами.
        int[] ys = {y0, y0 + tl, y0 + tr, y1 - bl, y1 - br, y1};
        java.util.Arrays.sort(ys);
        for (int i = 0; i < ys.length - 1; i++) {
            int a = ys[i];
            int b = ys[i + 1];
            if (b <= a) {
                continue;
            }
            int left = x0 + (a < y0 + tl ? tl : b > y1 - bl ? bl : 0);
            int right = x1 - (a < y0 + tr ? tr : b > y1 - br ? br : 0);
            if (right > left) {
                canvas.fill(left, a, right, b, c);
            }
        }
    }

    /** Обводка внутрь формы толщиной {@code stroke} (в GUI; минимум 1 физический пиксель). */
    public void outline(float x, float y, float w, float h, float r, float stroke, int argb) {
        int c = color(argb);
        if ((c >>> 24) == 0) {
            return;
        }
        int x0 = px(x);
        int y0 = py(y);
        int x1 = px(x + w);
        int y1 = py(y + h);
        int sw = Math.max(1, Math.round(stroke * s));
        int rp = Math.max(sw, Math.min(Math.round(r * s), Math.min(x1 - x0, y1 - y0) / 2));
        if (x1 - x0 < 2 * rp || y1 - y0 < 2 * rp) {
            return;
        }
        Mask ring = ringMask(rp * 2, sw);
        canvas.mask(ring, x0, y0, rp, rp, 0, 0, rp, rp, c);
        canvas.mask(ring, x1 - rp, y0, rp, rp, rp, 0, rp, rp, c);
        canvas.mask(ring, x1 - rp, y1 - rp, rp, rp, rp, rp, rp, rp, c);
        canvas.mask(ring, x0, y1 - rp, rp, rp, 0, rp, rp, rp, c);
        canvas.fill(x0 + rp, y0, x1 - rp, y0 + sw, c);
        canvas.fill(x0 + rp, y1 - sw, x1 - rp, y1, c);
        canvas.fill(x0, y0 + rp, x0 + sw, y1 - rp, c);
        canvas.fill(x1 - sw, y0 + rp, x1, y1 - rp, c);
    }

    // ─── Круги ──────────────────────────────────────────────────────────────

    public void circle(float cx, float cy, float radius, int argb) {
        int c = color(argb);
        int d = Math.round(radius * 2.0f * s);
        if ((c >>> 24) == 0 || d <= 0) {
            return;
        }
        int x0 = Math.round((cx + tx) * s - d / 2.0f);
        int y0 = Math.round((cy + ty) * s - d / 2.0f);
        Mask m = disc(d);
        canvas.mask(m, x0, y0, d, d, 0, 0, d, d, c);
    }

    public void ring(float cx, float cy, float radius, float stroke, int argb) {
        int c = color(argb);
        int d = Math.round(radius * 2.0f * s);
        if ((c >>> 24) == 0 || d <= 0) {
            return;
        }
        int sw = Math.max(1, Math.round(stroke * s));
        int x0 = Math.round((cx + tx) * s - d / 2.0f);
        int y0 = Math.round((cy + ty) * s - d / 2.0f);
        Mask m = ringMask(d, sw);
        canvas.mask(m, x0, y0, d, d, 0, 0, d, d, c);
    }

    // ─── Тени ───────────────────────────────────────────────────────────────

    /** Тень уровня M3 под формой со скруглением {@code r}. Цвет — роль {@code shadow} схемы. */
    public void elevation(float x, float y, float w, float h, float r, Elevation level) {
        elevation(x, y, w, h, r, level, 1.0f);
    }

    public void elevation(float x, float y, float w, float h, float r, Elevation level, float strength) {
        if (level == Elevation.LEVEL0 || strength <= 0.0f) {
            return;
        }
        int base = shadowColor();
        float boost = UiTheme.dark() ? 1.6f : 1.0f;
        shadow(x - level.ambientSpread, y - level.ambientSpread + level.ambientY, w + level.ambientSpread * 2, h + level.ambientSpread * 2,
            r + level.ambientSpread, level.ambientSigma, Argb.withAlpha(base, Math.min(1.0f, level.ambientAlpha * strength * boost)));
        shadow(x - level.keySpread, y + level.keyY, w + level.keySpread * 2, h, r, level.keySigma,
            Argb.withAlpha(base, Math.min(1.0f, level.keyAlpha * strength * boost)));
    }

    /** Цвет теней: в светлой схеме — глубокий тон бренда (тени «тёплые»), в тёмной — чёрный. */
    public static int shadowColor() {
        return UiTheme.dark() ? 0xFF000000 : Argb.mixOklab(0xFF000000, UiTheme.c(Role.ON_PRIMARY_FIXED), 0.55f);
    }

    /** Размытая тень прямоугольника: {@code sigma} — гауссово σ в GUI. */
    public void shadow(float x, float y, float w, float h, float r, float sigma, int argb) {
        int c = color(argb);
        if ((c >>> 24) == 0 || w <= 0 || h <= 0) {
            return;
        }
        float sig = Math.max(0.5f, Math.round(sigma * s * 2.0f) / 2.0f);
        int x0 = px(x);
        int y0 = py(y);
        int x1 = px(x + w);
        int y1 = py(y + h);
        int rp = Math.max(0, Math.min(Math.round(r * s), Math.min(x1 - x0, y1 - y0) / 2));
        int e = Raster.shadowExtent(sig);
        int p = rp + 2 * e;
        if (x1 - x0 < 2 * (rp + e) || y1 - y0 < 2 * (rp + e)) {
            String key = "sf" + (x1 - x0) + "x" + (y1 - y0) + "r" + rp + "s" + sig;
            Mask m = bigMasks.get(key);
            if (m == null) {
                m = Raster.shadowFull(x1 - x0, y1 - y0, rp, sig);
                bigMasks.put(key, m);
            }
            canvas.mask(m, x0 - e, y0 - e, m.width, m.height, 0, 0, m.width, m.height, c);
            return;
        }
        long key = key(3, rp, Math.round(sig * 2), 0);
        Mask sheet = masks.get(key);
        if (sheet == null) {
            sheet = Raster.shadowSheet(rp, sig);
            masks.put(key, sheet);
        }
        int left = x0 - e;
        int top = y0 - e;
        int right = x1 + e;
        int bottom = y1 + e;
        // Углы.
        canvas.mask(sheet, left, top, p, p, 0, 0, p, p, c);
        canvas.mask(sheet, right - p, top, p, p, p, 0, p, p, c);
        canvas.mask(sheet, right - p, bottom - p, p, p, p, p, p, p, c);
        canvas.mask(sheet, left, bottom - p, p, p, 0, p, p, p, c);
        // Края: растягиваем центральные столбец и строку.
        int mid = p - 1;
        if (right - left > 2 * p) {
            canvas.mask(sheet, left + p, top, right - left - 2 * p, p, mid, 0, 1, p, c);
            canvas.mask(sheet, left + p, bottom - p, right - left - 2 * p, p, mid, p, 1, p, c);
        }
        if (bottom - top > 2 * p) {
            canvas.mask(sheet, left, top + p, p, bottom - top - 2 * p, 0, mid, p, 1, c);
            canvas.mask(sheet, right - p, top + p, p, bottom - top - 2 * p, p, mid, p, 1, c);
        }
        if (right - left > 2 * p && bottom - top > 2 * p) {
            canvas.fill(left + p, top + p, right - p, bottom - p, c);
        }
    }

    // ─── Иконки ─────────────────────────────────────────────────────────────

    public void icon(Icon icon, float x, float y, float size, int argb) {
        icon(icon, x, y, size, argb, 1.0f);
    }

    /** Иконка в квадрате {@code size}; {@code weight} утолщает штрих (активные состояния). */
    public void icon(Icon icon, float x, float y, float size, int argb, float weight) {
        int c = color(argb);
        int d = Math.round(size * s);
        if ((c >>> 24) == 0 || d <= 0) {
            return;
        }
        long key = key(4, icon.ordinal(), d, Math.round(weight * 100));
        Mask m = masks.get(key);
        if (m == null) {
            m = IconRaster.render(icon, d, weight);
            masks.put(key, m);
        }
        int x0 = Math.round((x + tx) * s);
        int y0 = Math.round((y + ty) * s);
        canvas.mask(m, x0, y0, d, d, 0, 0, d, d, c);
    }

    // ─── Текст ──────────────────────────────────────────────────────────────

    public SizedFont font(TypeStyle style) {
        return Fonts.get(style).at(style.size * s);
    }

    /** Ширина строки в GUI. */
    public float textWidth(TypeStyle style, String text) {
        if (text == null || text.isEmpty()) {
            return 0.0f;
        }
        SizedFont f = font(style);
        SizedFont.Layout layout = f.layout(text);
        float tracking = style.tracking * style.size * s;
        return (layout.width + tracking * Math.max(0, layout.count() - 1)) / s;
    }

    /**
     * Строка в «строчном боксе» стиля: {@code y} — верх бокса высотой {@code style.lineHeight};
     * текст оптически центрирован по высоте прописных и строчных. Возвращает ширину в GUI.
     */
    public float text(TypeStyle style, String text, float x, float y, int argb) {
        if (text == null || text.isEmpty()) {
            return 0.0f;
        }
        int c = color(argb);
        SizedFont f = font(style);
        SizedFont.Layout layout = f.layout(text);
        float tracking = style.tracking * style.size * s;
        if ((c >>> 24) == 0) {
            return (layout.width + tracking * Math.max(0, layout.count() - 1)) / s;
        }
        float originX = (x + tx) * s;
        float top = (y + ty) * s;
        int baseline = Math.round(top + style.lineHeight * s * 0.5f + (f.capHeight + f.xHeight) * 0.25f);
        boolean light = Argb.luminance(c) > 0.42f;
        int count = layout.count();
        for (int i = 0; i < count; i++) {
            float pen = originX + layout.x(i) + tracking * i;
            int ip = (int) Math.floor(pen);
            int bin = Math.min(2, (int) ((pen - ip) * 3.0f));
            SizedFont.Glyph g = layout.font(i).glyph(layout.code(i), bin, light);
            if (g.page() == null) {
                continue;
            }
            canvas.mask(g.page(), ip + g.offsetX(), baseline + g.offsetY(), g.w(), g.h(), g.u(), g.v(), g.w(), g.h(), c);
        }
        return (layout.width + tracking * Math.max(0, count - 1)) / s;
    }

    public float textCentered(TypeStyle style, String text, float cx, float y, int argb) {
        float w = textWidth(style, text);
        text(style, text, cx - w / 2.0f, y, argb);
        return w;
    }

    public float textRight(TypeStyle style, String text, float right, float y, int argb) {
        float w = textWidth(style, text);
        text(style, text, right - w, y, argb);
        return w;
    }

    /** Обрезка строки с многоточием под ширину {@code max}. */
    public String ellipsize(TypeStyle style, String text, float max) {
        if (text == null || textWidth(style, text) <= max) {
            return text;
        }
        String dots = "…";
        int lo = 0;
        int hi = text.length();
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (textWidth(style, text.substring(0, mid).stripTrailing() + dots) <= max) {
                lo = mid;
            } else {
                hi = mid - 1;
            }
        }
        return lo <= 0 ? dots : text.substring(0, lo).stripTrailing() + dots;
    }

    /** Перенос по словам; не более {@code maxLines} строк (последняя — с многоточием). */
    public java.util.List<String> wrap(TypeStyle style, String text, float max, int maxLines) {
        java.util.List<String> lines = new java.util.ArrayList<>();
        if (text == null || text.isBlank()) {
            return lines;
        }
        String[] words = text.trim().split("\\s+");
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            String candidate = line.isEmpty() ? words[i] : line + " " + words[i];
            if (textWidth(style, candidate) <= max || line.isEmpty()) {
                line.setLength(0);
                line.append(candidate);
            } else {
                if (lines.size() == maxLines - 1) {
                    StringBuilder rest = new StringBuilder(line);
                    for (int j = i; j < words.length; j++) {
                        rest.append(' ').append(words[j]);
                    }
                    lines.add(ellipsize(style, rest.toString(), max));
                    return lines;
                }
                lines.add(line.toString());
                line.setLength(0);
                line.append(words[i]);
            }
        }
        if (!line.isEmpty()) {
            lines.add(ellipsize(style, line.toString(), max));
        }
        return lines;
    }

    // ─── Кэш масок ──────────────────────────────────────────────────────────

    private static long key(int type, int a, int b, int c) {
        return ((long) type << 56) | ((long) (a & 0xFFFF) << 32) | ((long) (b & 0xFFFF) << 16) | (c & 0xFFFF);
    }

    private Mask disc(int d) {
        long key = key(1, d, 0, 0);
        Mask m = masks.get(key);
        if (m == null) {
            m = Raster.disc(d);
            masks.put(key, m);
        }
        return m;
    }

    private Mask ringMask(int d, int stroke) {
        long key = key(2, d, stroke, 0);
        Mask m = masks.get(key);
        if (m == null) {
            m = Raster.ring(d, stroke);
            masks.put(key, m);
        }
        return m;
    }
}
