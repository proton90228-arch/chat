package com.valkyrie.client.ui.color;

/**
 * HCT (Hue · Chroma · Tone) из Material Color Utilities: CAM16 + CIE L*.
 * <p>
 * Порт {@code valkyrie-launcher/ui/src/theme/hct.ts} с тем же порядком операций,
 * поэтому клиент и лаунчер получают из одного seed-цвета байт-в-байт одинаковые
 * схемы (проверяется тестом против {@code schemes.json} лаунчера).
 * Стандартные условия просмотра MCU: sRGB, D65, L* фона 50, surround 2.
 */
public final class Hct {
    private static final double[] WHITE = {95.047, 100.0, 108.883};
    private static final double[][] SRGB_TO_XYZ = {
        {0.41233895, 0.35762064, 0.18051042},
        {0.2126, 0.7152, 0.0722},
        {0.01932141, 0.11916382, 0.95034478},
    };
    private static final double[][] XYZ_TO_SRGB = {
        {3.2413774792388685, -1.5376652402851851, -0.49885366846268053},
        {-0.9691452513005321, 1.8758853451067872, 0.04156585616912061},
        {0.05562093689691305, -0.20395524564742123, 1.0571799111220335},
    };
    private static final double[][] XYZ_TO_CAM16RGB = {
        {0.401288, 0.650173, -0.051461},
        {-0.250268, 1.204414, 0.045854},
        {-0.002079, 0.048952, 0.953127},
    };
    private static final double DEG_TO_RAD = Math.PI / 180.0;
    private static final double RAD_TO_DEG = 180.0 / Math.PI;

    // Условия просмотра (ViewingConditions.DEFAULT).
    private static final double NC;
    private static final double C;
    private static final double[] RGB_D;
    private static final double FL;
    private static final double N;
    private static final double Z;
    private static final double NBB;
    private static final double NCB;
    private static final double AW;

    static {
        double adapting = ((200.0 / Math.PI) * yFromLstar(50.0)) / 100.0;
        double[] w = mul(XYZ_TO_CAM16RGB, WHITE);
        double f = 0.8 + 2.0 / 10.0;
        double c = f >= 0.9 ? 0.59 + (0.69 - 0.59) * ((f - 0.9) * 10) : 0.525 + (0.59 - 0.525) * ((f - 0.8) * 10);
        double d = f * (1 - (1 / 3.6) * Math.exp((-adapting - 42) / 92));
        d = Math.max(0, Math.min(1, d));
        double[] rgbD = {d * (100 / w[0]) + 1 - d, d * (100 / w[1]) + 1 - d, d * (100 / w[2]) + 1 - d};
        double k = 1 / (5 * adapting + 1);
        double k4 = k * k * k * k;
        double k4F = 1 - k4;
        double fl = k4 * adapting + 0.1 * k4F * k4F * Math.cbrt(5 * adapting);
        double n = yFromLstar(50.0) / WHITE[1];
        double z = 1.48 + Math.sqrt(n);
        double nbb = 0.725 / Math.pow(n, 0.2);
        double[] rgbA = new double[3];
        for (int i = 0; i < 3; i++) {
            double fac = Math.pow((fl * rgbD[i] * w[i]) / 100, 0.42);
            rgbA[i] = (400 * fac) / (fac + 27.13);
        }
        NC = f;
        C = c;
        RGB_D = rgbD;
        FL = fl;
        N = n;
        Z = z;
        NBB = nbb;
        NCB = nbb;
        AW = (2 * rgbA[0] + rgbA[1] + 0.05 * rgbA[2]) * nbb;
    }

    private Hct() {
    }

    // ─── Публичное API ───────────────────────────────────────────────────────

    /** {hue, chroma, tone} цвета ARGB (альфа игнорируется). */
    public static double[] fromArgb(int argb) {
        double[] lin = {linearized((argb >> 16) & 0xFF), linearized((argb >> 8) & 0xFF), linearized(argb & 0xFF)};
        double[] xyz = mul(SRGB_TO_XYZ, lin);
        double[] cam = cam16FromXyz(xyz[0], xyz[1], xyz[2]);
        return new double[] {cam[0], cam[1], lstarFromY(xyz[1])};
    }

    /** Цвет с заданными hue/tone и максимально достижимой chroma ≤ запрошенной; непрозрачный ARGB. */
    public static int toArgb(double hue, double chroma, double tone) {
        if (tone <= 0.0001) {
            return 0xFF000000;
        }
        if (tone >= 99.9999) {
            return 0xFFFFFFFF;
        }
        double[] lin = linearRgb(hue, chroma, tone);
        if (!inGamut(lin)) {
            double lo = 0.0;
            double hi = chroma;
            for (int i = 0; i < 40; i++) {
                double mid = (lo + hi) / 2;
                if (inGamut(linearRgb(hue, mid, tone))) {
                    lo = mid;
                } else {
                    hi = mid;
                }
            }
            lin = linearRgb(hue, lo, tone);
        }
        int r = delinearized(clamp100(lin[0]));
        int g = delinearized(clamp100(lin[1]));
        int b = delinearized(clamp100(lin[2]));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** M3 Blend.harmonize: поворот hue к источнику на min(15°, разница/2). Возвращает {hue, chroma, tone}. */
    public static double[] harmonize(int design, int source) {
        double[] d = fromArgb(design);
        double[] s = fromArgb(source);
        double diff = 180 - Math.abs(Math.abs(d[0] - s[0]) - 180);
        double rotation = Math.min(diff * 0.5, 15.0);
        double direction = mod360(s[0] - d[0]) < 180 ? 1 : -1;
        return new double[] {mod360(d[0] + rotation * direction), d[1], d[2]};
    }

    /** Контраст WCAG 2.x между двумя цветами. */
    public static double contrast(int a, int b) {
        double la = luminance(a);
        double lb = luminance(b);
        double hi = Math.max(la, lb);
        double lo = Math.min(la, lb);
        return (hi + 0.05) / (lo + 0.05);
    }

    /** Относительная яркость WCAG (0..1). */
    public static double luminance(int argb) {
        double r = linearized((argb >> 16) & 0xFF) / 100;
        double g = linearized((argb >> 8) & 0xFF) / 100;
        double b = linearized(argb & 0xFF) / 100;
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }

    /** Остаток как в Python: всегда в [0, 360). */
    public static double mod360(double value) {
        double r = value % 360;
        return r < 0 ? r + 360 : r;
    }

    public static double yFromLstar(double l) {
        return 100.0 * labInvF((l + 16) / 116);
    }

    public static double lstarFromY(double y) {
        return 116 * labF(y / 100) - 16;
    }

    // ─── CAM16 ───────────────────────────────────────────────────────────────

    private static double[] cam16FromXyz(double x, double y, double z) {
        double[] rgbC = mul(XYZ_TO_CAM16RGB, new double[] {x, y, z});
        double rA = adapt(RGB_D[0] * rgbC[0]);
        double gA = adapt(RGB_D[1] * rgbC[1]);
        double bA = adapt(RGB_D[2] * rgbC[2]);
        double a = (11 * rA - 12 * gA + bA) / 11;
        double b = (rA + gA - 2 * bA) / 9;
        double u = (20 * rA + 20 * gA + 21 * bA) / 20;
        double p2 = (40 * rA + 20 * gA + bA) / 20;
        double hue = mod360(RAD_TO_DEG * Math.atan2(b, a));
        double ac = p2 * NBB;
        double j = 100 * Math.pow(ac / AW, C * Z);
        double hp = hue < 20.14 ? hue + 360 : hue;
        double eHue = 0.25 * (Math.cos(DEG_TO_RAD * hp + 2) + 3.8);
        double p1 = (50000.0 / 13) * eHue * NC * NCB;
        double t = (p1 * Math.hypot(a, b)) / (u + 0.305);
        double alpha = Math.pow(t, 0.9) * Math.pow(1.64 - Math.pow(0.29, N), 0.73);
        return new double[] {hue, alpha * Math.sqrt(j / 100), j};
    }

    private static double adapt(double v) {
        double af = Math.pow((FL * Math.abs(v)) / 100, 0.42);
        return (sign(v) * 400 * af) / (af + 27.13);
    }

    private static double[] xyzFromJch(double j, double chroma, double hue) {
        double alpha = chroma == 0 || j == 0 ? 0 : chroma / Math.sqrt(j / 100);
        double t = Math.pow(alpha / Math.pow(1.64 - Math.pow(0.29, N), 0.73), 1 / 0.9);
        double h = DEG_TO_RAD * hue;
        double eHue = 0.25 * (Math.cos(h + 2) + 3.8);
        double ac = AW * Math.pow(j / 100, 1 / C / Z);
        double p1 = eHue * (50000.0 / 13) * NC * NCB;
        double p2 = ac / NBB;
        double hs = Math.sin(h);
        double hc = Math.cos(h);
        double gamma = (23 * (p2 + 0.305) * t) / (23 * p1 + 11 * t * hc + 108 * t * hs);
        double a = gamma * hc;
        double b = gamma * hs;
        double rA = (460 * p2 + 451 * a + 288 * b) / 1403;
        double gA = (460 * p2 - 891 * a - 261 * b) / 1403;
        double bA = (460 * p2 - 220 * a - 6300 * b) / 1403;
        double rF = unadapt(rA) / RGB_D[0];
        double gF = unadapt(gA) / RGB_D[1];
        double bF = unadapt(bA) / RGB_D[2];
        return new double[] {
            1.86206786 * rF - 1.01125463 * gF + 0.14918677 * bF,
            0.38752654 * rF + 0.62144744 * gF - 0.00897398 * bF,
            -0.0158415 * rF - 0.03412294 * gF + 1.04996444 * bF,
        };
    }

    private static double unadapt(double v) {
        double base = Math.max(0, (27.13 * Math.abs(v)) / (400 - Math.abs(v)));
        return sign(v) * (100 / FL) * Math.pow(base, 1 / 0.42);
    }

    private static double solveJForY(double hue, double chroma, double yTarget) {
        double lo = 0.0;
        double hi = 100.0;
        for (int i = 0; i < 60; i++) {
            double mid = (lo + hi) / 2;
            double y = xyzFromJch(mid, chroma, hue)[1];
            if (y < yTarget) {
                lo = mid;
            } else {
                hi = mid;
            }
        }
        return (lo + hi) / 2;
    }

    private static double[] linearRgb(double hue, double chroma, double tone) {
        double j = solveJForY(hue, chroma, yFromLstar(tone));
        return mul(XYZ_TO_SRGB, xyzFromJch(j, chroma, hue));
    }

    private static boolean inGamut(double[] lin) {
        double eps = 0.01;
        for (double c : lin) {
            if (c < -eps || c > 100 + eps) {
                return false;
            }
        }
        return true;
    }

    // ─── sRGB ────────────────────────────────────────────────────────────────

    static double linearized(int c8) {
        double n = c8 / 255.0;
        return (n <= 0.040449936 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4)) * 100;
    }

    private static int delinearized(double c) {
        double n = c / 100.0;
        double v = n <= 0.0031308 ? n * 12.92 : 1.055 * Math.pow(n, 1 / 2.4) - 0.055;
        return (int) Math.max(0, Math.min(255, roundHalfEven(v * 255)));
    }

    /** Банковское округление, как {@code round()} в Python (и как в лаунчере). */
    private static double roundHalfEven(double x) {
        double r = Math.floor(x + 0.5); // Math.round из JS: половина — вверх
        double frac = Math.abs(x % 1);
        return frac == 0.5 && r % 2 != 0 ? r - 1 : r;
    }

    private static double labF(double t) {
        double e = 216.0 / 24389.0;
        double k = 24389.0 / 27.0;
        return t > e ? Math.pow(t, 1.0 / 3.0) : (k * t + 16) / 116;
    }

    private static double labInvF(double ft) {
        double e = 216.0 / 24389.0;
        double k = 24389.0 / 27.0;
        double ft3 = ft * ft * ft;
        return ft3 > e ? ft3 : (116 * ft - 16) / k;
    }

    private static double clamp100(double v) {
        return Math.max(0, Math.min(100, v));
    }

    private static double sign(double v) {
        return v < 0 ? -1 : 1;
    }

    private static double[] mul(double[][] m, double[] v) {
        return new double[] {
            m[0][0] * v[0] + m[0][1] * v[1] + m[0][2] * v[2],
            m[1][0] * v[0] + m[1][1] * v[1] + m[1][2] * v[2],
            m[2][0] * v[0] + m[2][1] * v[1] + m[2][2] * v[2],
        };
    }
}
