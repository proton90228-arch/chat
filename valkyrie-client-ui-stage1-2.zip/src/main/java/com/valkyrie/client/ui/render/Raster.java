package com.valkyrie.client.ui.render;

/**
 * Аналитический растеризатор форм. Покрытие считается по знаковому расстоянию
 * до границы с шириной перехода в 1 физический пиксель, поэтому края одинаково
 * гладкие при любом масштабе GUI. Тени — честная гауссова свёртка формы.
 */
public final class Raster {
    private Raster() {
    }

    private static double coverage(double signedDistance) {
        double c = 0.5 - signedDistance;
        return c <= 0.0 ? 0.0 : c >= 1.0 ? 1.0 : c;
    }

    /**
     * Диск диаметром {@code d} пикселей. Его четверти — это углы скругления радиуса d/2,
     * поэтому одна маска обслуживает и круги, и скругления прямоугольников.
     */
    public static Mask disc(int d) {
        Mask mask = new Mask("disc" + d, d, d);
        double r = d / 2.0;
        // 4×4 суперсэмплинг на границе: точная площадь даже для крошечных кругов.
        for (int y = 0; y < d; y++) {
            for (int x = 0; x < d; x++) {
                double px = x + 0.5 - r;
                double py = y + 0.5 - r;
                double dist = Math.sqrt(px * px + py * py) - r;
                if (dist < -1.0) {
                    mask.set(x, y, 255);
                } else if (dist > 1.0) {
                    mask.set(x, y, 0);
                } else {
                    mask.setCoverage(x, y, superSampleDisc(x, y, r, r, r, -1.0));
                }
            }
        }
        return mask;
    }

    /** Кольцо: внешний диаметр {@code d}, толщина {@code stroke} (внутрь). */
    public static Mask ring(int d, float stroke) {
        Mask mask = new Mask("ring" + d + "_" + stroke, d, d);
        double r = d / 2.0;
        double inner = Math.max(0.0, r - stroke);
        for (int y = 0; y < d; y++) {
            for (int x = 0; x < d; x++) {
                double outer = superSampleDisc(x, y, r, r, r, -1.0);
                double hole = inner > 0.0 ? superSampleDisc(x, y, r, r, inner, -1.0) : 0.0;
                mask.setCoverage(x, y, outer - hole);
            }
        }
        return mask;
    }

    private static double superSampleDisc(int x, int y, double cx, double cy, double radius, double unused) {
        int inside = 0;
        double r2 = radius * radius;
        for (int sy = 0; sy < 4; sy++) {
            for (int sx = 0; sx < 4; sx++) {
                double px = x + (sx + 0.5) / 4.0 - cx;
                double py = y + (sy + 0.5) / 4.0 - cy;
                if (px * px + py * py <= r2) {
                    inside++;
                }
            }
        }
        // Смесь 16 сэмплов и SDF-оценки сглаживает «ступеньки» суперсэмплинга.
        double px = x + 0.5 - cx;
        double py = y + 0.5 - cy;
        double sdf = coverage(Math.sqrt(px * px + py * py) - radius);
        return (inside / 16.0) * 0.5 + sdf * 0.5;
    }

    /** Покрытие скруглённого прямоугольника {@code w×h} с радиусом {@code r}, полностью. */
    public static Mask roundRect(int w, int h, float r) {
        Mask mask = new Mask("rr" + w + "x" + h + "r" + r, w, h);
        double hw = w / 2.0;
        double hh = h / 2.0;
        double rr = Math.min(r, Math.min(hw, hh));
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                mask.setCoverage(x, y, coverage(sdRoundRect(x + 0.5 - hw, y + 0.5 - hh, hw, hh, rr)));
            }
        }
        return mask;
    }

    /** Знаковое расстояние до скруглённого прямоугольника с полуразмерами (hw, hh). */
    public static double sdRoundRect(double px, double py, double hw, double hh, double r) {
        double qx = Math.abs(px) - hw + r;
        double qy = Math.abs(py) - hh + r;
        double ox = Math.max(qx, 0.0);
        double oy = Math.max(qy, 0.0);
        return Math.sqrt(ox * ox + oy * oy) + Math.min(Math.max(qx, qy), 0.0) - r;
    }

    /**
     * Тень скруглённого прямоугольника для 9-slice: размытая гауссом (σ) форма
     * размера {@code 2(r+e)} с полем {@code e = ⌈3σ⌉} со всех сторон. Четверти маски —
     * углы тени, центральные строка и столбец — профили краёв.
     * Размер маски {@code 2P × 2P}, где {@code P = r + 2e}.
     */
    public static Mask shadowSheet(int r, float sigma) {
        int e = Math.max(1, (int) Math.ceil(sigma * 3.0f));
        int inner = 2 * (r + e);
        return blurredRoundRect("shadow" + r + "s" + sigma, inner, inner, r, sigma, e);
    }

    /** Полная размытая маска для маленьких элементов, где 9-slice не помещается. */
    public static Mask shadowFull(int w, int h, int r, float sigma) {
        int e = Math.max(1, (int) Math.ceil(sigma * 3.0f));
        return blurredRoundRect("shadowF" + w + "x" + h + "r" + r + "s" + sigma, w, h, r, sigma, e);
    }

    public static int shadowExtent(float sigma) {
        return Math.max(1, (int) Math.ceil(sigma * 3.0f));
    }

    private static Mask blurredRoundRect(String name, int w, int h, int r, float sigma, int e) {
        int mw = w + 2 * e;
        int mh = h + 2 * e;
        float[] src = new float[mw * mh];
        double hw = w / 2.0;
        double hh = h / 2.0;
        double rr = Math.min(r, Math.min(hw, hh));
        for (int y = 0; y < mh; y++) {
            for (int x = 0; x < mw; x++) {
                double px = x + 0.5 - e - hw;
                double py = y + 0.5 - e - hh;
                src[y * mw + x] = (float) coverage(sdRoundRect(px, py, hw, hh, rr));
            }
        }
        float[] kernel = gaussian(sigma, e);
        float[] tmp = new float[mw * mh];
        // Горизонтальный проход (за краем — ноль).
        for (int y = 0; y < mh; y++) {
            for (int x = 0; x < mw; x++) {
                float acc = 0.0f;
                for (int k = -e; k <= e; k++) {
                    int sx = x + k;
                    if (sx >= 0 && sx < mw) {
                        acc += src[y * mw + sx] * kernel[k + e];
                    }
                }
                tmp[y * mw + x] = acc;
            }
        }
        Mask mask = new Mask(name, mw, mh);
        for (int y = 0; y < mh; y++) {
            for (int x = 0; x < mw; x++) {
                float acc = 0.0f;
                for (int k = -e; k <= e; k++) {
                    int sy = y + k;
                    if (sy >= 0 && sy < mh) {
                        acc += tmp[sy * mw + x] * kernel[k + e];
                    }
                }
                mask.setCoverage(x, y, acc);
            }
        }
        return mask;
    }

    private static float[] gaussian(float sigma, int radius) {
        float[] kernel = new float[radius * 2 + 1];
        double sum = 0.0;
        double s = Math.max(0.3, sigma);
        for (int i = -radius; i <= radius; i++) {
            double v = Math.exp(-(i * i) / (2.0 * s * s));
            kernel[i + radius] = (float) v;
            sum += v;
        }
        for (int i = 0; i < kernel.length; i++) {
            kernel[i] /= (float) sum;
        }
        return kernel;
    }
}
