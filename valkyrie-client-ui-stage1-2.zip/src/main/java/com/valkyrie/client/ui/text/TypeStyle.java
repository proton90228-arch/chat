package com.valkyrie.client.ui.text;

/**
 * Типографическая шкала клиента (M3 type scale в единицах GUI Minecraft).
 * Как в лаунчере: Jost — дисплейные строки, заголовки и подписи; Inter — основной текст.
 * Размеры подобраны так, чтобы при масштабе GUI 2 текст совпадал с лаунчером на 100%.
 */
public enum TypeStyle {
    DISPLAY_SMALL(Fonts.Face.JOST_LIGHT, 18.0f, 22.0f, -0.01f),
    HEADLINE_MEDIUM(Fonts.Face.JOST_LIGHT, 15.0f, 18.0f, -0.005f),
    HEADLINE_SMALL(Fonts.Face.JOST_REGULAR, 12.5f, 16.0f, 0.0f),
    TITLE_LARGE(Fonts.Face.JOST_REGULAR, 10.5f, 13.0f, 0.0f),
    TITLE_MEDIUM(Fonts.Face.JOST_MEDIUM, 8.0f, 11.0f, 0.006f),
    TITLE_SMALL(Fonts.Face.JOST_MEDIUM, 7.0f, 10.0f, 0.008f),
    BODY_LARGE(Fonts.Face.INTER_REGULAR, 7.5f, 11.0f, 0.0f),
    BODY_MEDIUM(Fonts.Face.INTER_REGULAR, 6.5f, 9.5f, 0.0f),
    BODY_SMALL(Fonts.Face.INTER_REGULAR, 5.75f, 8.5f, 0.01f),
    LABEL_LARGE(Fonts.Face.JOST_MEDIUM, 7.0f, 10.0f, 0.01f),
    LABEL_MEDIUM(Fonts.Face.JOST_MEDIUM, 6.25f, 8.5f, 0.02f),
    LABEL_SMALL(Fonts.Face.JOST_MEDIUM, 5.5f, 7.5f, 0.03f),
    NUMERIC(Fonts.Face.JOST_MEDIUM, 6.5f, 9.0f, 0.0f),
    MONO(Fonts.Face.MONO, 6.0f, 9.0f, 0.0f),
    /** Совместимость со старыми экранами: строка высотой 9 как у прежнего шрифта. */
    UI_TEXT(Fonts.Face.INTER_REGULAR, 7.0f, 9.0f, 0.0f),
    UI_TITLE(Fonts.Face.JOST_MEDIUM, 7.75f, 9.0f, 0.006f);

    public final Fonts.Face face;
    /** Кегль (em) в единицах GUI. */
    public final float size;
    /** Высота строки в единицах GUI. */
    public final float lineHeight;
    /** Трекинг в долях em. */
    public final float tracking;

    TypeStyle(Fonts.Face face, float size, float lineHeight, float tracking) {
        this.face = face;
        this.size = size;
        this.lineHeight = lineHeight;
        this.tracking = tracking;
    }
}
