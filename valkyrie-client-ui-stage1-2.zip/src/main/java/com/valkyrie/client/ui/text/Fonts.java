package com.valkyrie.client.ui.text;

import java.util.EnumMap;
import java.util.Map;

/** Реестр шрифтов клиента. Файлы лежат в {@code assets/valkyrieclient/font/}. */
public final class Fonts {
    public enum Face {
        JOST_LIGHT("jost-light.ttf"),
        JOST_REGULAR("jost-regular.ttf"),
        JOST_MEDIUM("jost-medium.ttf"),
        JOST_SEMIBOLD("jost-semibold.ttf"),
        INTER_REGULAR("inter-regular.ttf"),
        INTER_BOLD("inter-bold.ttf"),
        NUNITO("nunito.ttf"),
        MONO("jetbrains-mono.ttf");

        public final String file;

        Face(String file) {
            this.file = file;
        }
    }

    private static final String ROOT = "/assets/valkyrieclient/font/";
    private static final Map<Face, FontFace> FACES = new EnumMap<>(Face.class);

    private Fonts() {
    }

    public static synchronized FontFace get(Face face) {
        FontFace loaded = FACES.get(face);
        if (loaded == null) {
            FontFace fallback = switch (face) {
                case NUNITO, MONO -> FontFace.system();
                case INTER_REGULAR, INTER_BOLD -> get(Face.NUNITO);
                case JOST_REGULAR -> get(Face.INTER_REGULAR);
                default -> get(Face.JOST_REGULAR);
            };
            loaded = FontFace.load(face.name().toLowerCase(), ROOT + face.file, fallback);
            FACES.put(face, loaded);
        }
        return loaded;
    }

    public static FontFace get(TypeStyle style) {
        return get(style.face);
    }
}
