package com.valkyrie.client.ui.mc;

import com.valkyrie.client.gui.CompanionReactions;
import com.valkyrie.client.module.ModuleRegistry;
import com.valkyrie.client.module.Setting;
import com.valkyrie.client.module.impl.DarkThemeModule;
import com.valkyrie.client.ui.clickgui.GuiModel;
import com.valkyrie.client.ui.clickgui.ModuleIcons;
import com.valkyrie.client.ui.color.Scheme;
import com.valkyrie.client.ui.icon.Icon;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/** {@link GuiModel} поверх {@link ModuleRegistry}: новый модуль появляется в ClickGUI сам. */
public final class ModuleGuiModel implements GuiModel {
    private static final int[] ACCENT_SWATCHES = presets();
    private static final int[] COLOR_SWATCHES = {
        0xFFDF91AA, 0xFFB3A0D2, 0xFF8FB4DE, 0xFF93B47E, 0xFFE39A6E, 0xFFF2D28C, 0xFFFFFFFF,
    };

    private final List<GuiModel.Category> categories = new ArrayList<>();
    private final Map<Setting<?>, Option> options = new IdentityHashMap<>();

    public ModuleGuiModel() {
        for (com.valkyrie.client.module.Category category : com.valkyrie.client.module.Category.values()) {
            List<com.valkyrie.client.module.Module> modules = ModuleRegistry.byCategory(category);
            if (modules.isEmpty()) {
                continue;
            }
            List<GuiModel.Module> items = new ArrayList<>();
            for (com.valkyrie.client.module.Module module : modules) {
                items.add(new ModuleItem(module));
            }
            categories.add(new CategoryItem(category.title(), ModuleIcons.forCategory(category.title()), items));
        }
    }

    private static int[] presets() {
        Scheme.Preset[] values = Scheme.Preset.values();
        int[] out = new int[values.length];
        for (int i = 0; i < values.length; i++) {
            out[i] = values[i].seed;
        }
        return out;
    }

    @Override
    public List<GuiModel.Category> categories() {
        return categories;
    }

    @Override
    public boolean dark() {
        return ModuleRegistry.get(DarkThemeModule.class).isEnabled();
    }

    @Override
    public void setDark(boolean dark) {
        ModuleRegistry.get(DarkThemeModule.class).setEnabled(dark);
    }

    private record CategoryItem(String title, Icon icon, List<GuiModel.Module> modules) implements GuiModel.Category {
    }

    private final class ModuleItem implements GuiModel.Module {
        private final com.valkyrie.client.module.Module module;
        private final List<Option> visible = new ArrayList<>();

        ModuleItem(com.valkyrie.client.module.Module module) {
            this.module = module;
        }

        @Override
        public String name() {
            return module.name();
        }

        @Override
        public String description() {
            return module.description();
        }

        @Override
        public Icon icon() {
            return ModuleIcons.forModule(module.name());
        }

        @Override
        public boolean toggleable() {
            return module.hasToggle() && !module.isAction();
        }

        @Override
        public boolean enabled() {
            return module.isEnabled();
        }

        @Override
        public void toggle() {
            module.toggle();
            CompanionReactions.moduleToggled(module.isEnabled());
        }

        @Override
        public String actionLabel() {
            return module.isAction() ? module.actionLabel() : null;
        }

        @Override
        public void action() {
            module.runAction();
        }

        @Override
        public List<Option> options() {
            visible.clear();
            for (Setting<?> setting : module.settings()) {
                Option option = options.computeIfAbsent(setting, ModuleGuiModel::wrap);
                if (option != null) {
                    visible.add(option);
                }
            }
            return visible;
        }

        @Override
        public boolean expanded() {
            return module.isExpanded();
        }

        @Override
        public void setExpanded(boolean expanded) {
            module.setExpanded(expanded);
        }
    }

    private static Option wrap(Setting<?> setting) {
        if (setting instanceof Setting.Bool bool) {
            return new BoolOption() {
                public String name() { return bool.name(); }
                public String description() { return bool.description() == null ? "" : bool.description(); }
                public boolean visible() { return bool.visible(); }
                public boolean value() { return bool.value(); }
                public void set(boolean value) {
                    bool.set(value);
                    CompanionReactions.settingChanged();
                }
            };
        }
        if (setting instanceof Setting.Slider slider) {
            return new SliderOption() {
                public String name() { return slider.name(); }
                public boolean visible() { return slider.visible(); }
                public float min() { return slider.min(); }
                public float max() { return slider.max(); }
                public float value() { return slider.value(); }
                public void set(float value) { slider.set(value); }
                public String label() { return slider.label(); }
            };
        }
        if (setting instanceof Setting.Mode mode) {
            return new ModeOption() {
                public String name() { return mode.name(); }
                public boolean visible() { return mode.visible(); }
                public List<String> modes() { return mode.options(); }
                public String value() { return mode.value(); }
                public void set(String value) {
                    mode.set(value);
                    CompanionReactions.settingChanged();
                }
            };
        }
        if (setting instanceof Setting.Color color) {
            boolean accent = "accent".equals(color.key());
            return new ColorOption() {
                public String name() { return color.name(); }
                public boolean visible() { return color.visible(); }
                public int value() { return color.value(); }
                public void set(int value) {
                    color.set(value);
                    CompanionReactions.settingChanged();
                }
                public int[] swatches() { return accent ? ACCENT_SWATCHES : COLOR_SWATCHES; }
            };
        }
        return null;
    }
}
