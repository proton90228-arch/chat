package com.valkyrie.client.ui.render;

/**
 * Маска покрытия (альфа 0..255) в физических пикселях. Цвет задаётся при отрисовке
 * тонированием, поэтому одна маска обслуживает все цвета схемы.
 * <p>
 * Реализация {@link Canvas} сама решает, как держать маску на GPU; для этого здесь
 * есть поля {@link #handle} и {@link #uploadedVersion}. {@link #version} растёт при
 * изменении пикселей (страницы атласа глифов дописываются по ходу работы).
 */
public final class Mask {
    public final int width;
    public final int height;
    public final byte[] alpha;
    public final String name;
    public int version;
    /** Данные реализации холста (текстура). */
    public Object handle;
    public int uploadedVersion = -1;

    public Mask(String name, int width, int height) {
        this.name = name;
        this.width = Math.max(1, width);
        this.height = Math.max(1, height);
        this.alpha = new byte[this.width * this.height];
    }

    public int get(int x, int y) {
        return alpha[y * width + x] & 0xFF;
    }

    public void set(int x, int y, int a) {
        alpha[y * width + x] = (byte) (a < 0 ? 0 : Math.min(255, a));
    }

    /** Запись покрытия 0..1. */
    public void setCoverage(int x, int y, double coverage) {
        alpha[y * width + x] = (byte) Math.round(Math.max(0.0, Math.min(1.0, coverage)) * 255.0);
    }

    public void touch() {
        version++;
    }
}
