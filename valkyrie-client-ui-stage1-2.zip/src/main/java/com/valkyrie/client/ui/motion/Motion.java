package com.valkyrie.client.ui.motion;

/**
 * Общие часы интерфейса. {@link #beginFrame()} вызывается один раз за кадр корнем
 * отрисовки; пружины продвигаются лениво при первом чтении в кадре, поэтому
 * отдельного цикла обновления нет, а скрытые элементы просто «спят».
 */
public final class Motion {
    private static long frameId;
    private static long lastNanos;
    private static float dt = 1.0f / 60.0f;
    private static float time;
    private static boolean reduced;
    private static long manualClockNanos = -1L;

    private Motion() {
    }

    /** Отмечает начало кадра. Повторный вызов в том же кадре (≤ 1 мс) игнорируется. */
    public static void beginFrame() {
        long now = manualClockNanos >= 0 ? manualClockNanos : System.nanoTime();
        if (lastNanos != 0L && now - lastNanos < 1_000_000L && manualClockNanos < 0) {
            return;
        }
        float seconds = lastNanos == 0L ? 1.0f / 60.0f : (now - lastNanos) / 1.0e9f;
        // Защита от рывка после паузы/загрузки: не больше 1/20 с за шаг.
        dt = Math.max(0.0f, Math.min(seconds, 1.0f / 20.0f));
        time += dt;
        lastNanos = now;
        frameId++;
    }

    public static long frameId() {
        return frameId;
    }

    /** Длительность текущего кадра, с. */
    public static float dt() {
        return dt;
    }

    /** Монотонное время интерфейса, с. */
    public static float time() {
        return time;
    }

    public static boolean reduced() {
        return reduced;
    }

    public static void setReduced(boolean value) {
        reduced = value;
    }

    /** Детерминированные часы для превью и тестов: следующий кадр наступит через {@code seconds}. */
    public static void advanceManual(float seconds) {
        if (manualClockNanos < 0) {
            manualClockNanos = System.nanoTime();
        }
        manualClockNanos += (long) (seconds * 1.0e9);
        beginFrame();
    }
}
