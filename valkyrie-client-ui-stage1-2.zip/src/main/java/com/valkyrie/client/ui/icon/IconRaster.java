package com.valkyrie.client.ui.icon;

import com.valkyrie.client.ui.render.Mask;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Растеризует иконки в маски нужного пиксельного размера (Java2D, сглаживание, «чистые» штрихи). */
public final class IconRaster {
    private record Op(char kind, Shape shape) {
    }

    private static final Map<Icon, List<Op>> PARSED = new EnumMap<>(Icon.class);

    private IconRaster() {
    }

    public static Mask render(Icon icon, int px) {
        return render(icon, px, 1.0f);
    }

    /** {@code weight} — множитель толщины штриха (1 — стандарт, 1.15 — активная иконка). */
    public static Mask render(Icon icon, int px, float weight) {
        int size = Math.max(4, px);
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setColor(Color.WHITE);
        float scale = size / 24.0f;
        AffineTransform transform = AffineTransform.getScaleInstance(scale, scale);
        // Минимальная толщина ~1.25 px, чтобы мелкие иконки не «рассыпались».
        float stroke = Math.max(1.25f, 2.0f * scale * weight);
        g.setStroke(new BasicStroke(stroke, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        for (Op op : ops(icon)) {
            Shape shape = transform.createTransformedShape(op.shape());
            if (op.kind() == 'F') {
                g.fill(shape);
            } else if (op.kind() == 'E') {
                g.setComposite(java.awt.AlphaComposite.Clear);
                g.fill(shape);
                g.setComposite(java.awt.AlphaComposite.SrcOver);
            } else {
                g.draw(shape);
            }
        }
        g.dispose();
        Mask mask = new Mask(icon.name() + "@" + size, size, size);
        byte[] gray = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
        System.arraycopy(gray, 0, mask.alpha, 0, gray.length);
        return mask;
    }

    private static synchronized List<Op> ops(Icon icon) {
        return PARSED.computeIfAbsent(icon, IconRaster::parse);
    }

    private static List<Op> parse(Icon icon) {
        List<Op> ops = new ArrayList<>();
        if (icon == Icon.SAKURA) {
            ops.add(new Op('F', sakura()));
            ops.add(new Op('E', new Ellipse2D.Float(12.0f - 1.7f, 12.4f - 1.7f, 3.4f, 3.4f)));
            return ops;
        }
        for (String part : icon.source.split(";")) {
            String p = part.trim();
            if (p.isEmpty()) {
                continue;
            }
            char kind = p.charAt(0);
            String rest = p.substring(1).trim();
            switch (kind) {
                case 'P' -> ops.add(new Op('S', SvgPath.parse(rest)));
                case 'F' -> ops.add(new Op('F', SvgPath.parse(rest)));
                case 'C', 'D' -> {
                    float[] v = numbers(rest);
                    Shape s = new Ellipse2D.Float(v[0] - v[2], v[1] - v[2], v[2] * 2, v[2] * 2);
                    ops.add(new Op(kind == 'C' ? 'S' : 'F', s));
                }
                case 'R', 'B' -> {
                    float[] v = numbers(rest);
                    Shape s = new RoundRectangle2D.Float(v[0], v[1], v[2], v[3], v[4] * 2, v[4] * 2);
                    ops.add(new Op(kind == 'R' ? 'S' : 'F', s));
                }
                default -> throw new IllegalArgumentException("bad icon op " + p);
            }
        }
        return ops;
    }

    private static float[] numbers(String s) {
        String[] parts = s.trim().split("[\\s,]+");
        float[] out = new float[parts.length];
        for (int i = 0; i < parts.length; i++) {
            out[i] = Float.parseFloat(parts[i]);
        }
        return out;
    }

    /** Цветок сакуры: пять лепестков с выемкой на конце, повёрнутых на 72°. */
    static Shape sakura() {
        Path2D.Float petal = new Path2D.Float();
        // Лепесток вверх от центра (12,12): основание узкое, вершина с вырезом.
        petal.moveTo(12.0f, 12.6f);
        petal.curveTo(9.0f, 10.4f, 8.1f, 6.6f, 9.6f, 3.6f);
        petal.curveTo(10.6f, 3.0f, 11.3f, 3.0f, 12.0f, 4.6f);
        petal.curveTo(12.7f, 3.0f, 13.4f, 3.0f, 14.4f, 3.6f);
        petal.curveTo(15.9f, 6.6f, 15.0f, 10.4f, 12.0f, 12.6f);
        petal.closePath();
        Path2D.Float flower = new Path2D.Float(Path2D.WIND_NON_ZERO);
        for (int i = 0; i < 5; i++) {
            AffineTransform r = AffineTransform.getRotateInstance(Math.toRadians(i * 72.0), 12.0, 12.4);
            flower.append(r.createTransformedShape(petal), false);
        }
        return flower;
    }
}
