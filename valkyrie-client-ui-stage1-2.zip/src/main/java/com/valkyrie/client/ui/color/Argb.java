package com.valkyrie.client.ui.color;

/** Операции над цветами ARGB (0xAARRGGBB). */
public final class Argb {
    private Argb() {
    }

    public static int a(int c) {
        return c >>> 24;
    }

    public static int r(int c) {
        return (c >> 16) & 0xFF;
    }

    public static int g(int c) {
        return (c >> 8) & 0xFF;
    }

    public static int b(int c) {
        return c & 0xFF;
    }

    public static int of(int a, int r, int g, int b) {
        return (clamp8(a) << 24) | (clamp8(r) << 16) | (clamp8(g) << 8) | clamp8(b);
    }

    /** Заменяет альфу на {@code alpha} (0..1). */
    public static int withAlpha(int c, float alpha) {
        return (clamp8(Math.round(alpha * 255.0f)) << 24) | (c & 0xFFFFFF);
    }

    /** Умножает существующую альфу на {@code factor} (0..1). */
    public static int fade(int c, float factor) {
        if (factor >= 1.0f) {
            return c;
        }
        int a = Math.round((c >>> 24) * Math.max(0.0f, factor));
        return (clamp8(a) << 24) | (c & 0xFFFFFF);
    }

    /** Линейное смешивание в sRGB, включая альфу. */
    public static int mix(int from, int to, float t) {
        if (t <= 0.0f) {
            return from;
        }
        if (t >= 1.0f) {
            return to;
        }
        return of(
            Math.round(a(from) + (a(to) - a(from)) * t),
            Math.round(r(from) + (r(to) - r(from)) * t),
            Math.round(g(from) + (g(to) - g(from)) * t),
            Math.round(b(from) + (b(to) - b(from)) * t)
        );
    }

    /**
     * Слой состояния M3: {@code overlay} с прозрачностью {@code opacity} поверх {@code base}.
     * Альфа результата — альфа основы, т. е. hover не делает полупрозрачную карточку плотнее.
     */
    public static int layer(int base, int overlay, float opacity) {
        if (opacity <= 0.0f) {
            return base;
        }
        int mixed = mix(base | 0xFF000000, overlay | 0xFF000000, Math.min(1.0f, opacity));
        return (base & 0xFF000000) | (mixed & 0xFFFFFF);
    }

    /** Смешивание в OKLab: переходы между тонами без «грязной» середины. */
    public static int mixOklab(int from, int to, float t) {
        if (t <= 0.0f || from == to) {
            return from;
        }
        if (t >= 1.0f) {
            return to;
        }
        float[] x = oklab(from);
        float[] y = oklab(to);
        float l = x[0] + (y[0] - x[0]) * t;
        float aa = x[1] + (y[1] - x[1]) * t;
        float bb = x[2] + (y[2] - x[2]) * t;
        int alpha = Math.round(a(from) + (a(to) - a(from)) * t);
        return (clamp8(alpha) << 24) | (fromOklab(l, aa, bb) & 0xFFFFFF);
    }

    /** Относительная яркость (0..1) — для выбора варианта текста и контраста. */
    public static float luminance(int c) {
        return (float) Hct.luminance(c);
    }

    // ─── OKLab ──────────────────────────────────────────────────────────────

    private static float toLinear(int c8) {
        float c = c8 / 255.0f;
        return c <= 0.04045f ? c / 12.92f : (float) Math.pow((c + 0.055f) / 1.055f, 2.4f);
    }

    private static int toSrgb8(float lin) {
        float v = lin <= 0.0031308f ? lin * 12.92f : 1.055f * (float) Math.pow(Math.max(0.0f, lin), 1.0f / 2.4f) - 0.055f;
        return clamp8(Math.round(v * 255.0f));
    }

    private static float[] oklab(int c) {
        float r = toLinear(r(c));
        float g = toLinear(g(c));
        float b = toLinear(b(c));
        float l = (float) Math.cbrt(0.4122214708f * r + 0.5363325363f * g + 0.0514459929f * b);
        float m = (float) Math.cbrt(0.2119034982f * r + 0.6806995451f * g + 0.1073969566f * b);
        float s = (float) Math.cbrt(0.0883024619f * r + 0.2817188376f * g + 0.6299787005f * b);
        return new float[] {
            0.2104542553f * l + 0.7936177850f * m - 0.0040720468f * s,
            1.9779984951f * l - 2.4285922050f * m + 0.4505937099f * s,
            0.0259040371f * l + 0.7827717662f * m - 0.8086757660f * s,
        };
    }

    private static int fromOklab(float l, float a, float b) {
        float l1 = l + 0.3963377774f * a + 0.2158037573f * b;
        float m1 = l - 0.1055613458f * a - 0.0638541728f * b;
        float s1 = l - 0.0894841775f * a - 1.2914855480f * b;
        l1 = l1 * l1 * l1;
        m1 = m1 * m1 * m1;
        s1 = s1 * s1 * s1;
        float r = 4.0767416621f * l1 - 3.3077115913f * m1 + 0.2309699292f * s1;
        float g = -1.2684380046f * l1 + 2.6097574011f * m1 - 0.3413193965f * s1;
        float bb = -0.0041960863f * l1 - 0.7034186147f * m1 + 1.7076147010f * s1;
        return 0xFF000000 | (toSrgb8(r) << 16) | (toSrgb8(g) << 8) | toSrgb8(bb);
    }

    private static int clamp8(int v) {
        return v < 0 ? 0 : Math.min(255, v);
    }
}
