package com.valkyrie.client.ui.clickgui;

import com.valkyrie.client.ui.icon.Icon;
import java.util.List;

/**
 * Модель ClickGUI без зависимостей от Minecraft: в игре её реализует адаптер над
 * {@code ModuleRegistry}, в песочнице — данные для PNG-превью.
 */
public interface GuiModel {
    List<Category> categories();

    /** Тёмная схема (модуль Dark mode) — быстрый переключатель в рейле. */
    boolean dark();

    void setDark(boolean dark);

    interface Category {
        String title();

        Icon icon();

        List<Module> modules();
    }

    interface Module {
        String name();

        String description();

        Icon icon();

        /** Есть ли переключатель (у «действий» вроде Edit layout его нет). */
        boolean toggleable();

        boolean enabled();

        void toggle();

        /** Подпись кнопки действия или {@code null}. */
        default String actionLabel() {
            return null;
        }

        default void action() {
        }

        List<Option> options();

        /** Раскрыт ли список настроек (сохраняется между открытиями). */
        default boolean expanded() {
            return false;
        }

        default void setExpanded(boolean expanded) {
        }
    }

    interface Option {
        String name();

        default String description() {
            return "";
        }

        default boolean visible() {
            return true;
        }
    }

    interface BoolOption extends Option {
        boolean value();

        void set(boolean value);
    }

    interface SliderOption extends Option {
        float min();

        float max();

        float value();

        void set(float value);

        /** Текст значения (через форматтер настройки). */
        String label();
    }

    interface ModeOption extends Option {
        List<String> modes();

        String value();

        void set(String value);
    }

    interface ColorOption extends Option {
        int value();

        void set(int value);

        /** Образцы цветов; для акцента — пресеты Sakura You. */
        int[] swatches();
    }
}
