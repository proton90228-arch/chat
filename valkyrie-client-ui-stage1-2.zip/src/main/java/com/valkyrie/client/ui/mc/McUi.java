package com.valkyrie.client.ui.mc;

import com.valkyrie.client.module.ModuleRegistry;
import com.valkyrie.client.module.impl.AppearanceModule;
import com.valkyrie.client.module.impl.DarkThemeModule;
import com.valkyrie.client.ui.color.Role;
import com.valkyrie.client.ui.motion.Motion;
import com.valkyrie.client.ui.render.Ui;
import com.valkyrie.client.ui.text.TypeStyle;
import com.valkyrie.client.ui.theme.UiTheme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Точка входа нового интерфейса для кода Minecraft. */
public final class McUi {
    private static long lastSync;

    private McUi() {
    }

    /** Начать рисование: часы кадра, тема, холст в физических пикселях. Парный вызов — {@link #end()}. */
    public static Ui begin(GuiGraphics graphics) {
        GuiCanvas canvas = GuiCanvas.get();
        if (canvas.begin(graphics)) {
            syncTheme(true);
            return Ui.get().begin(canvas);
        }
        return Ui.get();
    }

    public static void end() {
        GuiCanvas.get().end();
    }

    /** Цвет роли текущей схемы (с синхронизацией настроек не чаще раза в 50 мс). */
    public static int role(Role role) {
        syncTheme(false);
        return UiTheme.c(role);
    }

    public static int role(Role role, float alpha) {
        syncTheme(false);
        return UiTheme.c(role, alpha);
    }

    public static void syncTheme(boolean frame) {
        long now = System.nanoTime();
        if (!frame && now - lastSync < 50_000_000L) {
            return;
        }
        lastSync = now;
        Motion.beginFrame();
        try {
            AppearanceModule appearance = ModuleRegistry.get(AppearanceModule.class);
            DarkThemeModule dark = ModuleRegistry.get(DarkThemeModule.class);
            int accent = appearance.accent.value();
            UiTheme.sync((accent >>> 24) == 0 ? 0xFFDF91AA : accent, dark != null && dark.isEnabled());
            Motion.setReduced(appearance.reducedMotion.value());
        } catch (RuntimeException ignored) {
            // Реестр ещё не готов (ранняя загрузка) — остаёмся на текущей схеме.
        }
    }

    /** Ширина строки в GUI без активного кадра (для совместимых API шрифтов). */
    public static float textWidth(TypeStyle style, String text) {
        if (GuiCanvas.get().active()) {
            return Ui.get().textWidth(style, text);
        }
        var window = Minecraft.getInstance().getWindow();
        float scale = Math.max(1, Math.round((float) window.getWidth() / Math.max(1, window.getGuiScaledWidth())));
        if (Ui.get().canvas() == null || Ui.get().scale() != scale) {
            return measure(style, text, scale);
        }
        return Ui.get().textWidth(style, text);
    }

    private static float measure(TypeStyle style, String text, float scale) {
        if (text == null || text.isEmpty()) {
            return 0.0f;
        }
        var font = com.valkyrie.client.ui.text.Fonts.get(style).at(style.size * scale);
        var layout = font.layout(text);
        float tracking = style.tracking * style.size * scale;
        return (layout.width + tracking * Math.max(0, layout.count() - 1)) / scale;
    }
}
