package com.valkyrie.client.ui.mc;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.platform.Window;
import com.valkyrie.client.ui.render.Canvas;
import com.valkyrie.client.ui.render.Mask;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * {@link Canvas} поверх {@link GuiGraphics}: на время отрисовки поза масштабируется
 * на {@code 1/guiScale}, и все координаты — это физические пиксели окна.
 * Маски живут в {@link DynamicTexture}; изменённые страницы атласа догружаются
 * в конце прохода (GUI в 1.21.6+ рисуется отложенно, в конце кадра).
 */
public final class GuiCanvas implements Canvas {
    private static final GuiCanvas INSTANCE = new GuiCanvas();
    private static final long EVICT_NANOS = 30_000_000_000L;

    private GuiGraphics g;
    private float scale = 1.0f;
    private int width;
    private int height;
    private int depth;
    private int counter;
    private long lastEvict;
    private final List<Mask> live = new ArrayList<>();
    private final List<Mask> dirty = new ArrayList<>();

    private static final class Tex {
        ResourceLocation id;
        DynamicTexture texture;
        NativeImage image;
        long lastUsed;
    }

    private GuiCanvas() {
    }

    public static GuiCanvas get() {
        return INSTANCE;
    }

    /** {@code true}, если это внешний вызов (вложенные используют уже настроенную позу). */
    public boolean begin(GuiGraphics graphics) {
        if (depth++ > 0) {
            return false;
        }
        g = graphics;
        Window window = Minecraft.getInstance().getWindow();
        int gw = Math.max(1, window.getGuiScaledWidth());
        int gh = Math.max(1, window.getGuiScaledHeight());
        scale = Math.max(1, Math.round((float) window.getWidth() / gw));
        width = gw * Math.round(scale);
        height = gh * Math.round(scale);
        g.pose().pushMatrix();
        g.pose().scale(1.0f / scale, 1.0f / scale);
        return true;
    }

    public void end() {
        if (--depth > 0) {
            return;
        }
        depth = 0;
        g.pose().popMatrix();
        flush();
        evict();
        g = null;
    }

    public boolean active() {
        return depth > 0;
    }

    @Override
    public float scale() {
        return scale;
    }

    @Override
    public int width() {
        return width;
    }

    @Override
    public int height() {
        return height;
    }

    @Override
    public void fill(int x0, int y0, int x1, int y1, int argb) {
        if (x1 > x0 && y1 > y0) {
            g.fill(x0, y0, x1, y1, argb);
        }
    }

    @Override
    public void gradient(int x0, int y0, int x1, int y1, int argbTop, int argbBottom) {
        if (x1 > x0 && y1 > y0) {
            g.fillGradient(x0, y0, x1, y1, argbTop, argbBottom);
        }
    }

    @Override
    public void mask(Mask mask, int dx, int dy, int dw, int dh, int sx, int sy, int sw, int sh, int argb) {
        if (dw <= 0 || dh <= 0) {
            return;
        }
        g.blit(RenderPipelines.GUI_TEXTURED, texture(mask), dx, dy, (float) sx, (float) sy, dw, dh, sw, sh, mask.width, mask.height, argb);
    }

    /**
     * Ножницы задаются в единицах GUI при исходной позе: границы {@code Ui.clip}
     * уже выровнены по сетке GUI, поэтому деление точное.
     */
    @Override
    public void pushClip(int x0, int y0, int x1, int y1) {
        g.pose().pushMatrix();
        g.pose().scale(scale, scale);
        g.enableScissor(Math.round(x0 / scale), Math.round(y0 / scale), Math.round(x1 / scale), Math.round(y1 / scale));
        g.pose().popMatrix();
    }

    @Override
    public void popClip() {
        g.disableScissor();
    }

    private ResourceLocation texture(Mask mask) {
        Tex tex = mask.handle instanceof Tex t ? t : null;
        if (tex == null || tex.texture == null) {
            tex = new Tex();
            tex.id = ResourceLocation.fromNamespaceAndPath("valkyrieclient", "ui/mask_" + (counter++));
            tex.image = new NativeImage(NativeImage.Format.RGBA, mask.width, mask.height, false);
            write(mask, tex.image);
            String label = "valkyrie ui " + mask.name;
            tex.texture = new DynamicTexture(() -> label, tex.image);
            tex.texture.setFilter(false, false);
            tex.texture.upload();
            Minecraft.getInstance().getTextureManager().register(tex.id, tex.texture);
            mask.handle = tex;
            mask.uploadedVersion = mask.version;
            live.add(mask);
        } else if (mask.uploadedVersion != mask.version && !dirty.contains(mask)) {
            dirty.add(mask);
        }
        tex.lastUsed = System.nanoTime();
        return tex.id;
    }

    private static void write(Mask mask, NativeImage image) {
        byte[] alpha = mask.alpha;
        int w = mask.width;
        for (int y = 0; y < mask.height; y++) {
            int row = y * w;
            for (int x = 0; x < w; x++) {
                image.setPixelABGR(x, y, ((alpha[row + x] & 0xFF) << 24) | 0x00FFFFFF);
            }
        }
    }

    private void flush() {
        for (Mask mask : dirty) {
            if (mask.handle instanceof Tex tex && tex.texture != null) {
                write(mask, tex.image);
                tex.texture.upload();
                mask.uploadedVersion = mask.version;
            }
        }
        dirty.clear();
    }

    private void evict() {
        long now = System.nanoTime();
        if (now - lastEvict < 5_000_000_000L) {
            return;
        }
        lastEvict = now;
        Iterator<Mask> it = live.iterator();
        while (it.hasNext()) {
            Mask mask = it.next();
            if (mask.handle instanceof Tex tex && now - tex.lastUsed > EVICT_NANOS) {
                Minecraft.getInstance().getTextureManager().release(tex.id);
                tex.texture = null;
                mask.handle = null;
                mask.uploadedVersion = -1;
                it.remove();
            }
        }
    }
}
