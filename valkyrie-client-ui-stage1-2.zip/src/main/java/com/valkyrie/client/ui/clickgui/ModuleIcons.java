package com.valkyrie.client.ui.clickgui;

import com.valkyrie.client.ui.icon.Icon;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Иконки модулей и категорий (по имени — без правок в классах модулей). */
public final class ModuleIcons {
    private static final Map<String, Icon> BY_NAME = new HashMap<>();

    static {
        put(Icon.TAG, "watermark");
        put(Icon.KEYBOARD, "keystrokes");
        put(Icon.INFO, "info");
        put(Icon.SHIELD, "armor");
        put(Icon.FLASK, "effects");
        put(Icon.MOVE, "edit layout", "hud editor");
        put(Icon.PERSON, "target hud");
        put(Icon.CUBE, "esp");
        put(Icon.TRACERS, "tracers");
        put(Icon.HITMARKER, "hit marker");
        put(Icon.DROP, "damage tint");
        put(Icon.CROSSHAIR, "crosshair");
        put(Icon.SUN, "world time");
        put(Icon.GLOW, "target glow");
        put(Icon.SAKURA, "sakura bloom");
        put(Icon.STARS, "threat constellation");
        put(Icon.LENS, "intent lens");
        put(Icon.HISTORY, "memory echo");
        put(Icon.SELECT, "block highlight");
        put(Icon.ORBIT, "pearl prediction");
        put(Icon.TRAIL, "projectile trails");
        put(Icon.MOTION, "item animations");
        put(Icon.CAMERA, "camera effects");
        put(Icon.CHEST, "storage esp");
        put(Icon.PALETTE, "world color", "appearance");
        put(Icon.SWORD, "killaura", "kill aura");
        put(Icon.AIM, "aim assist");
        put(Icon.BOLT, "triggerbot", "trigger bot");
        put(Icon.SWAP, "autoweapon", "auto weapon");
        put(Icon.HEART, "autototem", "auto totem");
        put(Icon.BURST, "criticals");
        put(Icon.MOON, "dark mode");
        put(Icon.HOME, "main menu");
        put(Icon.FOCUS, "focus mode");
        put(Icon.LAYERS, "visual profiles");
    }

    private ModuleIcons() {
    }

    private static void put(Icon icon, String... names) {
        for (String n : names) {
            BY_NAME.put(n, icon);
        }
    }

    public static Icon forModule(String name) {
        Icon icon = BY_NAME.get(name.toLowerCase(Locale.ROOT));
        return icon != null ? icon : Icon.SPARKLE;
    }

    public static Icon forCategory(String title) {
        return switch (title.toLowerCase(Locale.ROOT)) {
            case "hud" -> Icon.DASHBOARD;
            case "visuals" -> Icon.EYE;
            case "combat" -> Icon.SWORD;
            default -> Icon.TUNE;
        };
    }
}
