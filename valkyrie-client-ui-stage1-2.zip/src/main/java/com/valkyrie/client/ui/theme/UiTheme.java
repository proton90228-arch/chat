package com.valkyrie.client.ui.theme;

import com.valkyrie.client.ui.color.Argb;
import com.valkyrie.client.ui.color.Role;
import com.valkyrie.client.ui.color.Scheme;
import com.valkyrie.client.ui.motion.Spring;
import com.valkyrie.client.ui.motion.SpringSpec;

/**
 * Текущая схема интерфейса. Смена акцента или режима не «щёлкает», а перетекает
 * в OKLab за ~300 мс — вся палитра клиента меняется одной плавной волной.
 */
public final class UiTheme {
    private static final Role[] ROLES = Role.all();
    private static Scheme target = Scheme.of(Scheme.Preset.SAKURA.seed, false);
    private static final int[] from = new int[ROLES.length];
    private static final int[] colors = new int[ROLES.length];
    private static final Spring progress = new Spring(1.0f, SpringSpec.SLOW_EFFECTS, 0.002f);
    private static float lastProgress = 1.0f;

    static {
        for (Role role : ROLES) {
            colors[role.ordinal()] = target.get(role);
            from[role.ordinal()] = colors[role.ordinal()];
        }
    }

    private UiTheme() {
    }

    /** Синхронизация с настройками; вызывается каждый кадр — без изменений ничего не делает. */
    public static void sync(int seed, boolean dark) {
        Scheme next = Scheme.of(seed, dark);
        if (next == target) {
            return;
        }
        // Старт перехода с текущих (возможно, промежуточных) цветов.
        refresh();
        System.arraycopy(colors, 0, from, 0, colors.length);
        target = next;
        progress.snap(0.0f).target(1.0f);
        lastProgress = -1.0f;
    }

    /** Мгновенно применить схему (превью, тесты). */
    public static void set(int seed, boolean dark) {
        target = Scheme.of(seed, dark);
        progress.snap(1.0f);
        for (Role role : ROLES) {
            colors[role.ordinal()] = target.get(role);
        }
        lastProgress = 1.0f;
    }

    private static void refresh() {
        float t = progress.value01();
        if (t == lastProgress) {
            return;
        }
        lastProgress = t;
        for (Role role : ROLES) {
            int i = role.ordinal();
            colors[i] = t >= 1.0f ? target.get(role) : Argb.mixOklab(from[i], target.get(role), t);
        }
    }

    public static int c(Role role) {
        refresh();
        return colors[role.ordinal()];
    }

    /** Цвет роли с альфой 0..1. */
    public static int c(Role role, float alpha) {
        return Argb.withAlpha(c(role), alpha);
    }

    public static boolean dark() {
        return target.dark;
    }

    public static int seed() {
        return target.seed;
    }

    public static Scheme scheme() {
        return target;
    }
}
