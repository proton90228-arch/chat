package com.valkyrie.client.ui.motion;

/**
 * Параметры пружины M3 (androidx Expressive/Standard motion tokens): коэффициент
 * затухания ζ и жёсткость k при единичной массе. Те же значения, что в {@code tokens.css} лаунчера.
 */
public record SpringSpec(float dampingRatio, float stiffness) {
    /** Быстрые пространственные движения с заметным перелётом (~9%): переключатели, индикаторы. */
    public static final SpringSpec EXPRESSIVE_FAST_SPATIAL = new SpringSpec(0.6f, 800.0f);
    /** Основные пространственные движения (~1.4% перелёта): карточки, панели. */
    public static final SpringSpec EXPRESSIVE_DEFAULT_SPATIAL = new SpringSpec(0.8f, 380.0f);
    /** Крупные и медленные перемещения: окно, складывание. */
    public static final SpringSpec EXPRESSIVE_SLOW_SPATIAL = new SpringSpec(0.8f, 200.0f);
    public static final SpringSpec STANDARD_FAST_SPATIAL = new SpringSpec(0.9f, 1400.0f);
    public static final SpringSpec STANDARD_DEFAULT_SPATIAL = new SpringSpec(0.9f, 700.0f);
    public static final SpringSpec STANDARD_SLOW_SPATIAL = new SpringSpec(0.9f, 300.0f);
    /** Эффекты (цвет, прозрачность) — без перелёта. */
    public static final SpringSpec FAST_EFFECTS = new SpringSpec(1.0f, 3800.0f);
    public static final SpringSpec DEFAULT_EFFECTS = new SpringSpec(1.0f, 1600.0f);
    public static final SpringSpec SLOW_EFFECTS = new SpringSpec(1.0f, 800.0f);

    /** При «уменьшении движения» пространственные пружины заменяются коротким затуханием. */
    public SpringSpec reduced() {
        return dampingRatio < 1.0f ? FAST_EFFECTS : this;
    }
}
