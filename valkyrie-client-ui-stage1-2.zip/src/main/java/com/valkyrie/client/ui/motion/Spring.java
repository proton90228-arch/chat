package com.valkyrie.client.ui.motion;

/**
 * Пружина с аналитическим решением: шаг не зависит от FPS и не разгоняется при
 * длинных кадрах. Значение продвигается лениво — один раз за кадр {@link Motion}.
 */
public final class Spring {
    private SpringSpec spec;
    private float value;
    private float velocity;
    private float target;
    private float threshold;
    private long frame = -1L;

    public Spring(float initial, SpringSpec spec) {
        this(initial, spec, 0.0005f);
    }

    /** {@code threshold} — точность, при которой пружина «засыпает» на цели (в единицах значения). */
    public Spring(float initial, SpringSpec spec, float threshold) {
        this.value = initial;
        this.target = initial;
        this.spec = spec;
        this.threshold = threshold;
    }

    public Spring spec(SpringSpec spec) {
        this.spec = spec;
        return this;
    }

    /** Новая цель; скорость сохраняется, поэтому смена направления плавная. */
    public Spring target(float target) {
        this.target = target;
        return this;
    }

    public Spring target(boolean on) {
        return target(on ? 1.0f : 0.0f);
    }

    /** Мгновенно ставит значение и цель (без анимации). */
    public Spring snap(float value) {
        this.value = value;
        this.target = value;
        this.velocity = 0.0f;
        this.frame = Motion.frameId();
        return this;
    }

    /** Толчок скорости — для «упругого» отклика без смены цели. */
    public Spring kick(float velocity) {
        this.velocity += velocity;
        return this;
    }

    public float target() {
        return target;
    }

    public float velocity() {
        advance();
        return velocity;
    }

    public boolean settled() {
        advance();
        return value == target && velocity == 0.0f;
    }

    /** Текущее значение (с продвижением на текущий кадр). */
    public float value() {
        advance();
        return value;
    }

    /** Значение, ограниченное [0, 1] — для прозрачностей при пружинах с перелётом. */
    public float value01() {
        float v = value();
        return v < 0.0f ? 0.0f : Math.min(1.0f, v);
    }

    private void advance() {
        long now = Motion.frameId();
        if (frame == now) {
            return;
        }
        float dt = frame < 0 ? 0.0f : Motion.dt();
        frame = now;
        if (value == target && velocity == 0.0f) {
            return;
        }
        step(dt);
    }

    /** Точный шаг затухающего осциллятора длиной {@code dt} секунд. */
    void step(float dt) {
        SpringSpec s = Motion.reduced() ? spec.reduced() : spec;
        double omega = Math.sqrt(s.stiffness());
        double zeta = s.dampingRatio();
        double x0 = value - target;
        double v0 = velocity;
        double x;
        double v;
        if (zeta < 1.0) {
            double wd = omega * Math.sqrt(1.0 - zeta * zeta);
            double decay = Math.exp(-zeta * omega * dt);
            double cos = Math.cos(wd * dt);
            double sin = Math.sin(wd * dt);
            double b = (v0 + zeta * omega * x0) / wd;
            x = decay * (x0 * cos + b * sin);
            // d/dt[e^{-ζωt}(x0·cos + b·sin)] = -ζω·x + e^{-ζωt}·wd·(b·cos − x0·sin)
            v = -zeta * omega * x + decay * wd * (b * cos - x0 * sin);
        } else if (zeta == 1.0) {
            double decay = Math.exp(-omega * dt);
            double b = v0 + omega * x0;
            x = (x0 + b * dt) * decay;
            v = (v0 - omega * b * dt) * decay;
        } else {
            double root = Math.sqrt(zeta * zeta - 1.0);
            double r1 = -omega * (zeta - root);
            double r2 = -omega * (zeta + root);
            double c1 = (v0 - r2 * x0) / (r1 - r2);
            double c2 = x0 - c1;
            double e1 = Math.exp(r1 * dt);
            double e2 = Math.exp(r2 * dt);
            x = c1 * e1 + c2 * e2;
            v = c1 * r1 * e1 + c2 * r2 * e2;
        }
        if (Math.abs(x) < threshold && Math.abs(v) < threshold * 10.0) {
            value = target;
            velocity = 0.0f;
        } else {
            value = (float) (target + x);
            velocity = (float) v;
        }
    }
}
