package com.valkyrie.client.ui.color;

/**
 * Цветовые роли Sakura You (M3 + роли бренда и состояний лаунчера).
 * Для каждой роли: палитра и тон в светлой и тёмной схеме — один в один с {@code scheme.ts}.
 */
public enum Role {
    PRIMARY("primary", 'P', 40, 'P', 80),
    ON_PRIMARY("on-primary", 'P', 100, 'P', 20),
    PRIMARY_CONTAINER("primary-container", 'P', 90, 'P', 30),
    ON_PRIMARY_CONTAINER("on-primary-container", 'P', 30, 'P', 90),
    SECONDARY("secondary", 'S', 40, 'S', 80),
    ON_SECONDARY("on-secondary", 'S', 100, 'S', 20),
    SECONDARY_CONTAINER("secondary-container", 'S', 90, 'S', 30),
    ON_SECONDARY_CONTAINER("on-secondary-container", 'S', 30, 'S', 90),
    TERTIARY("tertiary", 'T', 40, 'T', 80),
    ON_TERTIARY("on-tertiary", 'T', 100, 'T', 20),
    TERTIARY_CONTAINER("tertiary-container", 'T', 90, 'T', 30),
    ON_TERTIARY_CONTAINER("on-tertiary-container", 'T', 30, 'T', 90),
    ERROR("error", 'E', 40, 'E', 80),
    ON_ERROR("on-error", 'E', 100, 'E', 20),
    ERROR_CONTAINER("error-container", 'E', 90, 'E', 30),
    ON_ERROR_CONTAINER("on-error-container", 'E', 30, 'E', 90),
    SURFACE("surface", 'N', 99, 'D', 6),
    SURFACE_DIM("surface-dim", 'N', 88, 'D', 6),
    SURFACE_BRIGHT("surface-bright", 'N', 99, 'D', 24),
    SURFACE_CONTAINER_LOWEST("surface-container-lowest", 'N', 100, 'D', 4),
    SURFACE_CONTAINER_LOW("surface-container-low", 'N', 97, 'D', 10),
    SURFACE_CONTAINER("surface-container", 'N', 95, 'D', 12),
    SURFACE_CONTAINER_HIGH("surface-container-high", 'N', 93, 'D', 17),
    SURFACE_CONTAINER_HIGHEST("surface-container-highest", 'N', 91, 'D', 22),
    ON_SURFACE("on-surface", 'N', 10, 'D', 92),
    ON_SURFACE_VARIANT("on-surface-variant", 'V', 30, 'V', 80),
    OUTLINE("outline", 'V', 50, 'V', 60),
    OUTLINE_VARIANT("outline-variant", 'V', 85, 'V', 30),
    INVERSE_SURFACE("inverse-surface", 'N', 20, 'D', 90),
    INVERSE_ON_SURFACE("inverse-on-surface", 'N', 95, 'D', 20),
    INVERSE_PRIMARY("inverse-primary", 'P', 80, 'P', 40),
    SCRIM("scrim", 'N', 0, 'N', 0),
    SHADOW("shadow", 'N', 0, 'N', 0),
    PRIMARY_FIXED("primary-fixed", 'P', 90, 'P', 90),
    PRIMARY_FIXED_DIM("primary-fixed-dim", 'P', 80, 'P', 80),
    ON_PRIMARY_FIXED("on-primary-fixed", 'P', 10, 'P', 10),
    ON_PRIMARY_FIXED_VARIANT("on-primary-fixed-variant", 'P', 30, 'P', 30),
    PETAL("petal", 'P', 80, 'P', 70),
    PETAL_SOFT("petal-soft", 'P', 90, 'P', 40),
    BRAND("brand", 'P', 50, 'P', 70),
    ON_BRAND("on-brand", 'P', 100, 'P', 10),
    // Расширенные роли состояний (лаунчер: install/update/success).
    INSTALL("install", 'i', 40, 'i', 80),
    ON_INSTALL("on-install", 'i', 100, 'i', 20),
    INSTALL_CONTAINER("install-container", 'i', 90, 'i', 30),
    ON_INSTALL_CONTAINER("on-install-container", 'i', 30, 'i', 90),
    UPDATE("update", 'u', 40, 'u', 80),
    ON_UPDATE("on-update", 'u', 100, 'u', 20),
    UPDATE_CONTAINER("update-container", 'u', 90, 'u', 30),
    ON_UPDATE_CONTAINER("on-update-container", 'u', 30, 'u', 90),
    SUCCESS("success", 's', 40, 's', 80),
    ON_SUCCESS("on-success", 's', 100, 's', 20),
    SUCCESS_CONTAINER("success-container", 's', 90, 's', 30),
    ON_SUCCESS_CONTAINER("on-success-container", 's', 30, 's', 90);

    public final String token;
    final char lightPalette;
    final int lightTone;
    final char darkPalette;
    final int darkTone;

    Role(String token, char lightPalette, int lightTone, char darkPalette, int darkTone) {
        this.token = token;
        this.lightPalette = lightPalette;
        this.lightTone = lightTone;
        this.darkPalette = darkPalette;
        this.darkTone = darkTone;
    }

    private static final Role[] VALUES = values();

    public static Role[] all() {
        return VALUES;
    }
}
