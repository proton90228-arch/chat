package com.valkyrie.client.ui.color;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Схема Sakura You: все роли {@link Role} для одного seed-цвета и режима.
 * <p>
 * Палитры как в лаунчере: P — chroma ≥ 36, S — 16, T — hue+60 / 24, N — 4, NV — 8,
 * DN — тёмная нейтраль с hue−28 и chroma 7 (сумеречный фиолет вместо серого),
 * E — ошибка, гармонизированная к seed.
 */
public final class Scheme {
    /** Пресеты лаунчера. */
    public enum Preset {
        SAKURA("Сакура", "桜", 0xFFDF91AA),
        FUJI("Глициния", "藤", 0xFFB3A0D2),
        MOMIJI("Момидзи", "紅葉", 0xFFE39A6E),
        MATCHA("Матча", "抹茶", 0xFF93B47E),
        SORA("Сора", "空", 0xFF8FB4DE);

        public final String title;
        public final String kanji;
        public final int seed;

        Preset(String title, String kanji, int seed) {
            this.title = title;
            this.kanji = kanji;
            this.seed = seed;
        }

        /** Пресет с точно таким seed или {@code null}. */
        public static Preset bySeed(int argb) {
            for (Preset preset : values()) {
                if ((preset.seed & 0xFFFFFF) == (argb & 0xFFFFFF)) {
                    return preset;
                }
            }
            return null;
        }
    }

    private static final Map<Long, Scheme> CACHE = new ConcurrentHashMap<>();

    public final int seed;
    public final boolean dark;
    private final int[] colors;

    private Scheme(int seed, boolean dark, int[] colors) {
        this.seed = seed;
        this.dark = dark;
        this.colors = colors;
    }

    /** Схема для seed (альфа игнорируется). Результаты кэшируются. */
    public static Scheme of(int seed, boolean dark) {
        int rgb = seed & 0xFFFFFF;
        long key = ((long) rgb << 1) | (dark ? 1 : 0);
        return CACHE.computeIfAbsent(key, k -> build(0xFF000000 | rgb, dark));
    }

    public int get(Role role) {
        return colors[role.ordinal()];
    }

    /** Цвет роли с альфой 0..1. */
    public int get(Role role, float alpha) {
        return Argb.withAlpha(colors[role.ordinal()], alpha);
    }

    /** Покомпонентная интерполяция двух схем — для плавной смены акцента/режима. */
    public static int[] lerp(Scheme from, Scheme to, float t, int[] out) {
        for (int i = 0; i < out.length; i++) {
            out[i] = Argb.mixOklab(from.colors[i], to.colors[i], t);
        }
        return out;
    }

    int[] raw() {
        return colors;
    }

    private static Scheme build(int seed, boolean dark) {
        double[] hct = Hct.fromArgb(seed);
        double hue = hct[0];
        double chroma = hct[1];
        Map<Character, TonalPalette> palettes = new EnumKeyMap();
        palettes.put('P', new TonalPalette(hue, Math.max(chroma, 36.0)));
        palettes.put('S', new TonalPalette(hue, 16.0));
        palettes.put('T', new TonalPalette(hue + 60.0, 24.0));
        palettes.put('N', new TonalPalette(hue, 4.0));
        palettes.put('V', new TonalPalette(hue, 8.0));
        palettes.put('D', new TonalPalette(Hct.mod360(hue - 28.0), 7.0));
        double[] error = Hct.harmonize(0xFFB3261E, seed);
        palettes.put('E', new TonalPalette(error[0], Math.max(error[1], 60.0)));
        double[] install = Hct.harmonize(0xFF9D8AB8, seed);
        palettes.put('i', new TonalPalette(install[0], Math.max(install[1], 36.0)));
        double[] update = Hct.harmonize(0xFFD9925F, seed);
        palettes.put('u', new TonalPalette(update[0], Math.max(update[1], 36.0)));
        double[] success = Hct.fromArgb(0xFF4FB98A); // «успех» не гармонизируется
        palettes.put('s', new TonalPalette(success[0], Math.max(success[1], 36.0)));

        Role[] roles = Role.all();
        int[] colors = new int[roles.length];
        for (Role role : roles) {
            char palette = dark ? role.darkPalette : role.lightPalette;
            int tone = dark ? role.darkTone : role.lightTone;
            colors[role.ordinal()] = palettes.get(palette).tone(tone);
        }
        return new Scheme(seed, dark, colors);
    }

    /** Маленькая карта по символу палитры (HashMap без лишних аллокаций boxed-ключей не нужен). */
    private static final class EnumKeyMap extends java.util.HashMap<Character, TonalPalette> {
    }

    /** Для отладки и тестов: роль → цвет. */
    public Map<Role, Integer> asMap() {
        Map<Role, Integer> map = new EnumMap<>(Role.class);
        for (Role role : Role.all()) {
            map.put(role, colors[role.ordinal()]);
        }
        return map;
    }
}
