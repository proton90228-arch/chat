package com.valkyrie.client.ui.clickgui;

import com.valkyrie.client.ui.color.Argb;
import com.valkyrie.client.ui.color.Role;
import com.valkyrie.client.ui.icon.Icon;
import com.valkyrie.client.ui.motion.Motion;
import com.valkyrie.client.ui.motion.Spring;
import com.valkyrie.client.ui.motion.SpringSpec;
import com.valkyrie.client.ui.render.Ui;
import com.valkyrie.client.ui.text.TypeStyle;
import com.valkyrie.client.ui.theme.Elevation;
import com.valkyrie.client.ui.theme.UiTheme;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * ClickGUI «гибрид»: единое окно с навигационным рейлом слева (как в лаунчере)
 * и карточками модулей в колонках справа. Настройки раскрываются прямо в карточке,
 * окно складывается в рейл («Book Fold»). Не зависит от Minecraft: рисует через {@link Ui},
 * ввод получает в координатах GUI.
 */
public final class ClickGuiView {
    public enum Sound { NAV, CLICK, TOGGLE_ON, TOGGLE_OFF, EXPAND, COLLAPSE, SLIDER, OPEN, CLOSE }

    /** Связь с игрой: звуки, закрытие, модель игрока, сохранение состояния. */
    public interface Host {
        void sound(Sound sound);

        void close();

        default void companion(Ui ui, float x, float y, float w, float h, float alpha) {
        }

        default String playerName() {
            return "Player";
        }

        default void stateChanged(int category, boolean folded) {
        }
    }

    // ─── Размеры (единицы GUI) ──────────────────────────────────────────────
    private static final float RAIL_W = 64.0f;
    private static final float RADIUS = 18.0f;
    private static final float CARD_R = 12.0f;
    private static final float HEAD_H = 36.0f;
    private static final float GAP = 8.0f;
    private static final float MIN_CARD_W = 150.0f;
    private static final float NAV_TOP = 46.0f;
    private static final float NAV_STEP = 40.0f;

    private final GuiModel model;
    private final Host host;

    private int category;
    private boolean folded;
    private boolean closing;
    private final Spring appear = new Spring(0.0f, SpringSpec.EXPRESSIVE_DEFAULT_SPATIAL, 0.001f);
    private final Spring fold = new Spring(0.0f, SpringSpec.EXPRESSIVE_DEFAULT_SPATIAL, 0.001f);
    private final Spring navY = new Spring(0.0f, SpringSpec.EXPRESSIVE_FAST_SPATIAL, 0.001f);
    private final Spring navGrow = new Spring(1.0f, SpringSpec.EXPRESSIVE_FAST_SPATIAL, 0.001f);
    private final Spring contentIn = new Spring(1.0f, SpringSpec.EXPRESSIVE_DEFAULT_SPATIAL, 0.001f);
    private final Spring scroll = new Spring(0.0f, SpringSpec.STANDARD_DEFAULT_SPATIAL, 0.02f);
    private final Spring searchFocusS = new Spring(0.0f, SpringSpec.DEFAULT_EFFECTS, 0.002f);
    private final Spring scrollbar = new Spring(0.0f, SpringSpec.DEFAULT_EFFECTS, 0.002f);
    private final Spring menuS = new Spring(0.0f, SpringSpec.EXPRESSIVE_FAST_SPATIAL, 0.001f);
    private float scrollTarget;
    private float lastScrollAt = -10.0f;
    private int contentDirection = 1;

    private String query = "";
    private boolean searchFocus;

    private final Map<Object, Spring> hovers = new HashMap<>();
    private final Map<GuiModel.Module, Card> cards = new IdentityHashMap<>();
    private final Map<Object, Spring> toggles = new IdentityHashMap<>();
    private List<Hot> hots = new ArrayList<>();
    private List<Hot> lastHots = new ArrayList<>();
    private final float[] clip = new float[4 * 8];
    private int clipDepth;
    private Object hoverKey;
    private float mx = -1000.0f;
    private float my = -1000.0f;

    private GuiModel.ModeOption menu;
    private GuiModel.ModeOption menuShown;
    private float menuX;
    private float menuY;
    private float menuW;

    private GuiModel.SliderOption drag;
    private float dragX;
    private float dragW;
    private String dragLabel = "";
    private float dragSoundAt;
    private final Spring dragS = new Spring(0.0f, SpringSpec.FAST_EFFECTS, 0.002f);

    private static final class Card {
        final Spring expand = new Spring(0.0f, SpringSpec.EXPRESSIVE_DEFAULT_SPATIAL, 0.001f);
        final Spring toggle = new Spring(0.0f, SpringSpec.EXPRESSIVE_FAST_SPATIAL, 0.001f);
        final Spring appear = new Spring(0.0f, SpringSpec.EXPRESSIVE_DEFAULT_SPATIAL, 0.001f);
        final Spring press = new Spring(0.0f, SpringSpec.FAST_EFFECTS, 0.002f);
        boolean expanded;
        float appearAt = -1.0f;
    }

    /** Активная зона ввода текущего кадра. */
    private interface Action {
        void run(int button, float x, float y);
    }

    private record Hot(float x0, float y0, float x1, float y1, Object key, Action action) {
        boolean contains(float x, float y) {
            return x >= x0 && x < x1 && y >= y0 && y < y1;
        }
    }

    public ClickGuiView(GuiModel model, Host host, int category, boolean folded) {
        this.model = model;
        this.host = host;
        this.category = Math.max(0, Math.min(category, model.categories().size() - 1));
        this.folded = folded;
        fold.snap(folded ? 1.0f : 0.0f);
        navY.snap(this.category);
        appear.target(1.0f);
        stagger(visibleModules(), 0.06f);
    }

    // ─── Состояние ──────────────────────────────────────────────────────────

    public int category() {
        return category;
    }

    public boolean folded() {
        return folded;
    }

    public boolean closing() {
        return closing;
    }

    public boolean searchFocused() {
        return searchFocus;
    }

    /** Прозрачность появления окна 0..1 (для фона экрана). */
    public float appearAlpha() {
        return clamp01(appear.value());
    }

    /** Запуск анимации закрытия; экран закроется через {@link Host#close()}. */
    public void requestClose() {
        if (!closing) {
            closing = true;
            appear.spec(SpringSpec.FAST_EFFECTS).target(0.0f);
            host.sound(Sound.CLOSE);
        }
    }

    private List<GuiModel.Module> visibleModules() {
        List<GuiModel.Module> out = new ArrayList<>();
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            out.addAll(model.categories().get(category).modules());
            return out;
        }
        for (GuiModel.Category c : model.categories()) {
            for (GuiModel.Module m : c.modules()) {
                if (m.name().toLowerCase(Locale.ROOT).contains(q) || m.description().toLowerCase(Locale.ROOT).contains(q)
                    || c.title().toLowerCase(Locale.ROOT).startsWith(q)) {
                    out.add(m);
                }
            }
        }
        return out;
    }

    private Card card(GuiModel.Module m) {
        Card c = cards.get(m);
        if (c == null) {
            c = new Card();
            c.expanded = m.expanded();
            c.expand.snap(c.expanded ? 1.0f : 0.0f);
            c.toggle.snap(m.toggleable() && m.enabled() ? 1.0f : 0.0f);
            cards.put(m, c);
        }
        return c;
    }

    private void stagger(List<GuiModel.Module> list, float delay) {
        float now = Motion.time();
        for (int i = 0; i < list.size(); i++) {
            Card c = card(list.get(i));
            c.appear.snap(0.0f);
            c.appearAt = now + delay + Math.min(i, 14) * 0.022f;
        }
    }

    private Spring hover(Object key) {
        Spring s = hovers.computeIfAbsent(key, k -> new Spring(0.0f, SpringSpec.DEFAULT_EFFECTS, 0.002f));
        s.target(key.equals(hoverKey) ? 1.0f : 0.0f);
        return s;
    }

    private Spring toggleSpring(Object key, boolean on) {
        Spring s = toggles.computeIfAbsent(key, k -> new Spring(on ? 1.0f : 0.0f, SpringSpec.EXPRESSIVE_FAST_SPATIAL, 0.001f));
        s.target(on ? 1.0f : 0.0f);
        return s;
    }

    private void hot(float x0, float y0, float x1, float y1, Object key, Action action) {
        if (clipDepth > 0) {
            int i = (clipDepth - 1) * 4;
            x0 = Math.max(x0, clip[i]);
            y0 = Math.max(y0, clip[i + 1]);
            x1 = Math.min(x1, clip[i + 2]);
            y1 = Math.min(y1, clip[i + 3]);
        }
        if (x1 > x0 && y1 > y0) {
            hots.add(new Hot(x0, y0, x1, y1, key, action));
        }
    }

    private void pushHotClip(float x0, float y0, float x1, float y1) {
        if (clipDepth > 0) {
            int i = (clipDepth - 1) * 4;
            x0 = Math.max(x0, clip[i]);
            y0 = Math.max(y0, clip[i + 1]);
            x1 = Math.min(x1, clip[i + 2]);
            y1 = Math.min(y1, clip[i + 3]);
        }
        int j = clipDepth * 4;
        clip[j] = x0;
        clip[j + 1] = y0;
        clip[j + 2] = x1;
        clip[j + 3] = y1;
        clipDepth++;
    }

    private void popHotClip() {
        clipDepth--;
    }

    private static int c(Role role) {
        return UiTheme.c(role);
    }

    private static int c(Role role, float alpha) {
        return UiTheme.c(role, alpha);
    }

    private static float clamp01(float v) {
        return v < 0.0f ? 0.0f : Math.min(1.0f, v);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    // ─── Отрисовка ──────────────────────────────────────────────────────────

    /** Кадр интерфейса. {@code Motion.beginFrame()} вызывает владелец экрана. */
    public void render(Ui ui, float mouseX, float mouseY) {
        mx = mouseX;
        my = mouseY;
        hoverKey = null;
        if (drag == null) {
            for (int i = lastHots.size() - 1; i >= 0; i--) {
                Hot h = lastHots.get(i);
                if (h.contains(mx, my)) {
                    hoverKey = h.key();
                    break;
                }
            }
        } else {
            hoverKey = drag;
        }
        hots = new ArrayList<>();
        clipDepth = 0;

        float a = appear.value();
        if (closing && a < 0.04f) {
            host.close();
        }
        float alpha = clamp01(a);
        float sw = ui.width();
        float sh = ui.height();

        // Вуаль поверх размытого мира: светлая в светлой схеме, тёмная — в тёмной.
        if (UiTheme.dark()) {
            ui.gradient(0, 0, sw, sh, c(Role.SCRIM, 0.18f * alpha), c(Role.SCRIM, 0.38f * alpha));
        } else {
            ui.gradient(0, 0, sw, sh, c(Role.SURFACE, 0.14f * alpha), c(Role.SURFACE, 0.30f * alpha));
        }

        float winW = Math.max(360.0f, Math.min(sw - 48.0f, 660.0f));
        float winH = Math.max(230.0f, Math.min(sh - 40.0f, 392.0f));
        float x = Math.round((sw - winW) / 2.0f);
        float y = Math.round((sh - winH) / 2.0f);
        float rise = (1.0f - a) * 14.0f;

        ui.pushAlpha(alpha);
        ui.push(0.0f, rise);
        drawCompanion(ui, x, y, winH, alpha);
        drawWindow(ui, x, y, winW, winH);
        ui.pop();
        ui.popAlpha();
        drawMenu(ui);

        List<Hot> swap = lastHots;
        lastHots = hots;
        swap.clear();
        hots = swap;
    }

    private void drawCompanion(Ui ui, float winX, float winY, float winH, float alpha) {
        float w = 86.0f;
        float h = 124.0f;
        float x = winX - 14.0f - w;
        if (x < 10.0f) {
            return;
        }
        float y = winY + winH - h;
        ui.elevation(x, y, w, h, 16, Elevation.LEVEL2);
        ui.round(x, y, w, h, 16, c(Role.SURFACE_CONTAINER, 0.94f));
        ui.round(x + 5, y + 5, w - 10, h - 26, 12, c(Role.SURFACE_CONTAINER_HIGH, 0.9f));
        host.companion(ui, x + 5, y + 5, w - 10, h - 26, alpha);
        String name = ui.ellipsize(TypeStyle.LABEL_MEDIUM, host.playerName(), w - 14);
        ui.textCentered(TypeStyle.LABEL_MEDIUM, name, x + w / 2.0f, y + h - 18.5f, c(Role.ON_SURFACE));
    }

    private void drawWindow(Ui ui, float x, float y, float winW, float winH) {
        float f = fold.value();
        float curW = RAIL_W + (winW - RAIL_W) * Math.max(0.0f, 1.0f - f);
        float dockH = Math.min(winH, NAV_TOP + model.categories().size() * NAV_STEP + 66.0f);
        float curH = winH - (winH - dockH) * clamp01(f);
        boolean dark = UiTheme.dark();
        ui.elevation(x, y, curW, curH, RADIUS, Elevation.LEVEL3);
        ui.round(x, y, curW, curH, RADIUS, c(Role.SURFACE_CONTAINER, dark ? 0.95f : 0.965f));
        ui.outline(x, y, curW, curH, RADIUS, 0.5f, c(Role.OUTLINE_VARIANT, dark ? 0.55f : 0.7f));
        hot(x, y, x + curW, y + curH, "window", (b, mx2, my2) -> { });

        drawRail(ui, x, y, curH);
        float visible = clamp01(1.0f - f);
        if (visible > 0.01f) {
            ui.clip(x + RAIL_W - 2, y, curW - RAIL_W + 2, curH);
            pushHotClip(x + RAIL_W - 2, y, x + curW, y + curH);
            ui.pushAlpha(clamp01(1.0f - f * 1.5f));
            drawContent(ui, x + RAIL_W, y, winW - RAIL_W, winH);
            ui.popAlpha();
            popHotClip();
            ui.unclip();
        }
    }

    // ─── Рейл ───────────────────────────────────────────────────────────────

    private void drawRail(Ui ui, float x, float y, float h) {
        float cx = x + RAIL_W / 2.0f;
        ui.icon(Icon.SAKURA, cx - 9.0f, y + 13.0f, 18.0f, c(Role.BRAND));
        List<GuiModel.Category> cats = model.categories();
        boolean searching = !query.isBlank();

        // Индикатор активного пункта: скользит пружиной и «распускается» по ширине.
        float iy = y + NAV_TOP + navY.value() * NAV_STEP;
        float grow = clamp01(navGrow.value());
        float iw = 32.0f * (0.45f + 0.55f * grow);
        ui.pill(cx - iw / 2.0f, iy, iw, 18.0f, c(Role.SECONDARY_CONTAINER, searching ? 0.45f : 1.0f));

        for (int i = 0; i < cats.size(); i++) {
            GuiModel.Category cat = cats.get(i);
            float ty = y + NAV_TOP + i * NAV_STEP;
            String key = "nav:" + i;
            float hv = hover(key).value01();
            boolean active = i == category && !searching;
            if (hv > 0.0f) {
                ui.pill(cx - 16.0f, ty, 32.0f, 18.0f, c(active ? Role.ON_SECONDARY_CONTAINER : Role.ON_SURFACE, 0.08f * hv));
            }
            int iconColor = active ? c(Role.ON_SECONDARY_CONTAINER) : c(Role.ON_SURFACE_VARIANT);
            ui.icon(cat.icon(), cx - 6.0f, ty + 3.0f, 12.0f, iconColor, active ? 1.12f : 1.0f);
            ui.textCentered(TypeStyle.LABEL_SMALL, cat.title(), cx, ty + 19.5f, active ? c(Role.ON_SURFACE) : c(Role.ON_SURFACE_VARIANT));
            final int index = i;
            hot(x + 4, ty - 3, x + RAIL_W - 4, ty + 30, key, (b, px, py) -> selectCategory(index));
        }

        // Нижние действия: тема и складывание.
        float by = y + h - 32.0f;
        iconButton(ui, model.dark() ? Icon.SUN : Icon.MOON, cx, by - 26.0f, "rail:theme", () -> {
            model.setDark(!model.dark());
            host.sound(Sound.CLICK);
        });
        iconButton(ui, folded ? Icon.DOCK_OPEN : Icon.DOCK_CLOSE, cx, by, "rail:fold", this::toggleFold);
    }

    private void iconButton(Ui ui, Icon icon, float cx, float y, String key, Runnable action) {
        float hv = hover(key).value01();
        if (hv > 0.0f) {
            ui.circle(cx, y + 11.0f, 11.0f, c(Role.ON_SURFACE, 0.08f * hv));
        }
        ui.icon(icon, cx - 6.0f, y + 5.0f, 12.0f, c(Role.ON_SURFACE_VARIANT));
        hot(cx - 11.0f, y, cx + 11.0f, y + 22.0f, key, (b, px, py) -> action.run());
    }

    // ─── Контент ────────────────────────────────────────────────────────────

    private void drawContent(Ui ui, float x, float y, float w, float h) {
        float right = x + w - 14.0f;
        float left = x + 6.0f;
        boolean searching = !query.isBlank();
        List<GuiModel.Module> list = visibleModules();

        // Заголовок.
        float fadeIn = clamp01(contentIn.value());
        float slide = (1.0f - contentIn.value()) * 10.0f * contentDirection;
        String title = searching ? "Search" : model.categories().get(category).title();
        int on = 0;
        for (GuiModel.Module m : list) {
            if (m.toggleable() && m.enabled()) {
                on++;
            }
        }
        String subtitle = searching
            ? list.size() + (list.size() == 1 ? " result" : " results")
            : list.size() + " modules  ·  " + on + " on";
        ui.pushAlpha(fadeIn);
        ui.text(TypeStyle.HEADLINE_SMALL, title, left + 2, y + 12.0f + slide * 0.4f, c(Role.ON_SURFACE));
        ui.text(TypeStyle.BODY_SMALL, subtitle, left + 2, y + 28.5f + slide * 0.4f, c(Role.ON_SURFACE_VARIANT));
        ui.popAlpha();

        // Кнопка закрытия и поиск.
        float closeCx = right - 10.0f;
        iconButton(ui, Icon.CLOSE, closeCx, y + 12.0f, "close", this::requestClose);
        float searchW = Math.min(176.0f, w * 0.40f);
        drawSearch(ui, closeCx - 16.0f - searchW, y + 13.0f, searchW, 20.0f);

        // Сетка карточек.
        float gx0 = left;
        float gx1 = right;
        float gy0 = y + 46.0f;
        float gy1 = y + h - 8.0f;
        float gw = gx1 - gx0;
        int cols = Math.max(1, (int) ((gw + GAP) / (MIN_CARD_W + GAP)));
        float cw = (gw - GAP * (cols - 1)) / cols;
        float[] colY = new float[cols];
        float[] cardY = new float[list.size()];
        float[] cardH = new float[list.size()];
        for (int i = 0; i < list.size(); i++) {
            GuiModel.Module m = list.get(i);
            Card cd = card(m);
            int col = i % cols;
            cardH[i] = cardHeight(ui, m, cd, cw);
            cardY[i] = colY[col];
            colY[col] += cardH[i] + GAP;
        }
        float contentH = 0.0f;
        for (float v : colY) {
            contentH = Math.max(contentH, v - GAP);
        }
        float viewH = gy1 - gy0;
        float maxScroll = Math.max(0.0f, contentH - viewH + 10.0f);
        scrollTarget = Math.max(0.0f, Math.min(scrollTarget, maxScroll));
        scroll.target(scrollTarget);
        float sc = scroll.value();

        ui.clip(gx0 - 8.0f, gy0, gw + 16.0f, viewH);
        pushHotClip(gx0 - 8.0f, gy0, gx1 + 8.0f, gy1);
        ui.pushAlpha(fadeIn);
        for (int i = 0; i < list.size(); i++) {
            float cy = gy0 + 2.0f + cardY[i] - sc + slide;
            if (cy + cardH[i] < gy0 - 24.0f || cy > gy1 + 24.0f) {
                continue;
            }
            float cx = gx0 + (i % cols) * (cw + GAP);
            drawCard(ui, list.get(i), card(list.get(i)), cx, cy, cw, cardH[i]);
        }
        ui.popAlpha();
        if (list.isEmpty()) {
            drawEmpty(ui, (gx0 + gx1) / 2.0f, gy0 + viewH * 0.32f);
        }
        // Мягкие края области прокрутки — только над карточками, которые режет край.
        int edge = c(Role.SURFACE_CONTAINER, UiTheme.dark() ? 0.95f : 0.965f);
        for (int i = 0; i < list.size(); i++) {
            float cy = gy0 + 2.0f + cardY[i] - sc + slide;
            float cx = gx0 + (i % cols) * (cw + GAP);
            if (cy + cardH[i] > gy1 - 12.0f && cy < gy1) {
                ui.gradient(cx - 1.0f, gy1 - 12.0f, cw + 2.0f, 12.0f, Argb.withAlpha(edge, 0.0f), edge);
            }
            if (sc > 0.5f && cy < gy0 + 8.0f && cy + cardH[i] > gy0) {
                ui.gradient(cx - 1.0f, gy0, cw + 2.0f, 8.0f, edge, Argb.withAlpha(edge, 0.0f));
            }
        }
        popHotClip();
        ui.unclip();
        hot(gx0 - 8.0f, gy0, gx1 + 8.0f, gy1, "grid", (b, px, py) -> { });

        // Полоса прокрутки — появляется при прокрутке и наведении.
        if (maxScroll > 0.5f) {
            boolean recent = Motion.time() - lastScrollAt < 0.9f;
            boolean over = mx >= gx0 && mx <= gx1 + 12 && my >= gy0 && my <= gy1;
            scrollbar.target(recent || over ? 1.0f : 0.0f);
            float sa = scrollbar.value01();
            if (sa > 0.01f) {
                float trackH = viewH - 8.0f;
                float thumbH = Math.max(18.0f, trackH * viewH / (contentH + 10.0f));
                float thumbY = gy0 + 4.0f + (trackH - thumbH) * (sc / maxScroll);
                ui.pill(gx1 + 5.0f, thumbY, 3.0f, thumbH, c(Role.ON_SURFACE_VARIANT, 0.45f * sa));
            }
        }
    }

    private void drawEmpty(Ui ui, float cx, float cy) {
        ui.circle(cx, cy, 18.0f, c(Role.SURFACE_CONTAINER_HIGHEST));
        ui.icon(Icon.SEARCH, cx - 9.0f, cy - 9.0f, 18.0f, c(Role.ON_SURFACE_VARIANT));
        ui.textCentered(TypeStyle.TITLE_SMALL, "Nothing found", cx, cy + 24.0f, c(Role.ON_SURFACE));
        ui.textCentered(TypeStyle.BODY_SMALL, "No module matches “" + query.trim() + "”", cx, cy + 35.0f, c(Role.ON_SURFACE_VARIANT));
    }

    private void drawSearch(Ui ui, float x, float y, float w, float h) {
        float focus = searchFocusS.target(searchFocus ? 1.0f : 0.0f).value01();
        float hv = hover("search").value01();
        int bg = Argb.layer(c(Role.SURFACE_CONTAINER_HIGHEST), c(Role.ON_SURFACE), 0.05f * hv);
        ui.pill(x, y, w, h, bg);
        if (focus > 0.0f) {
            ui.outline(x, y, w, h, h / 2.0f, 1.0f, c(Role.PRIMARY, focus));
        }
        ui.icon(Icon.SEARCH, x + 6.0f, y + 4.5f, 11.0f, focus > 0.5f ? c(Role.PRIMARY) : c(Role.ON_SURFACE_VARIANT));
        float tx = x + 21.0f;
        float maxText = w - 21.0f - (query.isEmpty() ? 8.0f : 20.0f);
        ui.clip(tx, y, maxText + 2.0f, h);
        if (query.isEmpty()) {
            ui.text(TypeStyle.BODY_MEDIUM, searchFocus ? "Type to search" : "Search modules", tx, y + 5.25f, c(Role.ON_SURFACE_VARIANT, 0.9f));
        } else {
            float tw = ui.textWidth(TypeStyle.BODY_MEDIUM, query);
            float shift = Math.max(0.0f, tw - maxText + 2.0f);
            ui.text(TypeStyle.BODY_MEDIUM, query, tx - shift, y + 5.25f, c(Role.ON_SURFACE));
            if (searchFocus && (Motion.time() * 1.6f) % 1.0f < 0.6f) {
                ui.rect(tx - shift + tw + 0.75f, y + 5.0f, 0.75f, 10.0f, c(Role.PRIMARY));
            }
        }
        if (query.isEmpty() && searchFocus && (Motion.time() * 1.6f) % 1.0f < 0.6f) {
            ui.rect(tx - 0.5f, y + 5.0f, 0.75f, 10.0f, c(Role.PRIMARY));
        }
        ui.unclip();
        if (!query.isEmpty()) {
            float cx = x + w - 10.0f;
            float chv = hover("search:clear").value01();
            ui.circle(cx, y + h / 2.0f, 7.0f, c(Role.ON_SURFACE, 0.08f * chv));
            ui.icon(Icon.CLOSE, cx - 4.5f, y + h / 2.0f - 4.5f, 9.0f, c(Role.ON_SURFACE_VARIANT));
            hot(cx - 8.0f, y, cx + 8.0f, y + h, "search:clear", (b, px, py) -> {
                setQuery("");
                host.sound(Sound.CLICK);
            });
        }
        hot(x, y, x + w, y + h, "search", (b, px, py) -> {
            searchFocus = true;
            if (folded) {
                toggleFold();
            }
        });
    }

    // ─── Карточка модуля ────────────────────────────────────────────────────

    private float cardHeight(Ui ui, GuiModel.Module m, Card cd, float w) {
        float e = cd.expand.value();
        if (e <= 0.001f) {
            return HEAD_H;
        }
        return HEAD_H + Math.max(0.0f, optionsHeight(ui, m, w) * e);
    }

    private float optionsHeight(Ui ui, GuiModel.Module m, float w) {
        float total = 6.0f;
        for (GuiModel.Option o : m.options()) {
            if (o.visible()) {
                total += rowHeight(ui, o, w);
            }
        }
        return total + 6.0f;
    }

    private float rowHeight(Ui ui, GuiModel.Option o, float w) {
        if (o instanceof GuiModel.BoolOption) {
            return o.description().isEmpty() ? 18.0f : 24.0f;
        }
        if (o instanceof GuiModel.SliderOption) {
            return 27.0f;
        }
        if (o instanceof GuiModel.ModeOption mode) {
            return segmented(ui, mode, w - 20.0f) ? 31.0f : 19.0f;
        }
        if (o instanceof GuiModel.ColorOption) {
            return 29.0f;
        }
        return 18.0f;
    }

    private boolean segmented(Ui ui, GuiModel.ModeOption mode, float width) {
        List<String> modes = mode.modes();
        if (modes.size() < 2 || modes.size() > 3) {
            return false;
        }
        float seg = width / modes.size();
        for (String s : modes) {
            if (ui.textWidth(TypeStyle.LABEL_MEDIUM, s) + 16.0f > seg) {
                return false;
            }
        }
        return true;
    }

    private void drawCard(Ui ui, GuiModel.Module m, Card cd, float x, float y, float w, float h) {
        if (cd.appearAt >= 0.0f && Motion.time() >= cd.appearAt) {
            cd.appear.target(1.0f);
            cd.appearAt = -1.0f;
        } else if (cd.appearAt < 0.0f && cd.appear.target() < 1.0f) {
            cd.appear.target(1.0f);
        }
        float ap = cd.appear.value();
        if (ap <= 0.001f) {
            return;
        }
        boolean dark = UiTheme.dark();
        cd.toggle.target(m.toggleable() && m.enabled() ? 1.0f : 0.0f);
        float on = cd.toggle.value01();
        float hv = hover(m).value01();
        float press = cd.press.target(0.0f).value01();

        ui.pushAlpha(clamp01(ap));
        ui.push(0.0f, (1.0f - ap) * 10.0f - hv * 0.75f);
        if (hv > 0.0f) {
            ui.elevation(x, y, w, h, CARD_R, Elevation.LEVEL2, hv * 0.85f);
        }
        int base = c(dark ? Role.SURFACE_CONTAINER_HIGH : Role.SURFACE_CONTAINER_LOWEST);
        int bg = Argb.mixOklab(base, c(Role.PRIMARY_CONTAINER), on * (dark ? 0.30f : 0.42f));
        bg = Argb.layer(bg, c(Role.ON_SURFACE), 0.035f * hv + 0.07f * press);
        ui.round(x, y, w, h, CARD_R + press * 2.0f, bg);

        // Ведущая иконка в тональном круге.
        float icx = x + 18.5f;
        float icy = y + HEAD_H / 2.0f;
        int icBg = Argb.mixOklab(c(dark ? Role.SURFACE_CONTAINER_HIGHEST : Role.SURFACE_CONTAINER_HIGH), c(Role.PRIMARY), on);
        int icFg = Argb.mixOklab(c(Role.ON_SURFACE_VARIANT), c(Role.ON_PRIMARY), on);
        ui.circle(icx, icy, 10.5f, icBg);
        ui.icon(m.icon(), icx - 6.0f, icy - 6.0f, 12.0f, icFg);

        // Хвост: переключатель / кнопка действия, шеврон настроек.
        float right = x + w - 9.0f;
        float trailing = right;
        String action = m.actionLabel();
        if (action != null) {
            float bw = ui.textWidth(TypeStyle.LABEL_MEDIUM, action) + 16.0f;
            float bx = right - bw;
            float bhv = hover("act:" + m.name()).value01();
            ui.pill(bx, icy - 8.0f, bw, 16.0f, Argb.layer(c(Role.SECONDARY_CONTAINER), c(Role.ON_SECONDARY_CONTAINER), 0.08f * bhv));
            ui.textCentered(TypeStyle.LABEL_MEDIUM, action, bx + bw / 2.0f, icy - 4.25f, c(Role.ON_SECONDARY_CONTAINER));
            hot(bx, icy - 8.0f, right, icy + 8.0f, "act:" + m.name(), (b, px, py) -> {
                host.sound(Sound.CLICK);
                m.action();
            });
            trailing = bx;
        } else if (m.toggleable()) {
            float tw = 26.0f;
            drawSwitch(ui, right - tw, icy - 7.0f, tw, 14.0f, cd.toggle.value(), press, hv);
            trailing = right - tw;
        }
        boolean hasOptions = !m.options().isEmpty();
        if (hasOptions) {
            float chx = trailing - 11.0f;
            String key = "chev:" + m.name();
            float chv = hover(key).value01();
            float ex = cd.expand.value01();
            if (chv > 0.0f) {
                ui.circle(chx, icy, 8.5f, c(Role.ON_SURFACE, 0.08f * chv));
            }
            ui.icon(ex > 0.5f ? Icon.CHEVRON_UP : Icon.CHEVRON_DOWN, chx - 5.0f, icy - 5.0f, 10.0f,
                ex > 0.5f ? c(Role.PRIMARY) : c(Role.ON_SURFACE_VARIANT));
            hot(chx - 9.0f, icy - 9.0f, chx + 9.0f, icy + 9.0f, key, (b, px, py) -> toggleExpand(m, cd));
            trailing = chx - 9.0f;
        }

        // Название и описание.
        float tx = x + 34.0f;
        float avail = trailing - tx - 4.0f;
        ui.text(TypeStyle.TITLE_SMALL, ui.ellipsize(TypeStyle.TITLE_SMALL, m.name(), avail), tx, y + 7.5f, c(Role.ON_SURFACE));
        ui.text(TypeStyle.BODY_SMALL, ui.ellipsize(TypeStyle.BODY_SMALL, m.description(), avail), tx, y + 18.0f, c(Role.ON_SURFACE_VARIANT));

        hot(x, y, x + w, y + HEAD_H, m, (b, px, py) -> {
            if (b == 1) {
                if (hasOptions) {
                    toggleExpand(m, cd);
                }
            } else if (m.toggleable()) {
                m.toggle();
                cd.press.snap(1.0f);
                host.sound(m.enabled() ? Sound.TOGGLE_ON : Sound.TOGGLE_OFF);
            } else if (action != null) {
                host.sound(Sound.CLICK);
                m.action();
            } else if (hasOptions) {
                toggleExpand(m, cd);
            }
        });
        hot(x, y + HEAD_H, x + w, y + h, "body:" + m.name(), (b, px, py) -> { });

        // Настройки (раскрытие на месте).
        if (h > HEAD_H + 0.5f) {
            float ex = cd.expand.value01();
            ui.clip(x, y + HEAD_H, w, h - HEAD_H);
            pushHotClip(x, y + HEAD_H, x + w, y + h);
            ui.rect(x + 12.0f, y + HEAD_H, w - 24.0f, 0.5f, c(Role.OUTLINE_VARIANT, 0.8f * ex));
            float ry = y + HEAD_H + 6.0f;
            int index = 0;
            for (GuiModel.Option o : m.options()) {
                if (!o.visible()) {
                    continue;
                }
                float rh = rowHeight(ui, o, w);
                float local = clamp01((ex - 0.15f - index * 0.04f) / 0.55f);
                ui.pushAlpha(local);
                drawOption(ui, o, x + 10.0f, ry, w - 20.0f, rh);
                ui.popAlpha();
                ry += rh;
                index++;
            }
            popHotClip();
            ui.unclip();
        }
        ui.pop();
        ui.popAlpha();
    }

    /** Переключатель M3: дорожка, «растущий» бегунок с галочкой, ореол при наведении. */
    private void drawSwitch(Ui ui, float x, float y, float w, float h, float onRaw, float press, float hv) {
        float on = clamp01(onRaw);
        ui.pill(x, y, w, h, Argb.mixOklab(c(Role.SURFACE_CONTAINER_HIGHEST), c(Role.PRIMARY), on));
        if (on < 0.999f) {
            ui.outline(x, y, w, h, h / 2.0f, Math.max(0.5f, h * 0.075f), c(Role.OUTLINE, 1.0f - on));
        }
        float dOff = h * 0.5f;
        float dOn = h * 0.72f;
        float d = lerp(dOff, dOn, on) + press * h * 0.12f;
        float cxOff = x + h / 2.0f;
        float cxOn = x + w - h / 2.0f;
        float tcx = lerp(cxOff, cxOn, onRaw);
        float tcy = y + h / 2.0f;
        if (hv > 0.0f) {
            ui.circle(tcx, tcy, h * 0.8f, c(on > 0.5f ? Role.PRIMARY : Role.ON_SURFACE, 0.10f * hv));
        }
        ui.circle(tcx, tcy, d / 2.0f, Argb.mixOklab(c(Role.OUTLINE), c(Role.ON_PRIMARY), on));
        if (on > 0.5f) {
            float is = d * 0.78f;
            ui.icon(Icon.CHECK, tcx - is / 2.0f, tcy - is / 2.0f, is, c(Role.ON_PRIMARY_CONTAINER, (on - 0.5f) * 2.0f), 1.1f);
        }
    }

    private void drawOption(Ui ui, GuiModel.Option o, float x, float y, float w, float h) {
        if (o instanceof GuiModel.BoolOption b) {
            Spring t = toggleSpring(b, b.value());
            float hv = hover(b).value01();
            if (hv > 0.0f) {
                ui.round(x - 4.0f, y + 1.0f, w + 8.0f, h - 2.0f, 7.0f, c(Role.ON_SURFACE, 0.05f * hv));
            }
            boolean desc = !b.description().isEmpty();
            float ty = desc ? y + 2.5f : y + 4.25f;
            ui.text(TypeStyle.BODY_MEDIUM, ui.ellipsize(TypeStyle.BODY_MEDIUM, b.name(), w - 30.0f), x, ty, c(Role.ON_SURFACE));
            if (desc) {
                ui.text(TypeStyle.BODY_SMALL, ui.ellipsize(TypeStyle.BODY_SMALL, b.description(), w - 30.0f), x, y + 12.0f, c(Role.ON_SURFACE_VARIANT));
            }
            drawSwitch(ui, x + w - 21.0f, y + (h - 12.0f) / 2.0f, 21.0f, 12.0f, t.value(), 0.0f, hv);
            hot(x - 4.0f, y, x + w + 4.0f, y + h, b, (btn, px, py) -> {
                b.set(!b.value());
                host.sound(b.value() ? Sound.TOGGLE_ON : Sound.TOGGLE_OFF);
            });
        } else if (o instanceof GuiModel.SliderOption s) {
            drawSlider(ui, s, x, y, w);
        } else if (o instanceof GuiModel.ModeOption mode) {
            if (segmented(ui, mode, w)) {
                drawSegmented(ui, mode, x, y, w);
            } else {
                drawModeChip(ui, mode, x, y, w, h);
            }
        } else if (o instanceof GuiModel.ColorOption col) {
            drawSwatches(ui, col, x, y, w);
        }
    }

    /** Слайдер M3 Expressive: толстая дорожка, вертикальная ручка с зазором, точка конца. */
    private void drawSlider(Ui ui, GuiModel.SliderOption s, float x, float y, float w) {
        boolean dragging = drag == s;
        float hv = hover(s).value01();
        ui.text(TypeStyle.BODY_MEDIUM, ui.ellipsize(TypeStyle.BODY_MEDIUM, s.name(), w - 40.0f), x, y + 1.0f, c(Role.ON_SURFACE));
        ui.textRight(TypeStyle.LABEL_MEDIUM, s.label(), x + w, y + 1.75f, c(Role.PRIMARY));
        float range = s.max() - s.min();
        float t = range <= 0.0f ? 0.0f : clamp01((s.value() - s.min()) / range);
        Spring pos = toggles.computeIfAbsent(s, k -> new Spring(t, SpringSpec.STANDARD_FAST_SPATIAL, 0.0005f));
        pos.target(t);
        float vt = dragging ? t : clamp01(pos.value());
        if (dragging) {
            pos.snap(t);
        }
        float ty = y + 15.0f;
        float th = 6.0f;
        float hx = x + 1.0f + (w - 2.0f) * vt;
        float gap = 2.0f;
        if (hx - gap - x > 1.0f) {
            ui.round(x, ty, hx - gap - x, th, th / 2.0f, 1.0f, 1.0f, th / 2.0f, c(Role.PRIMARY));
        }
        if (x + w - hx - gap > 1.0f) {
            ui.round(hx + gap, ty, x + w - hx - gap, th, 1.0f, th / 2.0f, th / 2.0f, 1.0f, c(Role.SECONDARY_CONTAINER));
            ui.circle(x + w - th / 2.0f, ty + th / 2.0f, 1.0f, c(Role.ON_SECONDARY_CONTAINER, 0.9f));
        }
        float handleW = 2.0f - 0.6f * (dragging ? 1.0f : 0.0f) + hv * 0.4f;
        ui.pill(hx - handleW / 2.0f, ty - 4.0f, handleW, th + 8.0f, c(Role.PRIMARY));
        float bubble = dragS.target(dragging ? 1.0f : 0.0f).value01();
        if (bubble > 0.01f) {
            String label = s.label();
            float bw = Math.max(22.0f, ui.textWidth(TypeStyle.LABEL_MEDIUM, label) + 12.0f);
            ui.pushAlpha(bubble);
            ui.push(0.0f, (1.0f - bubble) * 4.0f);
            ui.pill(hx - bw / 2.0f, ty - 19.0f, bw, 13.0f, c(Role.INVERSE_SURFACE));
            ui.textCentered(TypeStyle.LABEL_MEDIUM, label, hx, ty - 16.75f, c(Role.INVERSE_ON_SURFACE));
            ui.pop();
            ui.popAlpha();
        }
        hot(x - 3.0f, ty - 6.0f, x + w + 3.0f, ty + th + 6.0f, s, (btn, px, py) -> {
            drag = s;
            dragX = x;
            dragW = w;
            dragLabel = s.label();
            updateDrag(px);
        });
    }

    private void drawSegmented(Ui ui, GuiModel.ModeOption mode, float x, float y, float w) {
        ui.text(TypeStyle.BODY_MEDIUM, mode.name(), x, y + 1.0f, c(Role.ON_SURFACE));
        List<String> modes = mode.modes();
        float sy = y + 13.0f;
        float sh = 15.0f;
        float seg = w / modes.size();
        for (int i = 0; i < modes.size(); i++) {
            String value = modes.get(i);
            boolean selected = value.equals(mode.value());
            float sx = x + seg * i;
            float tl = i == 0 ? sh / 2.0f : 1.5f;
            float br = i == modes.size() - 1 ? sh / 2.0f : 1.5f;
            String key = "seg:" + System.identityHashCode(mode) + ":" + i;
            float hv = hover(key).value01();
            Spring sel = toggleSpring(key, selected);
            float sv = sel.value01();
            int fill = Argb.mixOklab(c(Role.SURFACE_CONTAINER_HIGHEST), c(Role.SECONDARY_CONTAINER), sv);
            fill = Argb.layer(fill, c(Role.ON_SURFACE), 0.06f * hv);
            ui.round(sx + (i == 0 ? 0.0f : 0.5f), sy, seg - (i == 0 || i == modes.size() - 1 ? 0.5f : 1.0f), sh, tl, br, br, tl, fill);
            float lw = ui.textWidth(TypeStyle.LABEL_MEDIUM, value);
            float iconW = 8.0f * sv;
            float start = sx + seg / 2.0f - (lw + iconW) / 2.0f;
            if (sv > 0.05f) {
                ui.icon(Icon.CHECK, start - 1.0f, sy + 3.5f, 8.0f, c(Role.ON_SECONDARY_CONTAINER, sv), 1.15f);
            }
            ui.text(TypeStyle.LABEL_MEDIUM, value, start + iconW, sy + 3.25f, selected ? c(Role.ON_SECONDARY_CONTAINER) : c(Role.ON_SURFACE));
            hot(sx, sy, sx + seg, sy + sh, key, (b, px, py) -> {
                if (!mode.value().equals(value)) {
                    mode.set(value);
                    host.sound(Sound.CLICK);
                }
            });
        }
    }

    private void drawModeChip(Ui ui, GuiModel.ModeOption mode, float x, float y, float w, float h) {
        float cw = Math.min(w * 0.6f, ui.textWidth(TypeStyle.LABEL_MEDIUM, mode.value()) + 24.0f);
        ui.text(TypeStyle.BODY_MEDIUM, ui.ellipsize(TypeStyle.BODY_MEDIUM, mode.name(), w - cw - 6.0f), x, y + 4.75f, c(Role.ON_SURFACE));
        float cx = x + w - cw;
        float cy = y + 2.0f;
        float hv = hover(mode).value01();
        boolean open = menu == mode;
        ui.pill(cx, cy, cw, 15.0f, Argb.layer(c(open ? Role.SECONDARY_CONTAINER : Role.SURFACE_CONTAINER_HIGHEST), c(Role.ON_SURFACE), 0.06f * hv));
        ui.text(TypeStyle.LABEL_MEDIUM, ui.ellipsize(TypeStyle.LABEL_MEDIUM, mode.value(), cw - 22.0f), cx + 8.0f, cy + 3.25f, c(Role.ON_SURFACE));
        ui.icon(open ? Icon.CHEVRON_UP : Icon.CHEVRON_DOWN, cx + cw - 13.0f, cy + 3.0f, 9.0f, c(Role.ON_SURFACE_VARIANT));
        hot(cx, cy, cx + cw, cy + 15.0f, mode, (b, px, py) -> {
            if (menu == mode) {
                closeMenu();
            } else {
                menu = mode;
                menuShown = mode;
                menuW = Math.max(cw, 80.0f);
                menuX = cx + cw - menuW;
                menuY = cy + 17.0f;
                menuS.snap(0.0f).target(1.0f);
                host.sound(Sound.EXPAND);
            }
        });
    }

    private void drawSwatches(Ui ui, GuiModel.ColorOption col, float x, float y, float w) {
        ui.text(TypeStyle.BODY_MEDIUM, col.name(), x, y + 1.0f, c(Role.ON_SURFACE));
        int[] swatches = col.swatches();
        int current = col.value();
        boolean known = false;
        for (int s : swatches) {
            known |= (s & 0xFFFFFF) == (current & 0xFFFFFF);
        }
        float d = 11.0f;
        float step = d + 4.5f;
        float sx = x + d / 2.0f;
        float sy = y + 13.0f + d / 2.0f + 1.0f;
        int count = swatches.length + (known ? 0 : 1);
        for (int i = 0; i < count; i++) {
            int value = i < swatches.length ? swatches[i] : current;
            float cx = sx + i * step;
            if (cx + d / 2.0f > x + w) {
                break;
            }
            boolean selected = (value & 0xFFFFFF) == (current & 0xFFFFFF);
            String key = "sw:" + System.identityHashCode(col) + ":" + i;
            float hv = hover(key).value01();
            float sel = toggleSpring(key, selected).value01();
            if (sel > 0.01f) {
                ui.ring(cx, sy, d / 2.0f + 2.25f, 1.0f, c(Role.ON_SURFACE, sel));
            }
            ui.circle(cx, sy, d / 2.0f - sel * 0.75f + hv * 0.5f, 0xFF000000 | value);
            if (Argb.luminance(value) > 0.7f) {
                ui.ring(cx, sy, d / 2.0f - sel * 0.75f + hv * 0.5f, 0.5f, c(Role.OUTLINE_VARIANT));
            }
            if (sel > 0.5f) {
                int mark = Argb.luminance(value) > 0.5f ? 0xFF201A1B : 0xFFFFFFFF;
                ui.icon(Icon.CHECK, cx - 3.5f, sy - 3.5f, 7.0f, Argb.withAlpha(mark, (sel - 0.5f) * 2.0f), 1.2f);
            }
            hot(cx - step / 2.0f, sy - d / 2.0f - 2.0f, cx + step / 2.0f, sy + d / 2.0f + 2.0f, key, (b, px, py) -> {
                if ((col.value() & 0xFFFFFF) != (value & 0xFFFFFF)) {
                    col.set(0xFF000000 | value);
                    host.sound(Sound.CLICK);
                }
            });
        }
    }

    private void drawMenu(Ui ui) {
        GuiModel.ModeOption shown = menu != null ? menu : menuShown;
        float open = menuS.value();
        if (shown == null || (menu == null && open < 0.02f)) {
            menuShown = null;
            return;
        }
        List<String> modes = shown.modes();
        float itemH = 16.0f;
        float mh = modes.size() * itemH + 8.0f;
        float o = clamp01(open);
        float maxY = ui.height() - 6.0f;
        float y = menuY + mh > maxY ? menuY - mh - 21.0f : menuY;
        ui.pushAlpha(o);
        ui.elevation(menuX, y, menuW, mh, 10.0f, Elevation.LEVEL2);
        ui.clip(menuX - 8.0f, y - 8.0f, menuW + 16.0f, (mh + 8.0f) * Math.max(0.15f, Math.min(1.0f, open)) + 8.0f);
        ui.round(menuX, y, menuW, mh, 10.0f, c(UiTheme.dark() ? Role.SURFACE_CONTAINER_HIGH : Role.SURFACE_CONTAINER_LOW));
        pushHotClip(menuX, y, menuX + menuW, y + mh);
        for (int i = 0; i < modes.size(); i++) {
            String value = modes.get(i);
            float iy = y + 4.0f + i * itemH;
            boolean selected = value.equals(shown.value());
            String key = "menu:" + i;
            float hv = hover(key).value01();
            if (selected) {
                ui.round(menuX + 4.0f, iy, menuW - 8.0f, itemH, 6.0f, c(Role.SECONDARY_CONTAINER));
            } else if (hv > 0.0f) {
                ui.round(menuX + 4.0f, iy, menuW - 8.0f, itemH, 6.0f, c(Role.ON_SURFACE, 0.08f * hv));
            }
            if (selected) {
                ui.icon(Icon.CHECK, menuX + 9.0f, iy + 3.5f, 9.0f, c(Role.ON_SECONDARY_CONTAINER), 1.1f);
            }
            ui.text(TypeStyle.LABEL_LARGE, value, menuX + 21.0f, iy + 3.0f, selected ? c(Role.ON_SECONDARY_CONTAINER) : c(Role.ON_SURFACE));
            if (menu != null) {
                hot(menuX, iy, menuX + menuW, iy + itemH, key, (b, px, py) -> {
                    shown.set(value);
                    host.sound(Sound.CLICK);
                    closeMenu();
                });
            }
        }
        popHotClip();
        ui.unclip();
        ui.popAlpha();
        if (menu != null) {
            hot(menuX, y, menuX + menuW, y + mh, "menu", (b, px, py) -> { });
        }
    }

    // ─── Действия ───────────────────────────────────────────────────────────

    private void selectCategory(int index) {
        if (folded) {
            folded = false;
            fold.target(0.0f);
        }
        if (!query.isBlank()) {
            setQuery("");
        }
        if (index != category) {
            contentDirection = index > category ? 1 : -1;
            category = index;
            navY.target(index);
            navGrow.snap(0.0f).target(1.0f);
            contentIn.snap(0.0f).target(1.0f);
            scrollTarget = 0.0f;
            scroll.snap(0.0f);
            stagger(visibleModules(), 0.02f);
            closeMenu();
            host.sound(Sound.NAV);
            host.stateChanged(category, folded);
        }
    }

    private void toggleFold() {
        folded = !folded;
        fold.target(folded ? 1.0f : 0.0f);
        if (folded) {
            searchFocus = false;
            closeMenu();
        }
        host.sound(folded ? Sound.COLLAPSE : Sound.EXPAND);
        host.stateChanged(category, folded);
    }

    private void toggleExpand(GuiModel.Module m, Card cd) {
        cd.expanded = !cd.expanded;
        cd.expand.target(cd.expanded ? 1.0f : 0.0f);
        m.setExpanded(cd.expanded);
        host.sound(cd.expanded ? Sound.EXPAND : Sound.COLLAPSE);
    }

    private void closeMenu() {
        if (menu != null) {
            menu = null;
            menuS.target(0.0f);
        }
    }

    private void setQuery(String next) {
        if (!next.equals(query)) {
            query = next;
            scrollTarget = 0.0f;
            scroll.snap(0.0f);
            contentIn.snap(0.4f).target(1.0f);
            contentDirection = 1;
            stagger(visibleModules(), 0.0f);
        }
    }

    private void updateDrag(float px) {
        GuiModel.SliderOption s = drag;
        if (s == null) {
            return;
        }
        float t = clamp01((px - dragX) / Math.max(1.0f, dragW));
        float range = s.max() - s.min();
        float step = range > 20.0f ? 1.0f : range > 2.0f ? 0.1f : 0.01f;
        float value = s.min() + Math.round(t * range / step) * step;
        s.set(Math.max(s.min(), Math.min(s.max(), value)));
        String label = s.label();
        if (!label.equals(dragLabel) && Motion.time() - dragSoundAt > 0.045f) {
            dragLabel = label;
            dragSoundAt = Motion.time();
            host.sound(Sound.SLIDER);
        }
    }

    // ─── Ввод (координаты GUI) ──────────────────────────────────────────────

    public boolean mouseClicked(double x, double y, int button) {
        float fx = (float) x;
        float fy = (float) y;
        if (closing) {
            return true;
        }
        if (menu != null) {
            Hot h = top(fx, fy);
            if (h == null || !(h.key() instanceof String k && k.startsWith("menu"))) {
                closeMenu();
                return true;
            }
        }
        Hot h = top(fx, fy);
        if (h == null) {
            searchFocus = false;
            return false;
        }
        if (!"search".equals(h.key())) {
            searchFocus = false;
        }
        h.action().run(button, fx, fy);
        return true;
    }

    public boolean mouseReleased(double x, double y, int button) {
        if (drag != null) {
            drag = null;
            host.sound(Sound.SLIDER);
            return true;
        }
        return false;
    }

    public boolean mouseDragged(double x, double y, int button) {
        if (drag != null) {
            updateDrag((float) x);
            return true;
        }
        return false;
    }

    public boolean mouseScrolled(double x, double y, double amount) {
        if (menu != null) {
            return true;
        }
        scrollTarget -= (float) amount * 26.0f;
        lastScrollAt = Motion.time();
        return true;
    }

    /** Клавиши по кодам GLFW. */
    public boolean keyPressed(int key, boolean ctrl) {
        switch (key) {
            case 256 -> {
                if (menu != null) {
                    closeMenu();
                } else if (searchFocus && !query.isEmpty()) {
                    setQuery("");
                } else if (searchFocus) {
                    searchFocus = false;
                } else {
                    requestClose();
                }
                return true;
            }
            case 259 -> {
                if (searchFocus && !query.isEmpty()) {
                    if (ctrl) {
                        String trimmed = query.stripTrailing();
                        int cut = trimmed.lastIndexOf(' ');
                        setQuery(cut < 0 ? "" : trimmed.substring(0, cut + 1));
                    } else {
                        setQuery(query.substring(0, query.length() - 1));
                    }
                    return true;
                }
                return false;
            }
            case 257, 335 -> {
                if (searchFocus) {
                    List<GuiModel.Module> list = visibleModules();
                    if (!list.isEmpty() && list.get(0).toggleable()) {
                        GuiModel.Module m = list.get(0);
                        m.toggle();
                        host.sound(m.enabled() ? Sound.TOGGLE_ON : Sound.TOGGLE_OFF);
                    }
                    return true;
                }
                return false;
            }
            case 258 -> {
                int n = model.categories().size();
                selectCategory((category + 1) % n);
                return true;
            }
            case 70 -> {
                if (ctrl) {
                    searchFocus = true;
                    if (folded) {
                        toggleFold();
                    }
                    return true;
                }
                return false;
            }
            default -> {
                return false;
            }
        }
    }

    public boolean charTyped(char ch) {
        if (ch < 32 || ch == 127 || closing) {
            return false;
        }
        if (!searchFocus) {
            searchFocus = true;
            if (folded) {
                toggleFold();
            }
        }
        if (query.length() < 40) {
            setQuery(query + ch);
        }
        return true;
    }

    private Hot top(float x, float y) {
        for (int i = lastHots.size() - 1; i >= 0; i--) {
            Hot h = lastHots.get(i);
            if (h.contains(x, y)) {
                return h;
            }
        }
        return null;
    }

    // ─── Для превью ─────────────────────────────────────────────────────────

    /** Программные действия (превью и тесты). */
    public void debugExpand(String moduleName) {
        for (GuiModel.Category cat : model.categories()) {
            for (GuiModel.Module m : cat.modules()) {
                if (m.name().equals(moduleName)) {
                    Card cd = card(m);
                    if (!cd.expanded) {
                        toggleExpand(m, cd);
                    }
                }
            }
        }
    }

    public void debugSelect(int index) {
        selectCategory(index);
    }

    public void debugQuery(String q) {
        searchFocus = true;
        setQuery(q);
    }

    public void debugFold() {
        toggleFold();
    }

    public void debugOpenMenu(GuiModel.ModeOption mode, float x, float y, float w) {
        menu = mode;
        menuShown = mode;
        menuX = x;
        menuY = y;
        menuW = w;
        menuS.snap(1.0f);
    }
}
