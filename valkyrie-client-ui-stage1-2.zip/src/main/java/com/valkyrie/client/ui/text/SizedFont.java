package com.valkyrie.client.ui.text;

import com.valkyrie.client.ui.render.Mask;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.font.LineMetrics;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Шрифт конкретного пиксельного размера: атлас глифов (страницы-маски) и кэш раскладок.
 * Раскладка строки делается движком AWT с кернингом из GPOS, позиции дробные;
 * при выводе перо округляется до 1/3 пикселя (три варианта растра глифа).
 */
public final class SizedFont {
    static final int SUBPIXEL_BINS = 3;
    private static final int PAGE = 512;
    private static final FontRenderContext FRC = new FontRenderContext(null, true, true);

    public final FontFace face;
    public final float px;
    final Font font;
    public final float ascent;
    public final float descent;
    public final float capHeight;
    public final float xHeight;

    private final List<Mask> pages = new ArrayList<>();
    private int shelfX;
    private int shelfY;
    private int shelfH;
    private final Map<Long, Glyph> glyphs = new HashMap<>();
    private final LinkedHashMap<String, Layout> layouts = new LinkedHashMap<>(256, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Layout> eldest) {
            return size() > 1024;
        }
    };
    private SizedFont fallbackSized;

    SizedFont(FontFace face, float px) {
        this.face = face;
        this.px = px;
        this.font = face.base.deriveFont(px);
        LineMetrics metrics = font.getLineMetrics("Hgx", FRC);
        this.ascent = metrics.getAscent();
        this.descent = metrics.getDescent();
        this.capHeight = inkHeight('H');
        this.xHeight = inkHeight('x');
    }

    private float inkHeight(char c) {
        if (!font.canDisplay(c)) {
            return ascent * 0.7f;
        }
        GlyphVector gv = font.createGlyphVector(FRC, new char[] {c});
        return (float) -gv.getGlyphOutline(0).getBounds2D().getMinY();
    }

    /** Раскладка строки (кэшируется). */
    public Layout layout(String text) {
        Layout layout = layouts.get(text);
        if (layout == null) {
            layout = build(text);
            layouts.put(text, layout);
        }
        return layout;
    }

    public float width(String text) {
        return text == null || text.isEmpty() ? 0.0f : layout(text).width;
    }

    private SizedFont fallback() {
        if (fallbackSized == null) {
            // Недостающие глифы (иероглифы, эмодзи) берём из системного шрифта.
            FontFace fb = FontFace.system();
            fallbackSized = fb == face ? this : fb.at(px);
        }
        return fallbackSized;
    }

    private Layout build(String text) {
        Layout out = new Layout();
        int n = text.length();
        int start = 0;
        float pen = 0.0f;
        while (start < n) {
            boolean primary = font.canDisplay(text.codePointAt(start)) || fallback() == this;
            int end = start;
            while (end < n) {
                int cp = text.codePointAt(end);
                boolean can = font.canDisplay(cp) || fallback() == this;
                if (can != primary) {
                    break;
                }
                end += Character.charCount(cp);
            }
            SizedFont run = primary ? this : fallback();
            char[] chars = text.substring(start, end).toCharArray();
            GlyphVector gv = run.font.layoutGlyphVector(FRC, chars, 0, chars.length, Font.LAYOUT_LEFT_TO_RIGHT);
            int count = gv.getNumGlyphs();
            for (int i = 0; i < count; i++) {
                out.add(run, gv.getGlyphCode(i), pen + (float) gv.getGlyphPosition(i).getX());
            }
            pen += (float) gv.getGlyphPosition(count).getX();
            start = end;
        }
        out.width = pen;
        return out;
    }

    /** Растр глифа для варианта: {@code bin} — доля пикселя (0..2), {@code light} — светлый текст на тёмном. */
    public Glyph glyph(int code, int bin, boolean light) {
        long key = ((long) code << 8) | ((long) bin << 1) | (light ? 1 : 0);
        Glyph glyph = glyphs.get(key);
        if (glyph == null) {
            glyph = rasterize(code, bin, light);
            glyphs.put(key, glyph);
        }
        return glyph;
    }

    private Glyph rasterize(int code, int bin, boolean light) {
        GlyphVector gv = font.createGlyphVector(FRC, new int[] {code});
        float shift = bin / (float) SUBPIXEL_BINS;
        Rectangle bounds = gv.getGlyphPixelBounds(0, FRC, shift, 0.0f);
        if (bounds.isEmpty()) {
            return Glyph.EMPTY;
        }
        int w = bounds.width + 2;
        int h = bounds.height + 2;
        BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setColor(Color.WHITE);
        g.drawGlyphVector(gv, shift - bounds.x + 1, -bounds.y + 1);
        g.dispose();

        Mask page = place(w, h);
        int u = shelfX - w - 1;
        int v = shelfY;
        byte[] gray = ((java.awt.image.DataBufferByte) image.getRaster().getDataBuffer()).getData();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int a = gray[y * w + x] & 0xFF;
                if (light && a > 0 && a < 255) {
                    // Светлый текст на тёмном фоне при sRGB-смешивании выглядит тоньше — слегка уплотняем.
                    a = (int) Math.round(255.0 * Math.pow(a / 255.0, 0.80));
                }
                page.set(u + x, v + y, a);
            }
        }
        page.touch();
        return new Glyph(page, u, v, w, h, bounds.x - 1, bounds.y - 1);
    }

    private Mask place(int w, int h) {
        if (pages.isEmpty() || shelfX + w + 1 > PAGE) {
            shelfX = 0;
            shelfY += shelfH + 1;
            shelfH = 0;
        }
        if (pages.isEmpty() || shelfY + h + 1 > PAGE) {
            pages.add(new Mask(face.name + "@" + px + "#" + pages.size(), PAGE, PAGE));
            shelfX = 0;
            shelfY = 0;
            shelfH = 0;
        }
        shelfX += w + 1;
        shelfH = Math.max(shelfH, h);
        return pages.get(pages.size() - 1);
    }

    /** Растеризованный глиф: позиция в странице и смещение от пера/базовой линии. */
    public record Glyph(Mask page, int u, int v, int w, int h, int offsetX, int offsetY) {
        static final Glyph EMPTY = new Glyph(null, 0, 0, 0, 0, 0, 0);
    }

    /** Раскладка: шрифт, код глифа и дробная позиция каждого глифа. */
    public static final class Layout {
        SizedFont[] fonts = new SizedFont[8];
        int[] codes = new int[8];
        float[] xs = new float[8];
        int count;
        public float width;

        void add(SizedFont font, int code, float x) {
            if (count == codes.length) {
                fonts = java.util.Arrays.copyOf(fonts, count * 2);
                codes = java.util.Arrays.copyOf(codes, count * 2);
                xs = java.util.Arrays.copyOf(xs, count * 2);
            }
            fonts[count] = font;
            codes[count] = code;
            xs[count] = x;
            count++;
        }

        public int count() {
            return count;
        }

        public SizedFont font(int i) {
            return fonts[i];
        }

        public int code(int i) {
            return codes[i];
        }

        public float x(int i) {
            return xs[i];
        }
    }
}
