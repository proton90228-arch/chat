package com.valkyrie.client.ui.icon;

import java.awt.geom.Path2D;

/** Небольшой парсер SVG path data (M L H V C S Q T A Z, абсолютные и относительные). */
public final class SvgPath {
    private final String d;
    private int pos;

    private SvgPath(String d) {
        this.d = d;
    }

    public static Path2D.Float parse(String data) {
        return new SvgPath(data).run();
    }

    private Path2D.Float run() {
        Path2D.Float path = new Path2D.Float();
        float x = 0;
        float y = 0;
        float startX = 0;
        float startY = 0;
        float lastCx = 0;
        float lastCy = 0;
        char cmd = 0;
        char prev = 0;
        while (true) {
            skipSeparators();
            if (pos >= d.length()) {
                break;
            }
            char c = d.charAt(pos);
            if (Character.isLetter(c)) {
                cmd = c;
                pos++;
            } else if (cmd == 0) {
                throw new IllegalArgumentException("path must start with a command: " + d);
            }
            boolean rel = Character.isLowerCase(cmd);
            switch (Character.toUpperCase(cmd)) {
                case 'M' -> {
                    float nx = num() + (rel ? x : 0);
                    float ny = num() + (rel ? y : 0);
                    path.moveTo(nx, ny);
                    x = startX = nx;
                    y = startY = ny;
                    cmd = rel ? 'l' : 'L'; // последующие пары — lineto
                }
                case 'L' -> {
                    x = num() + (rel ? x : 0);
                    y = num() + (rel ? y : 0);
                    path.lineTo(x, y);
                }
                case 'H' -> {
                    x = num() + (rel ? x : 0);
                    path.lineTo(x, y);
                }
                case 'V' -> {
                    y = num() + (rel ? y : 0);
                    path.lineTo(x, y);
                }
                case 'C' -> {
                    float x1 = num() + (rel ? x : 0);
                    float y1 = num() + (rel ? y : 0);
                    float x2 = num() + (rel ? x : 0);
                    float y2 = num() + (rel ? y : 0);
                    float nx = num() + (rel ? x : 0);
                    float ny = num() + (rel ? y : 0);
                    path.curveTo(x1, y1, x2, y2, nx, ny);
                    lastCx = x2;
                    lastCy = y2;
                    x = nx;
                    y = ny;
                }
                case 'S' -> {
                    boolean smooth = "CcSs".indexOf(prev) >= 0;
                    float x1 = smooth ? 2 * x - lastCx : x;
                    float y1 = smooth ? 2 * y - lastCy : y;
                    float x2 = num() + (rel ? x : 0);
                    float y2 = num() + (rel ? y : 0);
                    float nx = num() + (rel ? x : 0);
                    float ny = num() + (rel ? y : 0);
                    path.curveTo(x1, y1, x2, y2, nx, ny);
                    lastCx = x2;
                    lastCy = y2;
                    x = nx;
                    y = ny;
                }
                case 'Q' -> {
                    float x1 = num() + (rel ? x : 0);
                    float y1 = num() + (rel ? y : 0);
                    float nx = num() + (rel ? x : 0);
                    float ny = num() + (rel ? y : 0);
                    path.quadTo(x1, y1, nx, ny);
                    lastCx = x1;
                    lastCy = y1;
                    x = nx;
                    y = ny;
                }
                case 'T' -> {
                    boolean smooth = "QqTt".indexOf(prev) >= 0;
                    float x1 = smooth ? 2 * x - lastCx : x;
                    float y1 = smooth ? 2 * y - lastCy : y;
                    float nx = num() + (rel ? x : 0);
                    float ny = num() + (rel ? y : 0);
                    path.quadTo(x1, y1, nx, ny);
                    lastCx = x1;
                    lastCy = y1;
                    x = nx;
                    y = ny;
                }
                case 'A' -> {
                    float rx = num();
                    float ry = num();
                    float rotation = num();
                    boolean large = flag();
                    boolean sweep = flag();
                    float nx = num() + (rel ? x : 0);
                    float ny = num() + (rel ? y : 0);
                    arc(path, x, y, rx, ry, rotation, large, sweep, nx, ny);
                    x = nx;
                    y = ny;
                }
                case 'Z' -> {
                    path.closePath();
                    x = startX;
                    y = startY;
                }
                default -> throw new IllegalArgumentException("unsupported command " + cmd);
            }
            prev = cmd;
        }
        return path;
    }

    private void skipSeparators() {
        while (pos < d.length()) {
            char c = d.charAt(pos);
            if (c == ' ' || c == ',' || c == '\n' || c == '\t' || c == '\r') {
                pos++;
            } else {
                break;
            }
        }
    }

    private boolean flag() {
        skipSeparators();
        char c = d.charAt(pos++);
        return c == '1';
    }

    private float num() {
        skipSeparators();
        int start = pos;
        if (pos < d.length() && (d.charAt(pos) == '-' || d.charAt(pos) == '+')) {
            pos++;
        }
        boolean dot = false;
        while (pos < d.length()) {
            char c = d.charAt(pos);
            if (Character.isDigit(c)) {
                pos++;
            } else if (c == '.' && !dot) {
                dot = true;
                pos++;
            } else if ((c == 'e' || c == 'E') && pos + 1 < d.length()) {
                pos++;
                if (d.charAt(pos) == '-' || d.charAt(pos) == '+') {
                    pos++;
                }
            } else {
                break;
            }
        }
        return Float.parseFloat(d.substring(start, pos));
    }

    /** Эллиптическая дуга SVG → кубические кривые (W3C SVG, приложение F.6). */
    private static void arc(Path2D.Float path, float x0, float y0, float rx, float ry, float angle,
                            boolean large, boolean sweep, float x, float y) {
        if (rx == 0 || ry == 0) {
            path.lineTo(x, y);
            return;
        }
        double phi = Math.toRadians(angle);
        double cos = Math.cos(phi);
        double sin = Math.sin(phi);
        double dx = (x0 - x) / 2.0;
        double dy = (y0 - y) / 2.0;
        double x1p = cos * dx + sin * dy;
        double y1p = -sin * dx + cos * dy;
        double arx = Math.abs(rx);
        double ary = Math.abs(ry);
        double lambda = (x1p * x1p) / (arx * arx) + (y1p * y1p) / (ary * ary);
        if (lambda > 1) {
            arx *= Math.sqrt(lambda);
            ary *= Math.sqrt(lambda);
        }
        double num = arx * arx * ary * ary - arx * arx * y1p * y1p - ary * ary * x1p * x1p;
        double den = arx * arx * y1p * y1p + ary * ary * x1p * x1p;
        double coef = Math.sqrt(Math.max(0, num / den)) * (large == sweep ? -1 : 1);
        double cxp = coef * (arx * y1p / ary);
        double cyp = coef * -(ary * x1p / arx);
        double cx = cos * cxp - sin * cyp + (x0 + x) / 2.0;
        double cy = sin * cxp + cos * cyp + (y0 + y) / 2.0;
        double theta1 = angle((x1p - cxp) / arx, (y1p - cyp) / ary);
        double delta = angle((x1p - cxp) / arx, (y1p - cyp) / ary, (-x1p - cxp) / arx, (-y1p - cyp) / ary);
        if (!sweep && delta > 0) {
            delta -= 2 * Math.PI;
        } else if (sweep && delta < 0) {
            delta += 2 * Math.PI;
        }
        int segments = (int) Math.ceil(Math.abs(delta) / (Math.PI / 2) - 1e-7);
        double step = delta / Math.max(1, segments);
        double t = 4.0 / 3.0 * Math.tan(step / 4);
        double a = theta1;
        for (int i = 0; i < segments; i++) {
            double c1 = Math.cos(a);
            double s1 = Math.sin(a);
            double c2 = Math.cos(a + step);
            double s2 = Math.sin(a + step);
            double[] p1 = map(cx, cy, arx, ary, cos, sin, c1 - t * s1, s1 + t * c1);
            double[] p2 = map(cx, cy, arx, ary, cos, sin, c2 + t * s2, s2 - t * c2);
            double[] p3 = map(cx, cy, arx, ary, cos, sin, c2, s2);
            path.curveTo(p1[0], p1[1], p2[0], p2[1], p3[0], p3[1]);
            a += step;
        }
    }

    private static double[] map(double cx, double cy, double rx, double ry, double cos, double sin, double ux, double uy) {
        double px = ux * rx;
        double py = uy * ry;
        return new double[] {cx + cos * px - sin * py, cy + sin * px + cos * py};
    }

    private static double angle(double ux, double uy) {
        return Math.atan2(uy, ux);
    }

    private static double angle(double ux, double uy, double vx, double vy) {
        return Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy);
    }
}
