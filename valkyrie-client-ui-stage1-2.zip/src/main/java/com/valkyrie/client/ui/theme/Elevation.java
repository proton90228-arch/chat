package com.valkyrie.client.ui.theme;

/**
 * Уровни высоты M3. Каждый — две тени (ключевая и рассеянная), значения в единицах GUI
 * (≈ dp при масштабе GUI 2), как {@code box-shadow} уровней в Material Web.
 */
public enum Elevation {
    LEVEL0(0, 0, 0, 0, 0, 0, 0, 0),
    LEVEL1(1, 1.0f, 0.30f, 0, 1, 1.5f, 0.15f, 1),
    LEVEL2(1, 1.0f, 0.30f, 0, 2, 3.0f, 0.15f, 2),
    LEVEL3(1, 1.5f, 0.30f, 0, 4, 4.0f, 0.15f, 3),
    LEVEL4(2, 1.5f, 0.30f, 0, 6, 5.0f, 0.15f, 4),
    LEVEL5(4, 2.0f, 0.30f, 0, 8, 6.0f, 0.15f, 6);

    public final float keyY;
    public final float keySigma;
    public final float keyAlpha;
    public final float keySpread;
    public final float ambientY;
    public final float ambientSigma;
    public final float ambientAlpha;
    public final float ambientSpread;

    Elevation(float keyY, float keySigma, float keyAlpha, float keySpread,
              float ambientY, float ambientSigma, float ambientAlpha, float ambientSpread) {
        this.keyY = keyY;
        this.keySigma = keySigma;
        this.keyAlpha = keyAlpha;
        this.keySpread = keySpread;
        this.ambientY = ambientY;
        this.ambientSigma = ambientSigma;
        this.ambientAlpha = ambientAlpha;
        this.ambientSpread = ambientSpread;
    }
}
