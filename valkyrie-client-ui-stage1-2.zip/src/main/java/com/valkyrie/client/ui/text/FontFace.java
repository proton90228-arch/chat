package com.valkyrie.client.ui.text;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.font.TextAttribute;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Начертание шрифта (один TTF). Растеризованные размеры создаются по требованию:
 * размер в физических пикселях = размер стиля в GUI × масштаб интерфейса, поэтому
 * текст всегда рисуется 1:1 с пикселями экрана, без растяжения атласа.
 */
public final class FontFace {
    public final String name;
    final Font base;
    final FontFace fallback;
    private final Map<Integer, SizedFont> sizes = new HashMap<>();

    FontFace(String name, Font base, FontFace fallback) {
        this.name = name;
        Map<TextAttribute, Object> attributes = new HashMap<>();
        attributes.put(TextAttribute.KERNING, TextAttribute.KERNING_ON);
        this.base = base.deriveFont(attributes);
        this.fallback = fallback;
    }

    /** Загружает TTF из ресурсов мода; при ошибке возвращает {@code fallback} (или системный Sans). */
    public static FontFace load(String name, String resourcePath, FontFace fallback) {
        try (InputStream in = FontFace.class.getResourceAsStream(resourcePath)) {
            if (in != null) {
                return new FontFace(name, Font.createFont(Font.TRUETYPE_FONT, in), fallback == null ? system() : fallback);
            }
        } catch (FontFormatException | IOException | RuntimeException ignored) {
            // Ниже — запасной вариант.
        }
        return fallback != null ? fallback : system();
    }

    private static FontFace system;

    /** Системный логический шрифт: покрывает иероглифы и всё, чего нет в бренд-шрифтах. */
    public static synchronized FontFace system() {
        if (system == null) {
            system = new FontFace("system", new Font(Font.SANS_SERIF, Font.PLAIN, 12), null);
        }
        return system;
    }

    /** Растр размера {@code px} (квантуется до 1/4 пикселя). */
    public SizedFont at(float px) {
        int key = Math.max(4, Math.round(px * 4.0f));
        SizedFont sized = sizes.get(key);
        if (sized == null) {
            sized = new SizedFont(this, key / 4.0f);
            sizes.put(key, sized);
        }
        return sized;
    }

    /** Сбрасывает растры (например, после смены масштаба GUI старые размеры не нужны). */
    public void trim(int keepAtMost) {
        if (sizes.size() > keepAtMost) {
            sizes.clear();
        }
    }
}
