package com.valkyrie.client.ui.color;

import java.util.HashMap;
import java.util.Map;

/** Тональная палитра: фиксированные hue и chroma, тон 0..100. Значения кэшируются. */
public final class TonalPalette {
    private final double hue;
    private final double chroma;
    private final Map<Integer, Integer> cache = new HashMap<>();

    public TonalPalette(double hue, double chroma) {
        this.hue = Hct.mod360(hue);
        this.chroma = chroma;
    }

    public double hue() {
        return hue;
    }

    public double chroma() {
        return chroma;
    }

    /** Непрозрачный ARGB для тона (целого — как в токенах лаунчера). */
    public int tone(int tone) {
        return cache.computeIfAbsent(tone, t -> Hct.toArgb(hue, chroma, t));
    }
}
