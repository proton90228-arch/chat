package com.valkyrie.client.ui.render;

/**
 * Минимальная поверхность рисования в физических пикселях окна. Её реализуют
 * {@code GuiCanvas} (Minecraft {@code GuiGraphics}) и {@code ImageCanvas} (PNG-превью
 * в песочнице) — поэтому весь интерфейс над ней можно проверять без игры.
 * Смешивание — обычное «source over» с непремультиплицированной альфой, как в GUI Minecraft.
 */
public interface Canvas {
    /** Физических пикселей на единицу GUI (масштаб интерфейса Minecraft). */
    float scale();

    /** Ширина области GUI в физических пикселях. */
    int width();

    int height();

    void fill(int x0, int y0, int x1, int y1, int argb);

    void gradient(int x0, int y0, int x1, int y1, int argbTop, int argbBottom);

    /**
     * Рисует область {@code (sx, sy, sw, sh)} маски в прямоугольник {@code (dx, dy, dw, dh)}
     * c ближайшей выборкой, тонируя цветом {@code argb} (альфа цвета умножается на покрытие).
     */
    void mask(Mask mask, int dx, int dy, int dw, int dh, int sx, int sy, int sw, int sh, int argb);

    /** Прямоугольная обрезка; вложенные области пересекаются. */
    void pushClip(int x0, int y0, int x1, int y1);

    void popClip();
}
