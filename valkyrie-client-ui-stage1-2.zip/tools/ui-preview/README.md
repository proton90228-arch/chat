# ui-preview

Рендер PNG-превью нового интерфейса без Minecraft (JDK 21).

```
UI=src/main/java/com/valkyrie/client/ui
java tools/ui-preview/Javac.java build/ui-preview "" $UI/color $UI/motion $UI/render $UI/text $UI/icon $UI/theme $UI/clickgui tools/ui-preview/src
java -cp build/ui-preview GoldenSchemeTest tools/ui-preview/golden.txt
java -Djava.awt.headless=true -cp build/ui-preview:src/main/resources preview.ComponentSheet build
java -Djava.awt.headless=true -cp build/ui-preview:src/main/resources preview.ClickGuiPreview build
```

`ImageCanvas` смешивает цвета так же, как GUI Minecraft, поэтому превью совпадает с игрой.
